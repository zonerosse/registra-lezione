"""«Traduci» e «Scarica la trascrizione» (anteprima 63, 08/11/2026).

Traduci: gli appunti (PDF, con Sonnet: sono appunti, Paolo non vuole Haiku) o la trascrizione (Word, con Haiku:
e' solo una traduzione riga per riga) in un'altra lingua. Esce un file nuovo; l'originale non cambia. Le
traduzioni si tengono nella cartella della lezione (traduzioni/), cosi' riaprire non costa di nuovo.
Scarica: la trascrizione in testo (.txt), Word (.docx) o sottotitoli (.srt), gratis."""
import copy
import hashlib
import json
from pathlib import Path

import appunti as ap
import chiedi as ch
import elaborazione as el
import testi
from testi import tr

_TOOL_AP = {"name": "salva_traduzione", "description": "Salva gli appunti tradotti.",
            "input_schema": {"type": "object", "properties": {"testi": {"type": "array", "items": {"type": "string"},
                             "description": "i testi tradotti, uno per riga, nello stesso ordine e stesso numero"}},
                             "required": ["testi"]}}
_SALTA = {"dove", "slide", "sigle_v", "stelle", "formato", "lezioni", "lezione", "orario", "carta", "peso", "_evid", "_mie"}


def _segmenti(cartella):
    return [s for s in ch.segmenti_lezione(cartella) if str(s.get("testo") or "").strip()]


def _cartella_trad(cartella):
    d = Path(cartella) / "traduzioni"
    d.mkdir(exist_ok=True)
    return d


def _chiave_file(lingua):
    return hashlib.sha1(lingua.strip().lower().encode()).hexdigest()[:10]


# --------------------------------------------------------------------------- appunti

def _testi_di(v, via=()):
    """[(via, testo)] dei testi da tradurre in un .json di appunti (non i numeri delle slide, gli orari...)."""
    out = []
    if isinstance(v, str):
        if v.strip():
            out.append((via, v))
    elif isinstance(v, list):
        for i, x in enumerate(v):
            out += _testi_di(x, via + (i,))
    elif isinstance(v, dict):
        for k, x in v.items():
            if k not in _SALTA:
                out += _testi_di(x, via + (k,))
    return out


def _metti(dati, via, testo):
    x = dati
    for p in via[:-1]:
        x = x[p]
    x[via[-1]] = testo


def _traduci_righe(chiave, righe, lingua, modello, sistema):
    """Traduce una lista di testi a pezzi (stesso numero, stesso ordine). Torna (tradotti, usage)."""
    out, uso, pezzo, lung = [], {}, [], 0

    def manda(pz):
        corpo = {"model": modello, "max_tokens": 12000,
                 "system": sistema + f" Traduci in {lingua}. Ogni riga e' un testo a se': restituisci ESATTAMENTE "
                                     f"{len(pz)} testi nello stesso ordine, senza unirli ne' dividerli; formule, numeri, "
                                     "nomi propri e sigle restano come sono. Chiama lo strumento salva_traduzione.",
                 "tools": [_TOOL_AP],
                 "messages": [{"role": "user", "content": "\n".join(f"{i + 1}. {json.dumps(t, ensure_ascii=False)}"
                                                                    for i, t in enumerate(pz))}]}
        d, u = ch.strumento(chiave, corpo, "testi", "tt_err")
        for k, v in u.items():
            uso[k] = uso.get(k, 0) + v
        t = [str(x) for x in d.get("testi") or []]
        if len(t) != len(pz):              # numero sbagliato: quelli che mancano restano come erano
            t = (t + pz[len(t):])[:len(pz)]
        return t
    for r in righe:
        if pezzo and lung + len(r) > 9000:
            out += manda(pezzo)
            pezzo, lung = [], 0
        pezzo.append(r)
        lung += len(r)
    if pezzo:
        out += manda(pezzo)
    return out, uso


def traduci_appunti(cartella, chiave, lingua, cartella_pacchetti):
    """Il PDF degli appunti (tutte le parti, tutti i formati della lezione) tradotto. Torna (file, usage)."""
    cartella = Path(cartella)
    info = el.leggi_json(cartella / "info.json", {}) or {}
    formati = [f for f in ap.FORMATI if info.get(ap.chiave_info(f))]
    if not formati:
        raise ap.ErroreAppunti(tr("tt_noap"))
    formato = "cornell" if "cornell" in formati else formati[0]
    fatti = info.get(ap.chiave_info(formato)) or {}
    ks = sorted(fatti, key=lambda x: int(x) if str(x).isdigit() else 0)
    parti_orig = [(k, el.leggi_json(ap.file_json(cartella, k, formato))) for k in ks]
    parti_orig = [(k, d) for k, d in parti_orig if d]
    firma = hashlib.sha1(json.dumps([d for _, d in parti_orig], sort_keys=True, ensure_ascii=False).encode()).hexdigest()[:12]
    salvato = _cartella_trad(cartella) / f"appunti_{_chiave_file(lingua)}.json"
    vecchio = el.leggi_json(salvato, {}) or {}
    uso = {}
    if vecchio.get("firma") == firma and vecchio.get("parti"):
        tradotte = vecchio["parti"]
    else:
        tradotte = []
        for k, d in parti_orig:
            d = copy.deepcopy(d)
            voci = _testi_di(d)
            nuovi, u = _traduci_righe(chiave, [t for _, t in voci], lingua, ap.MODELLO,
                                      "Sei un traduttore di appunti universitari: traduzione fedele e scorrevole.")
            for k2, v in u.items():
                uso[k2] = uso.get(k2, 0) + v
            for (via, _), t in zip(voci, nuovi):
                _metti(d, via, t)
            tradotte.append([k, d])
        el.scrivi_json(salvato, {"firma": firma, "lingua": lingua, "parti": tradotte})
    info2 = dict(info, lingua_appunti="it" if lingua.lower().startswith("ital") else "en")
    L = testi.lingua_di(info2)
    pac = info.get("pacchetti") or {}
    parti = []
    for k, d in tradotte:
        base = ap._stem(pac.get(str(k)) or "")
        etichetta = base.split(" – ")[-1] if " – " in base else f"{tr('parte', L)} {k}"
        mappa = el.leggi_json(cartella / f"pacchetto_{int(k):03d}.json", []) or []
        slide = {m["n"]: (str(el.immagine_slide(cartella, m["file"])) if m.get("file") else None, m.get("inizio", 0)) for m in mappa}
        parti.append((d, etichetta, slide))
    dest = Path(cartella_pacchetti) / tr("tt_cartella") / f"{tr('tt_ap')} – {el.nome_sicuro(info.get('nome') or cartella.name)} ({el.nome_sicuro(lingua)}).pdf"
    dest.parent.mkdir(parents=True, exist_ok=True)
    ap.pdf_appunti_parti(parti, info2, str(dest))
    return dest, uso


# --------------------------------------------------------------------------- trascrizione

def _doc_trascrizione(info, righe, lingua_doc, sotto):
    return {"titolo": info.get("nome") or "", "sottotitolo": sotto, "lingua": lingua_doc, "formato": "cornell",
            "sezioni": [{"titolo": "", "livello": 1, "testo": f"[{ch.hms(t)}]  {x}", "punti": [], "numerati": False,
                         "aggiunte": [], "tabella": None} for t, x in righe]}


def traduci_trascrizione(cartella, chiave, lingua, cartella_pacchetti):
    import condividi as cd
    cartella = Path(cartella)
    info = el.leggi_json(cartella / "info.json", {}) or {}
    segs = _segmenti(cartella)
    if not segs:
        raise ap.ErroreAppunti(tr("tt_notr"))
    orig = [str(s["testo"]).strip() for s in segs]
    firma = hashlib.sha1("\n".join(orig).encode()).hexdigest()[:12]
    salvato = _cartella_trad(cartella) / f"trascrizione_{_chiave_file(lingua)}.json"
    vecchio = el.leggi_json(salvato, {}) or {}
    uso = {}
    if vecchio.get("firma") == firma and len(vecchio.get("righe") or []) == len(orig):
        nuovi = vecchio["righe"]
    else:
        nuovi, uso = _traduci_righe(chiave, orig, lingua, ch.MODELLO,
                                    "Sei un traduttore: questa e' la trascrizione di una lezione, frase per frase.")
        el.scrivi_json(salvato, {"firma": firma, "lingua": lingua, "righe": nuovi})
    L = "it" if lingua.lower().startswith("ital") else "en"
    doc = _doc_trascrizione(info, [(s["inizio"], t) for s, t in zip(segs, nuovi)], L, f"{tr('tt_tr')} · {lingua}")
    dest = Path(cartella_pacchetti) / tr("tt_cartella") / f"{tr('tt_tr')} – {el.nome_sicuro(info.get('nome') or cartella.name)} ({el.nome_sicuro(lingua)}).docx"
    cd.crea_docx(doc, dest)
    return dest, uso


def _srt_ora(s):
    ms = int(round(float(s or 0) * 1000))
    return f"{ms // 3600000:02d}:{ms // 60000 % 60:02d}:{ms // 1000 % 60:02d},{ms % 1000:03d}"


def scarica_trascrizione(cartella, tipo, cartella_pacchetti):
    """tipo = txt | docx | srt. Torna il file."""
    import condividi as cd
    cartella = Path(cartella)
    info = el.leggi_json(cartella / "info.json", {}) or {}
    segs = _segmenti(cartella)
    if not segs:
        raise ap.ErroreAppunti(tr("tt_notr"))
    nome = el.nome_sicuro(info.get("nome") or cartella.name)
    dest = Path(cartella_pacchetti) / tr("tt_cartella") / f"{tr('tt_tr')} – {nome}.{tipo}"
    dest.parent.mkdir(parents=True, exist_ok=True)
    if tipo == "txt":
        dest.write_text(f"{info.get('nome') or ''}\n\n" + "\n".join(f"[{ch.hms(s['inizio'])}] {str(s['testo']).strip()}" for s in segs) + "\n",
                        encoding="utf-8")
    elif tipo == "srt":
        righe = []
        for i, s in enumerate(segs, 1):
            fine = float(s.get("fine") or 0) or float(s["inizio"]) + 3
            righe.append(f"{i}\n{_srt_ora(s['inizio'])} --> {_srt_ora(fine)}\n{str(s['testo']).strip()}\n")
        dest.write_text("\n".join(righe), encoding="utf-8")
    else:
        cd.crea_docx(_doc_trascrizione(info, [(s["inizio"], str(s["testo"]).strip()) for s in segs], testi.lingua_di(info), tr("tt_tr")), dest)
    return dest
