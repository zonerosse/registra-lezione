"""Nuovi modi di ripassare (anteprima 67, 08/11/2026), tutti gratis e senza Claude:
- «Completa la frase»: le righe degli appunti con la parola chiave nascosta;
- «Abbina»: domande e risposte brevi da abbinare contro il tempo;
- «Slide coperte»: lo studente copre col dito parti di una slide (come l'«image occlusion» di Anki); nel ripasso
  il riquadro si scopre al tocco. I riquadri stanno in coperte.json nella cartella della lezione (frazioni 0-1 della
  slide), con l'ultimo voto: le slide «da rivedere» tornano per prime."""
import base64
import hashlib
import io
import random
import re
import time
from pathlib import Path

import chiedi as ch
import elaborazione as el
import ripasso as rp


def _rx(p):
    return re.compile(r"(?<![\w])" + re.escape(p) + r"(?![\w])", re.I)


def completa(cartelle, n=12):
    """[{"id", "pezzi": [testo, buco, testo, ...], "fonte"}]: righe con una parola chiave nascosta."""
    out = []
    for c in cartelle:
        for carta in rp.carte_lezione(c):
            parole = sorted({p.strip() for p in carta.get("parole") or [] if 2 < len(p.strip()) < 40}, key=len, reverse=True)
            for riga in carta.get("schema") or []:
                riga = str(riga).strip()
                if len(riga) < 20 or len(riga) > 260:
                    continue
                m = next((m for m in (_rx(p).search(riga) for p in parole) if m), None)
                if not m:          # nessuna parola chiave nella riga: la parola piu' lunga (almeno 7 lettere)
                    lunghe = sorted(re.finditer(r"[^\W\d_]{7,}", riga), key=lambda x: len(x.group(0)), reverse=True)
                    m = lunghe[0] if lunghe else None
                if m:
                    out.append({"id": hashlib.sha1(riga.encode()).hexdigest()[:12],
                                "pezzi": [riga[:m.start()], m.group(0), riga[m.end():]],
                                "domanda": carta["domanda"], "fonte": carta.get("lezione") or ""})
    random.shuffle(out)
    return out[:n]


def _corta(x, n):
    x = re.sub(r"\s+", " ", str(x or "")).strip()
    return x if len(x) <= n else x[:n - 1].rsplit(" ", 1)[0] + "…"


def abbina(cartelle, n=6):
    """[{"k", "d", "r"}]: n domande con la loro risposta breve (la prima riga degli appunti o l'idea)."""
    carte = []
    for c in cartelle:
        for x in rp.carte_lezione(c):
            r = x.get("idea") or next((s for s in x.get("schema") or [] if str(s).strip()), "")
            if r and len(x["domanda"]) <= 140:
                carte.append((x["domanda"], r))
    random.shuffle(carte)
    viste, out = set(), []
    for d, r in carte:
        rr = _corta(r, 90)
        if rr.lower() in viste:
            continue
        viste.add(rr.lower())
        out.append({"k": len(out), "d": _corta(d, 110), "r": rr})
        if len(out) == n:
            break
    return out


# --------------------------------------------------------------------------- slide coperte

def _file(cart):
    return Path(cart) / "coperte.json"


def _img(cart, nome, lato):
    from PIL import Image
    with Image.open(el.immagine_slide(cart, nome)) as im:
        im = im.convert("RGB")
        im.thumbnail((lato, lato))
        b = io.BytesIO()
        im.save(b, "JPEG", quality=80)
    return "data:image/jpeg;base64," + base64.b64encode(b.getvalue()).decode()


def slide(cartella):
    """Le slide di una lezione da coprire: [{"n", "file", "img" (piccola), "riquadri"}]."""
    cart = Path(cartella)
    fatte = {x.get("file"): x for x in el.leggi_json(_file(cart), []) or []}
    out = []
    for s in ch.slide_della_lezione(cart):
        try:
            out.append({"n": s["n"], "file": s["file"], "img": _img(cart, s["file"], 360),
                        "riquadri": len((fatte.get(s["file"]) or {}).get("riquadri") or [])})
        except Exception:
            continue
    return out


def una_slide(cartella, nome):
    cart = Path(cartella)
    x = next((x for x in el.leggi_json(_file(cart), []) or [] if x.get("file") == nome), {})
    return {"img": _img(cart, nome, 1280), "riquadri": x.get("riquadri") or []}


def salva(cartella, nome, n, riquadri):
    cart = Path(cartella)
    lista = [x for x in el.leggi_json(_file(cart), []) or [] if x.get("file") != nome]
    rq = []
    for r in riquadri or []:
        try:
            x, y, w, h = (max(0.0, min(1.0, float(r[k]))) for k in ("x", "y", "w", "h"))
        except (KeyError, TypeError, ValueError):
            continue
        if w > 0.01 and h > 0.01:
            rq.append({"x": round(x, 4), "y": round(y, 4), "w": round(w, 4), "h": round(h, 4)})
    if rq:
        lista.append({"file": nome, "n": int(n or 0), "riquadri": rq, "voto": None, "quando": 0})
    el.scrivi_json(_file(cart), sorted(lista, key=lambda x: x.get("n") or 0))
    return len(rq)


def da_ripassare(cartelle):
    """Le slide coperte delle lezioni: prima quelle «da rivedere» o mai viste, poi le altre dalla piu' vecchia."""
    out = []
    for c in cartelle:
        cart = Path(c)
        info = el.leggi_json(cart / "info.json", {}) or {}
        for x in el.leggi_json(_file(cart), []) or []:
            if not x.get("riquadri"):
                continue
            try:
                img = _img(cart, x["file"], 1280)
            except Exception:
                continue
            out.append({"cartella": str(cart), "file": x["file"], "n": x.get("n") or 0, "img": img, "riquadri": x["riquadri"],
                        "lezione": info.get("nome") or cart.name, "voto": x.get("voto"), "quando": x.get("quando") or 0})
    out.sort(key=lambda x: (x["voto"] is True, x["quando"]))
    return out


def conta(cartelle):
    return sum(len(x.get("riquadri") or []) for c in cartelle for x in el.leggi_json(_file(c), []) or [])


def voto(cartella, nome, ok):
    cart = Path(cartella)
    lista = el.leggi_json(_file(cart), []) or []
    for x in lista:
        if x.get("file") == nome:
            x["voto"], x["quando"] = bool(ok), int(time.time())
    el.scrivi_json(_file(cart), lista)


def immagini_anki(cartelle, tmp):
    """Per «Esporta per Anki»: una carta per riquadro (davanti il riquadro pieno, dietro il riquadro tratteggiato)."""
    from PIL import Image, ImageDraw
    carte = []
    for c in cartelle:
        cart = Path(c)
        info = el.leggi_json(cart / "info.json", {}) or {}
        for x in el.leggi_json(_file(cart), []) or []:
            try:
                with Image.open(el.immagine_slide(cart, x["file"])) as im:
                    base = im.convert("RGB")
                    base.thumbnail((1280, 1280))
            except Exception:
                continue
            W, H = base.size
            for i, r in enumerate(x.get("riquadri") or []):
                box = [r["x"] * W, r["y"] * H, (r["x"] + r["w"]) * W, (r["y"] + r["h"]) * H]
                fronte, retro = base.copy(), base.copy()
                for j, r2 in enumerate(x["riquadri"]):
                    b2 = [r2["x"] * W, r2["y"] * H, (r2["x"] + r2["w"]) * W, (r2["y"] + r2["h"]) * H]
                    ImageDraw.Draw(fronte).rectangle(b2, fill=(10, 74, 120) if j == i else (148, 163, 184))
                    if j != i:
                        ImageDraw.Draw(retro).rectangle(b2, fill=(148, 163, 184))
                ImageDraw.Draw(retro).rectangle(box, outline=(220, 38, 38), width=5)
                h = hashlib.sha1(f"{cart.name}|{x['file']}|{i}|{r}".encode()).hexdigest()[:14]
                f1, f2 = Path(tmp) / f"cop_{h}_a.jpg", Path(tmp) / f"cop_{h}_b.jpg"
                fronte.save(f1, "JPEG", quality=82)
                retro.save(f2, "JPEG", quality=82)
                carte.append({"id": f"cop:{x['file']}:{i}", "cartella": str(cart), "lezione": info.get("nome") or cart.name,
                              "coperta": True, "fronte": str(f1), "retro": str(f2), "slide_n": x.get("n") or 0})
    return carte
