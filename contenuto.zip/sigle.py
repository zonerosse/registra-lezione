# -*- coding: utf-8 -*-
"""Sigle sempre spiegate negli appunti (07/11/2026, Paolo: «avevamo detto di non mettere sigle senza la rispettiva
spiegazione»). La regola c'e' gia' nelle istruzioni a Claude (CHIARO), ma Claude non sempre la rispetta: qui il programma
la fa rispettare da solo.

La prima volta che una sigla compare in un blocco (domanda, sezione, voce) le si aggiunge la spiegazione tra parentesi,
presa da:
  1. il formulario / le parole chiave degli stessi appunti (Claude spiega li' le sigle che usa);
  2. un piccolo elenco di unita' di misura e sigle comuni;
  3. per gli appunti nuovi, le sigle che restano senza spiegazione si chiedono a Claude (una richiesta piccola).
"""
import logging
import re

log = logging.getLogger("registra")

# unita' di misura e sigle che si incontrano in tutte le materie
BASE = {
    "it": {
        "ng/mL": "nanogrammi per millilitro", "ng/ml": "nanogrammi per millilitro", "pg/mL": "picogrammi per millilitro",
        "pg/ml": "picogrammi per millilitro", "mg/dL": "milligrammi per decilitro", "mg/dl": "milligrammi per decilitro",
        "g/dL": "grammi per decilitro", "g/dl": "grammi per decilitro", "mg/L": "milligrammi per litro",
        "mg/kg": "milligrammi per chilo di peso", "µg/kg": "microgrammi per chilo di peso", "mcg/kg": "microgrammi per chilo di peso",
        "nmol/L": "nanomoli per litro", "nmol/l": "nanomoli per litro", "mmol/L": "millimoli per litro", "mmol/l": "millimoli per litro",
        "µmol/L": "micromoli per litro", "mEq/L": "milliequivalenti per litro", "UI/mL": "unità internazionali per millilitro",
        "mUI/mL": "milliunità internazionali per millilitro", "UI/L": "unità internazionali per litro", "U/L": "unità per litro",
        "km/h": "chilometri all'ora", "m/s": "metri al secondo", "kcal/kg": "chilocalorie per chilo",
        "DNA": "acido desossiribonucleico, il materiale genetico", "RNA": "acido ribonucleico", "UI": "unità internazionali",
        "LH": "ormone luteinizzante", "FSH": "ormone follicolo-stimolante", "GnRH": "ormone che fa rilasciare LH e FSH",
        "hCG": "gonadotropina corionica umana", "eCG": "gonadotropina corionica equina", "P4": "progesterone",
        "E2": "estradiolo", "AMH": "ormone antimülleriano", "PRL": "prolattina", "TSH": "ormone che stimola la tiroide",
        "PCR": "esame che cerca il DNA o l'RNA di un microbo", "ELISA": "test di laboratorio con enzimi",
        "RIA": "dosaggio con traccianti radioattivi", "IA": "inseminazione artificiale", "IM": "nel muscolo",
        "EV": "in vena", "SC": "sotto la pelle", "PIL": "prodotto interno lordo", "IVA": "imposta sul valore aggiunto",
    },
    "en": {
        "ng/mL": "nanograms per millilitre", "ng/ml": "nanograms per millilitre", "mg/dL": "milligrams per decilitre",
        "mg/kg": "milligrams per kilogram of body weight", "nmol/L": "nanomoles per litre", "mmol/L": "millimoles per litre",
        "km/h": "kilometres per hour", "m/s": "metres per second", "DNA": "deoxyribonucleic acid, the genetic material",
        "RNA": "ribonucleic acid", "LH": "luteinizing hormone", "FSH": "follicle-stimulating hormone",
        "PCR": "test that looks for the DNA or RNA of a germ", "GDP": "gross domestic product",
    },
}
# sigle che tutti conoscono: non si spiegano
NOTE = {"PDF", "OK", "TV", "USA", "UE", "EU", "UK", "PC", "CD", "DVD", "SMS", "WIFI", "WI-FI", "GPS", "ID", "N.B.", "NB",
        "PS", "FAQ", "URL", "WWW", "IT", "EN", "AM", "PM", "A4", "S.p.A.", "SPA", "SRL", "ONU", "ITALIA", "NATO", "IBAN",
        "UFO", "COVID", "COVID-19", "SARS-CoV-2"}
_ROMANI = re.compile(r"^(?=[IVXLCDM]+$)M{0,3}(CM|CD|D?C{0,3})(XC|XL|L?X{0,3})(IX|IV|V?I{0,3})$")
# una sigla: parola con almeno due maiuscole (LH, GnRH, hCG, L2-HGA) o maiuscola + cifra (P4, E2); oppure un'unita' «ng/mL»
_PAROLA = re.compile(r"(?<![\w/.-])([A-Za-z0-9µμ][A-Za-z0-9µμα-ω-]*[A-Za-z0-9α-ω](?:/[A-Za-z]{1,4})?|[A-Z])(?![\w/-])")
_SALTA = {"formulario", "legenda", "dove", "slide", "titolo", "da_controllare", "metodo", "formato", "mio_nome", "stelle",
          "inizio", "lingua", "parole_chiave", "src", "cartella", "file", "voci_aggiunte", "dall_ultima"}


_PAROLINE = set("""IN IL LA LE LO GLI DI DA AL DEL DAL NEL SUL CON PER TRA FRA SE NON MA ED E O UN UNA AI AGLI ALLA DELLA DELLE DEGLI
DEI SI NO HA HO PIU THE OF TO AND OR FOR ON AT BY IS IT AS AN BE NOT ALL""".split())


def e_sigla(w, parole=()):
    if w in NOTE or w.upper() in NOTE or w in _PAROLINE or _ROMANI.match(w):
        return False
    if w.isupper() and "-" not in w and not any(c.isdigit() for c in w) and w.lower() in parole:
        return False                               # parola scritta in maiuscolo («CICLO»), che nel testo c'e' anche in minuscolo
    if "/" not in w and sum(c.islower() for c in w) > sum(c.isupper() for c in w) and len(w) > 4:
        return False                               # un nome: «McDonald», «Mahi-Brown»
    if "/" in w:                                   # unita' di misura: «ng/mL», «mg/dL»
        a, b = w.split("/", 1)
        return len(a) <= 5 and len(b) <= 4 and a.isalpha() or a in ("µg", "μg", "mcg")
    maiu = sum(c.isupper() for c in w)
    cifre = sum(c.isdigit() for c in w)
    if len(w) > 10 or w.isdigit():
        return False
    if maiu >= 2:
        return not (w.isupper() and len(w) > 6 and "-" not in w)     # parole scritte tutte maiuscole: «IMPORTANTE»
    return maiu == 1 and cifre >= 1 and w[0].isupper() and len(w) <= 5   # P4, E2, T4


def _pulisci(s):
    s = re.sub(r"\s+", " ", str(s or "")).strip().rstrip(".;:")
    s = s[:1].lower() + s[1:] if s[:2] != s[:2].upper() else s
    return s if len(s) <= 90 else s[:90].rsplit(" ", 1)[0] + "…"


def dizionario(dati, L="it"):
    """{sigla: spiegazione} dal formulario e dalle parole chiave degli appunti, piu' le sigle comuni."""
    d = dict(BASE.get(L) or BASE["it"])
    voci = []
    for k in ("formulario", "legenda"):
        for v in dati.get(k) or []:
            if isinstance(v, dict):
                voci.append((v.get("simbolo") or v.get("sigla") or v.get("termine"), v.get("significato") or v.get("spiegazione")))
            elif isinstance(v, str) and (":" in v or " = " in v):
                a, _, b = v.partition(":") if ":" in v else v.partition(" = ")
                voci.append((a, b))
    for v in dati.get("parole_chiave") or []:
        if isinstance(v, dict):
            voci.append((v.get("parola"), v.get("significato")))
    for a, b in voci:
        a, b = str(a or "").strip(), _pulisci(b)
        if not a or not b:
            continue
        # «LH (ormone luteinizzante)» oppure «LH»
        m = re.match(r"^(\S+)\s*\((.+)\)$", a)
        if m and e_sigla(m.group(1)):
            d[m.group(1)] = _pulisci(m.group(2))
        if e_sigla(a):
            d[a] = b
    return d


def _nel_testo(s, d, visti, mancano, parole=()):
    def sost(m):
        w = m.group(1)
        if not e_sigla(w, parole):
            return w
        k = w.lower()
        if k in visti or s[:m.start()].count("(") > s[:m.start()].count(")"):
            return w
        visti.add(k)
        dopo = s[m.end():m.end() + 3]
        prima = s[:m.start()]
        if re.match(r"\s*\(", dopo) or prima.count("(") > prima.count(")"):
            return w      # gia' spiegata, o e' dentro una parentesi (una spiegazione: «ormone luteinizzante (LH)», «F2 alfa»)
        spieg = d.get(w) or next((v for k2, v in d.items() if k2.lower() == k), None)
        if not spieg:
            mancano.add(w)
            return w
        if spieg.lower() == w.lower():
            return w
        return f"{w} ({spieg})"
    return _PAROLA.sub(sost, s)


def spiega(dati, L="it", extra=None):
    """Aggiunge la spiegazione alle sigle (la prima volta in ogni blocco). Cambia dati; torna le sigle rimaste senza."""
    if not isinstance(dati, dict):
        return set()
    d = dizionario(dati, L)
    d.update(extra or {})
    mancano = set()
    import json
    parole = set(re.findall(r"\b[a-zàèéìòù]{2,}\b", json.dumps(dati, ensure_ascii=False)))

    def giro(x, visti, chiave=None):
        if isinstance(x, str):
            return _nel_testo(x, d, visti, mancano, parole)
        if isinstance(x, list):
            # una lista di blocchi/domande/sezioni: ognuno spiega le sue sigle; una lista di frasi: insieme
            return [giro(v, set() if isinstance(v, dict) else visti, chiave) for v in x]
        if isinstance(x, dict):
            return {k: (v if k in _SALTA else giro(v, visti, k)) for k, v in x.items()}
        return x
    nuovi = giro(dati, set())
    dati.clear()
    dati.update(nuovi)
    return mancano


def completa(dati, chiave, L="it"):
    """Appunti nuovi: le sigle spiegate dal programma; quelle che nessuno spiega si chiedono a Claude. Torna la spesa."""
    mancano = spiega(dati, L)
    if not mancano or not chiave:
        return 0.0
    import json
    import appunti as ap
    import chiedi as ch
    testo = json.dumps({k: v for k, v in dati.items() if k not in _SALTA}, ensure_ascii=False)[:20000]
    corpo = {"model": ap.MODELLO,          # Sonnet, come gli appunti (Paolo: niente Haiku) "max_tokens": 2000,
             "system": ("Ti do degli appunti e un elenco di sigle o abbreviazioni usate senza spiegazione. Per ognuna scrivi "
                        "per intero cosa vuol dire IN QUESTI APPUNTI, in poche parole (es. «LH» → «ormone luteinizzante»), in " +
                        ("italiano" if L == "it" else "the language of the notes") + ". Se una non e' una sigla o non sai cosa "
                        "vuol dire qui, lasciala fuori. Chiama lo strumento salva_sigle."),
             "tools": [{"name": "salva_sigle", "description": "Le sigle spiegate.", "input_schema": {
                 "type": "object", "properties": {"sigle": {"type": "array", "items": {"type": "object", "properties": {
                     "sigla": {"type": "string"}, "significato": {"type": "string"}}, "required": ["sigla", "significato"]}}},
                 "required": ["sigle"]}}],
             "tool_choice": {"type": "tool", "name": "salva_sigle"},
             "messages": [{"role": "user", "content": "SIGLE: " + ", ".join(sorted(mancano)) + "\n\nAPPUNTI:\n" + testo}]}
    try:
        r, usage = ch.strumento(chiave, corpo, "sigle", "ap_occupato")
    except Exception:
        log.exception("sigle")
        return 0.0
    extra = {}
    for v in r.get("sigle") or []:
        if isinstance(v, dict) and str(v.get("sigla") or "").strip() in mancano and _pulisci(v.get("significato")):
            extra[str(v["sigla"]).strip()] = _pulisci(v["significato"])
    if extra:
        if isinstance(dati.get("formulario"), list):        # restano anche nel formulario, per il ripasso
            gia = {str(x.get("simbolo") or "") for x in dati["formulario"] if isinstance(x, dict)}
            dati["formulario"] += [{"simbolo": k, "significato": v} for k, v in extra.items() if k not in gia]
        _rimetti(dati, extra, L)
    log.info("sigle: %d spiegate da Claude su %d", len(extra), len(mancano))
    try:
        return ch._costo(usage)
    except Exception:
        return 0.0


def _rimetti(dati, extra, L):
    spiega(dati, L, extra)
