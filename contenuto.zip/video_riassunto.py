"""«Video riassunto» (anteprima 65, 08/11/2026): la lezione (o tutta la materia) in 5-8 scene.

Claude (Sonnet: e' un riassunto, Paolo non vuole Haiku per gli appunti) sceglie le cose piu' importanti; per ognuna
una scena con un titolo, 2-4 punti brevi, quello che dice la voce narrante e, se c'e', la slide vera del prof.
La pagina lo fa vedere come un video (scena, voce, sottotitoli); sul PC si salva anche in MP4 (immagini fatte con
PIL, voce del sistema come il podcast in MP3, ffmpeg per unire). Si fa una volta sola: riaprirlo non costa."""
import base64
import hashlib
import io
import json
import logging
import os
import shutil
import subprocess
import tempfile
from pathlib import Path

import appunti as ap
import chiedi as ch
import elaborazione as el
import testi
from testi import tr

log = logging.getLogger("registra_lezione")

SCHEMA = {"type": "object", "properties": {"scene": {"type": "array", "items": {"type": "object", "properties": {
    "titolo": {"type": "string", "description": "titolo corto della scena (massimo 6 parole)"},
    "punti": {"type": "array", "items": {"type": "string"}, "description": "2-4 punti brevi da scrivere sullo schermo"},
    "voce": {"type": "string", "description": "quello che dice la voce narrante: 3-6 frasi chiare"},
    "slide": {"type": "integer", "description": "numero della slide da mostrare (dalla trascrizione), 0 se nessuna"},
    "lezione": {"type": "string", "description": "solo con piu' lezioni: L1, L2... la lezione della slide"},
    "disegno": {"type": "string", "description": "IN INGLESE: cosa disegnare per illustrare l'idea della scena (oggetti, metafora visiva, "
                "una frase); niente scritte, lettere, numeri o formule nel disegno"}},
    "required": ["titolo", "voce"]}}}, "required": ["scene"]}
V = 1          # cambia se cambia la forma delle scene


def _file(carts, base, materia):
    if materia:
        d = Path(base) / "video_materie"
        d.mkdir(parents=True, exist_ok=True)
        return d / f"{hashlib.sha1(str(materia).lower().encode()).hexdigest()[:12]}.json"
    return Path(carts[0]) / "video_riassunto.json"


def _img(cart, n):
    """La slide n di una lezione, piccola, come data URL (None se non c'e')."""
    try:
        from PIL import Image
        s = next((x for x in ch.slide_della_lezione(cart) if x["n"] == int(n or 0)), None)
        if not s:
            return None
        with Image.open(el.immagine_slide(cart, s["file"])) as im:
            im.thumbnail((1280, 720))
            b = io.BytesIO()
            im.convert("RGB").save(b, "JPEG", quality=82)
        return "data:image/jpeg;base64," + base64.b64encode(b.getvalue()).decode()
    except Exception:
        log.exception("video riassunto: slide")
        return None


def crea(carts, chiave, base, materia=None, rifai=False):
    """Torna (dati, usage). dati = {"scene": [{titolo, punti, voce, img, cartella}], "titolo", "lingua"}."""
    carts = [Path(c) for c in carts if Path(c).is_dir()]
    if not carts:
        raise ap.ErroreAppunti(tr("vr_err"))
    carts.sort(key=lambda c: str((el.leggi_json(c / "info.json", {}) or {}).get("inizio") or c.name))
    info = el.leggi_json(carts[0] / "info.json", {}) or {}
    L = testi.lingua_di(info)
    firma = sorted(c.name for c in carts)
    f = _file(carts, base, materia)
    vecchio = el.leggi_json(f, {}) or {}
    if not rifai and vecchio.get("v") == V and vecchio.get("firma") == firma and vecchio.get("scene"):
        illustra(vecchio, f)
        return vecchio, {}
    if not chiave:
        raise ap.ErroreAppunti(tr("manca_chiave"))
    piu = len(carts) > 1
    if piu:
        per = 180_000 // len(carts)
        testo = "\n\n".join(f"=== L{i}: {(el.leggi_json(c / 'info.json', {}) or {}).get('nome', c.name)} ===\n" + ch.testo_lezione(c)[:per]
                             for i, c in enumerate(carts, 1))
    else:
        testo = ch.testo_lezione(carts[0])[:180_000]
    corpo = {"model": ap.MODELLO, "max_tokens": 6000,
             "system": ap.CHIARO_VOCE + " Prepara un VIDEO RIASSUNTO " +
                       (f"di TUTTA LA MATERIA «{materia}» ({len(carts)} lezioni: collegale fra loro)" if piu else "di questa lezione") +
                       " di circa 5 minuti: da 5 a 8 scene, nell'ordine della lezione. La prima presenta di cosa si parla, "
                       "l'ultima dice cosa sapere per l'esame. Ogni scena: titolo corto, 2-4 punti brevi da leggere sullo schermo, "
                       "quello che dice la voce narrante (seconda persona, tono amichevole, solo cose della lezione), «disegno» = in inglese, cosa disegnare per far capire l'idea con un'immagine (senza scritte) e, quando "
                       "il docente mostra una slide su quel punto, il suo numero (\"--- Slide N ---\" nella trascrizione)"
                       + ("; \"lezione\" = L1, L2... la lezione della slide" if piu else "") +
                       ". Scrivi in " + testi.nome_lingua(L, "it") + ". Chiama lo strumento salva_video.",
             "tools": [{"name": "salva_video", "description": "Salva il video riassunto.", "input_schema": SCHEMA}],
             "messages": [{"role": "user", "content": "TRASCRIZIONE CON GLI ORARI E LE SLIDE:\n" + testo}]}
    d, uso = ch.strumento(chiave, corpo, "scene", "vr_err")
    tutti = {f"L{i}": c for i, c in enumerate(carts, 1)}
    scene = []
    for s in d["scene"][:10]:
        voce = str(s.get("voce") or "").strip()
        if not voce:
            continue
        cart = tutti.get(str(s.get("lezione") or "").strip().upper().replace(" ", ""), carts[0]) if piu else carts[0]
        img = _img(cart, s.get("slide")) if s.get("slide") else None
        scene.append({"titolo": str(s.get("titolo") or "").strip()[:80],
                      "punti": [str(p).strip()[:140] for p in (s.get("punti") or []) if str(p).strip()][:4],
                      "voce": voce[:1500], "img": img, "slide": int(s.get("slide") or 0) if img else 0,
                      "disegno": str(s.get("disegno") or "").strip()[:600],
                      "cartella": str(cart)})
    if not scene:
        raise ap.ErroreAppunti(tr("vr_err"))
    out = {"v": V, "firma": firma, "scene": scene, "lingua": L, "titolo": materia or info.get("nome") or carts[0].name}
    illustra(out)
    el.scrivi_json(f, out)
    return out, uso


# --------------------------------------------------------------------------- MP4 (sul PC)

# --------------------------------------------------------------------------- immagini dell'IA (anteprima 70)

RITENTA = 24 * 3600          # se il servizio non c'era, si riprova dopo un giorno


def _disegna(prompt):
    """Un'immagine dal sito (Cloudflare Workers AI, con l'accesso Google). Torna data URL o None."""
    if os.environ.get("RL_IMMAGINE_FINTA"):          # prove sul simulatore: un disegno finto, senza internet
        cart_f = Path(os.environ["RL_IMMAGINE_FINTA"])
        if cart_f.is_dir() and list(cart_f.glob("*.jpg")):     # i disegni d'esempio dell'anteprima (video della guida)
            fs = sorted(cart_f.glob("*.jpg"))
            return "data:image/jpeg;base64," + base64.b64encode(fs[int(hashlib.sha1(prompt.encode()).hexdigest()[:6], 16) % len(fs)].read_bytes()).decode()
        from PIL import Image, ImageDraw
        im = Image.new("RGB", (512, 384), (19, 40, 63))
        d = ImageDraw.Draw(im)
        h = int(hashlib.sha1(prompt.encode()).hexdigest()[:6], 16)
        d.ellipse([140, 80, 372, 312], outline=(125, 211, 252), width=8)
        d.line([60, 330 - h % 200, 452, 60 + h % 200], fill=(251, 191, 36), width=10)
        b = io.BytesIO()
        im.save(b, "JPEG", quality=80)
        return "data:image/jpeg;base64," + base64.b64encode(b.getvalue()).decode()
    try:
        import licenza as lic
        token = ap.LICENZA.token() if ap.LICENZA is not None else None
        if not token:
            return None
        import urllib.request, ssl
        req = urllib.request.Request(lic.SITO + "/api/immagine", data=json.dumps({"prompt": prompt}).encode(), method="POST",
                                     headers={"content-type": "application/json", "X-VM-Google": token, "User-Agent": "VerbaManentIA"})
        with urllib.request.urlopen(req, timeout=60, context=ssl.create_default_context()) as r:
            img = json.loads(r.read().decode() or "{}").get("img")
        return img if str(img or "").startswith("data:image/") else None
    except Exception as e:
        log.info("video riassunto: immagine non fatta (%s)", e)
        return None


def illustra(dati, f=None):
    """Mette un'immagine dell'IA in ogni scena che non ce l'ha. Se il servizio non risponde il video resta com'e'
    (solo slide e punti) e si riprova dopo un giorno. Torna True se ha aggiunto qualcosa."""
    import time
    from concurrent.futures import ThreadPoolExecutor
    if time.time() - float(dati.get("ia_t") or 0) < RITENTA and not os.environ.get("RL_IMMAGINE_FINTA"):
        return False
    manca = [s for s in dati.get("scene") or [] if not s.get("ia")]
    if not manca:
        return False
    def una(s):
        p = s.get("disegno") or (s.get("titolo", "") + ": " + "; ".join(s.get("punti") or []))
        s["ia"] = _disegna(p[:1000]) or ""
    with ThreadPoolExecutor(4) as ex:
        list(ex.map(una, manca))
    fatte = sum(1 for s in manca if s.get("ia"))
    if fatte < len(manca):
        dati["ia_t"] = time.time()
    if f is not None:
        el.scrivi_json(f, dati)
    return fatte > 0


def _font(grande, bold):
    from PIL import ImageFont
    windir = Path(os.environ.get("WINDIR", r"C:\Windows"))
    for p in ((windir / "Fonts" / ("arialbd.ttf" if bold else "arial.ttf")),
              el.CARTELLA_FONT / ("DejaVuSans-Bold.ttf" if bold else "DejaVuSans.ttf"),
              Path("/System/Library/Fonts/Supplemental/Arial Bold.ttf" if bold else "/System/Library/Fonts/Supplemental/Arial.ttf")):
        if p.exists():
            return ImageFont.truetype(str(p), grande)
    return ImageFont.load_default()


def _a_capo(draw, testo, font, larg):
    righe, r = [], ""
    for w in str(testo).split():
        prova = (r + " " + w).strip()
        if draw.textlength(prova, font=font) > larg and r:
            righe.append(r)
            r = w
        else:
            r = prova
    if r:
        righe.append(r)
    return righe


def _fotogramma(s, dest, n, tot):
    from PIL import Image, ImageDraw
    W, H = 1280, 720
    im = Image.new("RGB", (W, H), (11, 27, 46))
    d = ImageDraw.Draw(im)
    ft, fp, fn = _font(44, True), _font(30, False), _font(22, False)
    ia = s.get("ia")
    WL = 700 if ia else W                    # con l'immagine dell'IA: slide o punti a sinistra, immagine a destra
    if ia:
        try:
            with Image.open(io.BytesIO(base64.b64decode(ia.split(",", 1)[1]))) as x:
                x = x.convert("RGB")
                x.thumbnail((W - WL - 60, H - 200))
                im.paste(x, (WL + 20 + (W - WL - 60 - x.width) // 2, 120 + (H - 200 - x.height) // 2))
        except Exception:
            log.exception("video riassunto: immagine IA nel fotogramma")
    if s.get("img"):
        with Image.open(io.BytesIO(base64.b64decode(s["img"].split(",", 1)[1]))) as sl:
            sl = sl.convert("RGB")
            sl.thumbnail((WL - 120, H - 170))
            x, y = (WL - sl.width) // 2 if ia else (W - sl.width) // 2, 110 + (H - 170 - sl.height) // 2
            im.paste(sl, (x, y))
        d.text((60, 40), s["titolo"], font=ft, fill=(255, 255, 255))
    else:
        y = 150
        for r in _a_capo(d, s["titolo"], ft, WL - 160)[:2]:
            d.text((80, y), r, font=ft, fill=(255, 255, 255))
            y += 60
        y += 30
        for p in s.get("punti") or []:
            for i, r in enumerate(_a_capo(d, p, fp, WL - 200)[:2]):
                d.text((100, y), ("•  " if i == 0 else "    ") + r, font=fp, fill=(219, 231, 243))
                y += 44
            y += 10
    d.text((W - 110, H - 50), f"{n}/{tot}", font=fn, fill=(148, 163, 184))
    im.save(dest)


def mp4(dati, dest, velocita=1.0):
    """Il video riassunto in MP4 (solo PC: la voce del sistema la fanno Windows e Mac)."""
    import podcast as pc
    ff = el.ffmpeg_exe()
    tmp = Path(tempfile.mkdtemp(prefix="vmia_vr_"))
    try:
        pezzi = []
        for i, s in enumerate(dati["scene"], 1):
            png, wav, mp = tmp / f"s{i}.png", tmp / f"s{i}.wav", tmp / f"s{i}.mp4"
            _fotogramma(s, png, i, len(dati["scene"]))
            if not pc._voce_su_file(s["voce"], wav, dati.get("lingua", "it"), velocita, 0):
                raise RuntimeError("voce")
            r = subprocess.run([ff, "-y", "-loglevel", "error", "-loop", "1", "-i", str(png), "-i", str(wav), "-c:v", "libx264",
                                "-tune", "stillimage", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "128k", "-af", "apad=pad_dur=0.8",
                                "-shortest", str(mp)], creationflags=el.NO_WINDOW, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
            if r.returncode != 0:
                raise RuntimeError("ffmpeg scena: " + r.stderr.decode("utf-8", "replace")[-300:])
            pezzi.append(mp)
        elenco = tmp / "elenco.txt"
        elenco.write_text("".join(f"file '{p.as_posix()}'\n" for p in pezzi), encoding="utf-8")
        Path(dest).parent.mkdir(parents=True, exist_ok=True)
        r = subprocess.run([ff, "-y", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", str(elenco), "-c", "copy", str(dest)],
                           creationflags=el.NO_WINDOW, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        if r.returncode != 0:
            raise RuntimeError("ffmpeg unisci: " + r.stderr.decode("utf-8", "replace")[-300:])
        return Path(dest)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def json_per_pagina(dati):
    return json.loads(json.dumps(dati))
