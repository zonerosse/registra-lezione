/* Le guide interattive (anteprima 09, approvata da Paolo il 25/10/2026; come nel gestionale dell'allevamento).
   - Anteprima 11 (26/10/2026, come nel gestionale): in cima a ogni pagina la fascia con l'interruttore «Guida» sempre in vista
     (acceso di partenza, si ricorda nel dispositivo) e un solo «Guidami» che apre l'elenco delle guide della pagina
     (passi, «fatta», «Avvia») e «Tutte le guide».
   - Ogni guida: prima «A cosa serve», poi un punto alla volta illuminato da toccare, con il «Perché»; va avanti da sola
     quando il passo e' fatto (ok()), e alla fine un riepilogo. Si esce quando si vuole.
   Una funzione nuova importante = una guida nuova qui (GUIDE). */
'use strict';
// inglese (28/10/2026): le guide si traducono qui sotto, frase per frase (GD_EN); le scritte della guida con gl(it, en)
const gdEN = () => typeof LINGUA !== 'undefined' && LINGUA === 'en';
const gt = s => (gdEN() && GD_EN[s]) || s;
const gl = (it, en) => gdEN() ? en : it;
const gdOn = () => { try { return localStorage.getItem('vm_guida') !== '0'; } catch (e) { return true; } };
const gdTel = () => typeof ANDROID !== 'undefined' && ANDROID;
const gdWeb = () => document.documentElement.classList.contains('web');
const gdSM = () => typeof SCRIPTA !== 'undefined' && SCRIPTA;
function gdVis(sel) {
  for (const e of document.querySelectorAll(sel)) {
    const r = e.getBoundingClientRect();
    if (r.width > 0 && r.height > 0 && getComputedStyle(e).visibility !== 'hidden') return e;
  }
  return null;
}
const gdNav = p => gdVis(`#nav a[data-p="${p}"]`) || gdVis(`[data-p="${p}"]`);
const gdLez = () => (typeof LZ !== 'undefined' && LZ && LZ.lezioni) ? LZ.lezioni.length : 0;
const gdTile = a => gdVis(`#v-lezione .tile[data-ta="${a}"]`) || gdVis(`.tile[data-ta="${a}"]`);
// passi che si ripetono in tante guide
const P = {
  reg: {t: 'Apri «Registra»', p: 'Tocca «Registra» nel menu.', w: 'Da Registra partono le lezioni nuove e si importa quello che hai già.',
        el: () => gdNav('reg'), ok: () => pagina === 'reg'},
  arch: {t: 'Apri le tue lezioni', p: 'Tocca «Lezioni» nel menu.', w: 'Ogni cosa che riguarda una lezione (appunti, mappa, domande…) si fa dalla sua pagina.',
         el: () => gdNav('arch'), ok: () => pagina !== 'arch' ? ['lezione', 'chiedi', 'mappa', 'ascolta', 'rip', 'karaoke', 'podcast'].includes(pagina) : true},
  lez: {t: 'Apri una lezione', p: 'Tocca una lezione dell\'elenco: se è dentro una cartella, prima tocca la cartella (se non ce n\'è ancora una, prima registrane o importane una).', w: 'Gli strumenti di studio sono nella pagina della lezione.',
        el: () => gdVis('#lista .lez.apri') || gdVis('.sml-r.apri') || gdVis('#lista .cart'), ok: () => pagina !== 'arch'},
  imp: {t: 'Apri «Impostazioni»', p: 'Tocca «Impostazioni» nel menu.', w: 'Qui ci sono i collegamenti tra PC, telefono e cloud.',
        el: () => gdNav('imp'), ok: () => pagina === 'imp' || pagina === 'sy'},
  studia: {t: 'Apri «Studia»', p: 'Tocca «Studia» nel menu.', w: 'In Studia ogni materia ha la sua pagina: date d\'esame, libro, ripasso.',
           el: () => gdNav('studia'), ok: () => pagina === 'studia' || pagina === 'lb' || pagina === 'esame'},
  materia: {t: 'Apri la materia', p: 'Tocca la materia che vuoi (es. «Analisi 1»).', w: 'Libro e date valgono per tutta la materia, non per una sola lezione.',
            el: () => gdVis('#stMat [data-m]') || gdVis('#v-studia [data-m]'), ok: () => !!gdVis('[data-sa]') || pagina === 'lb' || pagina === 'esame'},
};
const GUIDE = {
  aula: {n: 'Registra in aula', solo: () => !gdWeb(),
    why: {h: 'Registra una lezione in aula', p: 'Il telefono o il PC ascolta il docente dal microfono; alla fine trascrive la lezione e prepara gli appunti da solo.',
          uses: ['Avere tutta la lezione scritta, anche quello che non hai fatto in tempo ad annotare', 'Appunti, mappa, flashcard e domande pronte per studiare'],
          tm: 'Prima chiedi al docente il permesso di registrare.'},
    S: [P.reg,
        {t: 'Scegli «Lezione»', p: 'In alto, il primo riquadro.', w: 'Così gli appunti sono quelli di una lezione: Cornell o Formato Esame, flashcard e domande.',
         el: () => gdVis('#tipoBox [data-k="lezione"]'), ok: () => !gdVis('#tipoBox') || (R && (R.tipo || 'lezione') === 'lezione' && gdVis('#tipoBox [data-k="lezione"].on'))},
        {t: 'Scegli «In aula»', p: 'Il docente è lì davanti: registro dal microfono.', w: 'In aula conta solo il microfono; online servono anche schermo e audio del PC.',
         el: () => gdVis('#qkDove [data-m="aula"]') || gdVis('#doveBox [data-m="aula"]'),
         ok: () => (!gdVis('#qkDove') && !gdVis('#doveBox')) || !!document.querySelector('#doveBox [data-m="aula"].on')},
        {t: 'Scrivi la materia', p: 'Per esempio «Analisi 1».', w: 'Le lezioni della stessa materia finiscono insieme in Studia, con le date d\'esame e il ripasso.',
         el: () => gdVis('#materia'), ok: () => { const m = gdVis('#materia'); return !m || m.value.trim().length > 1; }},
        {t: 'Tocca «Registra»', p: 'Appoggia il telefono vicino al docente.', w: 'Da qui registro: puoi mettere il telefono in tasca o spegnere lo schermo.',
         el: () => gdVis('#btnRec'), ok: () => !!(S && S.registro)}],
    done: () => !!(S && S.registro),
    end: 'Sto registrando. Quando il docente finisce tocca «Fine»: la trascrizione e gli appunti arrivano da soli, li trovi in «Lezioni».'},
  online: {n: 'Registra online', solo: () => !gdTel() && !gdWeb(),
    why: {h: 'Registra una lezione online', p: 'Meet, Teams, Zoom: registro l\'audio e fotografo le slide dallo schermo del PC.',
          uses: ['Gli appunti con le slide al punto giusto', 'Anche se ti distrai, la lezione resta tutta'], tm: 'Apri prima la lezione online, poi torna qui.'},
    S: [P.reg,
        {t: 'Scegli «Online»', p: 'Il secondo riquadro.', w: 'Online registro schermo e audio del PC, non il microfono.',
         el: () => gdVis('#qkDove [data-m="online"]') || gdVis('#doveBox [data-m="online"]'), ok: () => !!document.querySelector('#doveBox [data-m="online"].on')},
        {t: 'Scrivi la materia', p: 'Per esempio «Diritto privato».', w: 'Così la lezione finisce nella materia giusta.',
         el: () => gdVis('#materia'), ok: () => { const m = gdVis('#materia'); return !m || m.value.trim().length > 1; }},
        {t: 'Tocca «Registra»', p: 'Lascia aperta la finestra della lezione online.', w: 'Il programma si mette piccolo in un angolo e lavora mentre segui.',
         el: () => gdVis('#btnRec'), ok: () => !!(S && S.registro)}],
    done: () => !!(S && S.registro),
    end: 'Sto registrando. Alla fine tocca «Fine»: appunti e slide arrivano da soli in «Lezioni».'},
  testo: {n: 'Importa un PDF', solo: () => !gdWeb(),
    why: {h: 'Importa un PDF e fanne gli appunti', p: 'Hai già un PDF (dispense, una tesi, la trascrizione di una lezione)? Il programma lo legge e ne fa gli appunti, come se fosse una lezione registrata.',
          uses: ['Studiarlo con mappa, flashcard e domande', 'Chiedere a Claude cosa vuol dire un punto', 'Ritrovarlo su PC e telefono'],
          tm: 'Il PDF deve avere il testo vero (non foto di pagine). Ci vogliono pochi minuti e qualche centesimo.'},
    S: [P.reg,
        {t: 'Tocca «Importa un file…»', p: 'Il riquadro blu sotto REGISTRA. Poi scegli «Uno o più testi» (sul telefono «Un testo») e il PDF.', w: 'Da qui entrano nel programma le cose che non hai registrato tu: anche più file o una cartella intera, ogni file diventa una lezione.',
         el: () => gdVis('#qkImpB') || gdVis('#btnImportaTesto'), ok: () => typeof IT !== 'undefined' && !!IT},
        {t: 'Scrivi il nome della lezione', p: 'Per esempio «Riproduzione del cane».', w: 'Con questo nome la ritrovi in Lezioni e in Studia.',
         el: () => gdVis('#itNome'), ok: () => { const i = gdVis('#itNome'); return !i || i.value.trim().length > 2; }},
        {t: 'Tocca «Crea gli appunti»', p: 'Con più file il tasto dice quante lezioni. Sul tasto gira la rotella finché non ha finito di partire.', w: 'Claude scrive gli appunti; poi trovi anche mappa e flashcard.',
         el: () => gdVis('#itVai'), ok: () => gdLez() > GD.base.lez}],
    done: () => gdLez() > GD.base.lez,
    end: 'Fatto! La lezione è in «Lezioni»: quando gli appunti sono pronti aprila per leggerli, con la mappa e le flashcard.'},
  video: {n: 'Importa audio o video', solo: () => !gdWeb(),
    why: {h: 'Importa un audio o un video', p: 'Una lezione registrata con un\'altra app, un vocale lungo, il video di una lezione: lo trascrivo e ne faccio gli appunti.',
          uses: ['Non perdere le lezioni registrate prima', 'Appunti anche dai video delle lezioni'], tm: 'Più è lungo, più ci mette a trascrivere.'},
    S: [P.reg,
        {t: 'Tocca «Importa un file…»', p: 'Il riquadro blu sotto REGISTRA. Poi scegli «Un video o un audio» e il file.', w: 'Il file originale resta dov\'è: ne faccio una copia.',
         el: () => gdVis('#qkImpB') || gdVis('#btnImporta'), ok: () => typeof IV !== 'undefined' && !!IV},
        {t: 'Scrivi il nome della lezione', p: 'Il nome con cui la ritroverai.', w: 'Come per le lezioni registrate: nome e materia.',
         el: () => gdVis('#ivNome'), ok: () => { const i = gdVis('#ivNome'); return !i || i.value.trim().length > 2; }},
        {t: 'Tocca «Importa»', p: 'Parte la trascrizione.', w: 'Quando finisce arrivano gli appunti, come per una lezione registrata.',
         el: () => gdVis('#ivVai'), ok: () => gdLez() > GD.base.lez}],
    done: () => gdLez() > GD.base.lez,
    end: 'La lezione è in «Lezioni»: la trascrizione va avanti da sola, poi arrivano gli appunti.'},
  sync: {n: 'PC e telefono insieme', solo: () => !gdWeb(),
    why: {h: 'Le stesse lezioni su PC e telefono', p: 'Con Google Drive: entri con lo stesso account Google sul PC e sul telefono, e basta. Niente codici né QR: le lezioni, gli appunti e il ripasso sono gli stessi da tutte e due le parti, anche quando siete lontani.',
          uses: ['Registri col telefono e studi sul PC (o il contrario)', 'Anche fuori casa e con i dati del telefono', 'La password delle lezioni arriva da sola'], tm: 'Serve un account Google (quello di Gmail va benissimo). La stessa cosa va fatta sul PC e sul telefono.'},
    S: [P.imp,
        {t: 'Tocca «Apri» in «Sincronizza»', p: 'È il primo riquadro in alto: dice se PC e telefono sono già collegati.', w: 'Qui c\'è tutto quello che collega i tuoi dispositivi.',
         el: () => gdVis('#syApri'), ok: () => pagina === 'sy'},
        {t: 'Tocca «Accedi con Google»', p: 'Si apre la pagina di Google: entra con il tuo account e dai il permesso.', w: 'Verba Manent usa solo una cartella sua nel tuo Drive, con le lezioni chiuse da una password. ' + (gdTel() ? 'Se sul PC hai già fatto lo stesso, la password arriva da sola.' : 'Poi fai lo stesso sul telefono, con lo stesso account.'),
         el: () => gdVis('#nvAcc'), ok: () => !!(typeof NV !== 'undefined' && NV.d && NV.d.attiva)}],
    done: () => !!(typeof NV !== 'undefined' && NV.d && NV.d.attiva),
    end: gdTel() ? 'Collegati! Le lezioni del PC arrivano da sole sul telefono, e quelle del telefono sul PC.' : 'Collegato! Ora fai «Accedi con Google» anche sul telefono, con lo stesso account: le lezioni passano da sole.'},
  chiedi: {n: 'Chiedi alla lezione',
    why: {h: 'Fai una domanda sulla lezione', p: 'Non hai capito un punto? Chiedilo: risponde Claude, usando solo quello che è stato detto a lezione.',
          uses: ['Farti rispiegare un passaggio', 'Sapere se una cosa è stata detta o no'], tm: 'Meno di un centesimo a domanda.'},
    S: [P.arch, P.lez,
        {t: 'Tocca «Chiedi alla lezione»', p: 'Uno dei riquadri della lezione.', w: 'Le domande valgono per questa lezione (o per tutta la materia).',
         el: () => gdTile('chiedi'), ok: () => pagina === 'chiedi'},
        {t: 'Scrivi la domanda', p: 'Per esempio «Cos\'è un limite notevole?».', w: 'Più è precisa, migliore è la risposta.',
         el: () => gdVis('#chIn'), ok: () => { const i = gdVis('#chIn'); return pagina === 'chiedi' && (!i || i.value.trim().length > 4 || document.querySelectorAll('#chat > *').length > GD.base.chat); }},
        {t: 'Tocca «Chiedi»', p: 'La risposta arriva in pochi secondi.', w: 'Le risposte restano: puoi rileggerle dopo.',
         el: () => gdVis('#chVai'), ok: () => document.querySelectorAll('#chat > *').length > GD.base.chat}],
    done: () => pagina === 'chiedi' && document.querySelectorAll('#chat > *').length > GD.base.chat,
    end: 'Ecco la risposta. Puoi continuare a chiedere: «Nuova conversazione» ricomincia da capo.'},
  mappa: {n: 'La mappa',
    why: {h: 'La mappa della lezione', p: 'Tutta la lezione in una pagina: il tema al centro e i rami con le cose da sapere.',
          uses: ['Ripassare in due minuti', 'Ascoltarla ramo per ramo', 'Modificarla o costruirla tu'], tm: 'La prima volta Claude ci mette qualche secondo a prepararla.'},
    S: [P.arch, P.lez,
        {t: 'Tocca «Mappa»', p: 'Uno dei riquadri della lezione.', w: 'Ogni lezione ha la sua mappa.',
         el: () => gdTile('mappa'), ok: () => pagina === 'mappa'},
        ...(gdTel() ? [{t: 'Tocca «Grafica»', p: 'La mappa intera, con le linee: ingrandisci con due dita.', w: 'Sul telefono «Guarda» la mostra a elenco, più comoda da leggere; «Grafica» la mostra come sul PC.',
                        el: () => gdVis('#mpModi [data-m="graf"]'), ok: () => typeof MP !== 'undefined' && MP.modo === 'graf'}] : []),
        {t: 'Tocca l\'altoparlante di un ramo', p: 'Senti il ramo letto ad alta voce.', w: 'Ascoltare aiuta a ricordare.',
         el: () => gdVis('#mpBox .mp-ic'), ok: () => GD.clk.has('senti')}],
    done: () => GD.clk.has('senti'),
    end: 'Con «Modifica» la cambi, con «Costruiscila tu» la rifai da solo per allenarti; «Stampa o PDF» la salva.'},
  ripasso: {n: 'Le flashcard',
    why: {h: 'Ripassa con le flashcard', p: 'Domande e risposte prese dalla lezione: tu provi a rispondere, poi giri la carta e dici se la sapevi.',
          uses: ['Ricordare a lungo (te le ripropongo quando stai per dimenticarle)', 'Prepararti all\'esame poco alla volta'], tm: 'Bastano pochi minuti al giorno.'},
    S: [P.arch, P.lez,
        {t: 'Tocca «Flashcard»', p: 'Il riquadro con le carte.', w: 'Le carte sono di questa lezione; in Studia trovi il ripasso di tutta la materia.',
         el: () => gdTile('ripassa'), ok: () => pagina === 'rip'},
        {t: 'Prova a rispondere, poi gira la carta', p: 'Tocca la carta per vedere la risposta.', w: 'Lo sforzo di ricordare è quello che fa imparare.',
         el: () => gdVis('#v-rip .carta') || gdVis('#v-rip button'), ok: () => pagina === 'rip' && GD.clk.size > 0}],
    done: () => pagina === 'rip' && GD.clk.size > 0,
    end: 'Dì se la sapevi: quelle che non sapevi tornano prima. Il «Ripasso del giorno» in Studia te le ripropone da solo.'},
  ascolta: {n: 'Ascolta gli appunti',
    why: {h: 'Ascolta gli appunti', p: 'Una voce ti legge gli appunti della lezione, con la parola che senti evidenziata.',
          uses: ['Ripassare mentre cammini o sei in macchina', 'Leggere meno fatica (utile con un DSA)'], tm: 'Puoi scegliere la velocità.'},
    S: [P.arch, P.lez,
        {t: 'Tocca «Ascolta»', p: 'Il riquadro con l\'altoparlante.', w: 'Legge gli appunti di questa lezione.',
         el: () => gdTile('ascolta'), ok: () => pagina === 'ascolta'},
        {t: 'Tocca «Leggi»', p: 'Parte la voce.', w: 'Puoi fermarla e riprendere quando vuoi.',
         el: () => gdVis('#asPlay'), ok: () => typeof AS !== 'undefined' && !!AS.attivo}],
    done: () => typeof AS !== 'undefined' && !!AS.attivo,
    end: 'Sta leggendo. Con la velocità sotto la rallenti o la acceleri; con «Modalità DSA» il testo diventa più facile da leggere.'},
  libro: {n: 'Il libro della materia', solo: () => !gdWeb(),
    why: {h: 'Aggiungi il libro di testo', p: 'Il PDF del libro (o le dispense) di una materia: per ogni lezione ti dico le pagine giuste e cosa a lezione non si è detto.',
          uses: ['Sapere cosa studiare sul libro dopo ogni lezione', 'Non perdere le parti che il prof ha saltato'], tm: 'Il libro resta sul tuo dispositivo: non va su internet.'},
    S: [P.studia, P.materia,
        {t: 'Tocca «Libro»', p: 'Nella pagina della materia, il riquadro del libro.', w: 'Il libro vale per tutte le lezioni della materia.',
         el: () => gdVis('[data-sa="libro"]') || gdVis('[data-sa="lb"]'), ok: () => pagina === 'lb'},
        {t: 'Tocca «Scegli il PDF del libro»', p: 'Si apre l\'elenco dei file: scegli il PDF.', w: 'Lo leggo qui sul tuo dispositivo, una volta sola.',
         el: () => gdVis('#lbScegli') || gdVis('#lbDisp'), ok: () => GD.clk.size > 0 && !!gdVis('#lbCambia')}],
    done: () => pagina === 'lb' && !!gdVis('#lbCambia'),
    end: 'Il libro è collegato: nella pagina di ogni lezione trovi le pagine da studiare.'},
  esame: {n: 'Data d\'esame e piano',
    why: {h: 'La data dell\'esame e il piano di studio', p: 'Scrivi quando hai l\'esame: ti preparo un piano giorno per giorno e il ripasso si regola da solo.',
          uses: ['Sapere ogni giorno cosa ripassare', 'Arrivare all\'esame senza ansia dell\'ultimo momento'], tm: 'La data si può cambiare quando vuoi.'},
    S: [P.studia, P.materia,
        {t: 'Tocca «Data d\'esame» o «Piano»', p: 'Nella pagina della materia, in alto.', w: 'Il piano dipende dalla data.',
         el: () => gdVis('[data-sa="piano"]'), ok: () => pagina === 'esame'},
        {t: 'Scegli la data dell\'esame', p: 'Tocca la casella della data.', w: 'Da qui calcolo quanti giorni hai.',
         el: () => gdVis('#esData'), ok: () => { const d = gdVis('#esData'); return !!(d && d.value); }}],
    done: () => pagina === 'esame' && !!(gdVis('#esData') || {}).value,
    end: 'Fatto: nel piano vedi cosa fare ogni giorno, e in Studia il conto alla rovescia.'},
  cloud: {n: 'Copia nel cloud', solo: () => !gdTel() && !gdWeb(),
    why: {h: 'Una copia delle lezioni nel cloud', p: 'Ogni lezione pronta va anche nel tuo Google Drive o OneDrive: la ritrovi dal telefono o da un altro computer.',
          uses: ['Non perdere le lezioni se il PC si rompe', 'Leggere gli appunti dal telefono'], tm: 'Si imposta una volta sola.'},
    S: [P.imp,
        {t: 'In «Copia nel cloud» tocca «Apri…»', p: 'Il riquadro con la nuvola.', w: 'Lì scegli dove copiare e cosa.',
         el: () => gdVis('#clApri'), ok: () => pagina !== 'imp'}],
    done: () => pagina !== 'imp' && pagina !== 'sy' && GD.clk.size > 0,
    end: 'Scegli Google Drive o OneDrive, spunta cosa copiare e tocca «Copia anche le lezioni già fatte».'},
};
// le guide che ogni pagina propone con i tasti «Guidami»
const GD_PAGINE = {reg: ['aula', 'online', 'testo', 'video'], arch: ['chiedi', 'mappa', 'ripasso', 'ascolta'], lezione: ['chiedi', 'mappa', 'ripasso', 'ascolta'],
                   studia: ['esame', 'libro', 'testo'], imp: ['sync', 'cloud'], guida: Object.keys(GUIDE), dsa: ['ascolta', 'mappa', 'ripasso']};
const GD = {g: null, i: -2, t: 0, clk: new Set(), base: {}, giri: 0};
const gdGuide = p => (GD_PAGINE[p] || []).filter(k => GUIDE[k] && (!GUIDE[k].solo || GUIDE[k].solo()));

// la fascia in cima a ogni pagina (anteprima 11, 26/10/2026, come nel gestionale): a sinistra un solo «Guidami» con le guide
// di quella pagina, a destra l'interruttore «Guida» sempre in vista (verde quando e' accesa)
const GD_NOMI = {reg: 'Registra', arch: 'Lezioni', lezione: 'Lezione', studia: 'Studia', imp: 'Impostazioni', dsa: 'Modalità DSA', guida: 'Guida'};
const gdFatte = () => { try { return JSON.parse(localStorage.getItem('vm_gd_fatte') || '[]'); } catch (e) { return []; } };
function gdFatta(k) { try { const L = gdFatte(); if (!L.includes(k)) localStorage.setItem('vm_gd_fatte', JSON.stringify(L.concat([k]))); } catch (e) {} }
function gdDecora() {
  if (typeof pagina === 'undefined' || !pagina) return;
  const on = gdOn(), ks = gdGuide(pagina), firma = `${pagina}|${on ? 1 : 0}|${ks.length ? 1 : 0}|${gdEN() ? 'en' : 'it'}`;
  document.querySelectorAll('.gd-tb').forEach(r => { if (r.dataset.f !== firma || r.closest('section.pg.hidden')) r.remove(); });
  document.querySelectorAll('.gd-riga, #gdCard').forEach(r => r.remove());
  const sez = document.querySelector('section.pg:not(.hidden)');
  if (!sez || sez.querySelector(':scope > .gd-tb')) return;
  const h = `<div class="gd-tb" data-f="${firma}">${on && ks.length ? `<button class="btn gd-b" type="button" data-gdm="1">${gl('Guidami', 'Guide me')}</button>` : ''}<span class="gd-sp"></span>`
    + `<button class="gd-tg${on ? ' on' : ''}" type="button" data-gdsw="1" title="${on ? gl('Guida accesa: tocca per spegnerla', 'Guide on: tap to turn it off') : gl('Guida spenta: tocca per accenderla', 'Guide off: tap to turn it on')}"><b>${gl('Guida', 'Guide')}</b><small>${on ? gl('accesa', 'on') : gl('spenta', 'off')}</small><span class="gd-sw"></span></button></div>`;
  sez.insertAdjacentHTML('afterbegin', h);
}
function gdInterruttore() {
  const on = !gdOn();
  try { if (on) localStorage.removeItem('vm_guida'); else localStorage.setItem('vm_guida', '0'); } catch (e) {}
  if (!on) gdFerma();
  gdDecora();
  toast(on ? gl('Guida accesa: ecco il tasto «Guidami».', 'Guide on: here is the «Guide me» button.') : gl('Guida spenta: il tasto «Guidami» non c\'è più.', 'Guide off: the «Guide me» button is gone.'));
}
function gdChiudiElenco() { const v = document.getElementById('gdVelo'); if (v) v.remove(); }
function gdElenco(html) {
  gdChiudiElenco();
  const v = document.createElement('div'); v.id = 'gdVelo'; v.className = 'gd-velo';
  v.innerHTML = `<div class="gd-sheet" role="dialog">${html}</div>`;
  v.onclick = e => { if (e.target === v) gdChiudiElenco(); };
  document.body.append(v);
}
const gdRiga = (k, fatte) => `<div class="gd-li"><span><b>${esc(gt(GUIDE[k].n))}</b><small>${GUIDE[k].S.length} ${gl('passi', 'steps')}</small></span>${fatte.includes(k) ? `<span class="gd-dn">${gl('fatta', 'done')}</span>` : ''}<button class="btn b-sm ${fatte.includes(k) ? 'b-ghost' : 'b-main'}" type="button" data-gd="${k}">${gl('Avvia', 'Start')}</button></div>`;
function gdTutteK() { const v = new Set(); for (const p of ['reg', 'arch', 'studia', 'imp', 'dsa']) gdGuide(p).forEach(k => v.add(k)); return [...v]; }
function gdMenu() {
  const ks = gdGuide(pagina), F = gdFatte();
  gdElenco(`<h3>${gl('Guide di ', 'Guides for ')}${esc(gt(GD_NOMI[pagina]) || gl('questa pagina', 'this page'))}</h3><p class="gd-m">${gl('Scegli cosa vuoi fare: ti accompagno passo passo, con il perché di ogni passo.', 'Choose what you want to do: I walk you through it step by step, with the reason for each step.')}</p>${ks.map(k => gdRiga(k, F)).join('')}`
    + `<div class="gd-act"><button class="btn b-ghost b-sm" type="button" data-gdall="1">${gl('Tutte le guide', 'All guides')} (${gdTutteK().length})</button><button class="btn b-ghost b-sm" type="button" data-gdx="1">${gl('Chiudi', 'Close')}</button></div>`);
}
function gdTutte() {
  const F = gdFatte(), vist = new Set();
  const gr = ['reg', 'arch', 'studia', 'imp', 'dsa'].map(p => { const L = gdGuide(p).filter(k => !vist.has(k)); L.forEach(k => vist.add(k)); return L.length ? `<div class="gd-sec">${esc(gt(GD_NOMI[p]))}</div>${L.map(k => gdRiga(k, F)).join('')}` : ''; }).join('');
  gdElenco(`<h3>${gl('Tutte le guide', 'All guides')}</h3><p class="gd-m">${gl('Una per ogni cosa che si fa, divise per pagina.', 'One for each thing you can do, grouped by page.')}</p>${gr}<div class="gd-act"><span></span><button class="btn b-ghost b-sm" type="button" data-gdx="1">${gl('Chiudi', 'Close')}</button></div>`);
}
document.addEventListener('click', e => {
  const b = e.target && e.target.closest && e.target.closest('[data-gdm],[data-gdsw],[data-gdall],[data-gdx],#gdVelo [data-gd]');
  if (!b) return;
  e.preventDefault();
  if (b.dataset.gdm) gdMenu(); else if (b.dataset.gdsw) gdInterruttore(); else if (b.dataset.gdall) gdTutte();
  else if (b.dataset.gdx) gdChiudiElenco(); else if (b.dataset.gd) { gdChiudiElenco(); gdInizia(b.dataset.gd); }
});
function gdEls() {
  if (document.getElementById('gdHole')) return;
  for (const [id, c] of [['gdDim', 'gd-dim'], ['gdIntro', 'gd-intro'], ['gdHole', 'gd-hole'], ['gdTip', 'gd-tip']]) {
    const e = document.createElement('div'); e.id = id; e.className = c; document.body.append(e);
  }
}
function gdInizia(k) {
  const G = GUIDE[k]; if (!G) return;
  gdFerma(); gdEls();
  GD.g = k; GD.i = -2; GD.clk = new Set(); GD.giri = 0;
  GD.base = {lez: gdLez(), chat: document.querySelectorAll('#chat > *').length};
  const I = document.getElementById('gdIntro');
  I.innerHTML = `<div class="gd-n">${gl('Guida · A cosa serve', 'Guide · What it is for')}</div><h3>${esc(gt(G.why.h))}</h3><p>${esc(gt(G.why.p))}</p><p class="gd-uh">${gl('Ti serve per', 'Useful for')}</p><ul>${G.why.uses.map(u => `<li>${esc(gt(u))}</li>`).join('')}</ul><p class="gd-tm">${esc(gt(G.why.tm))}</p>
    <div class="gd-bar"><button class="gd-x" type="button" id="gdNo">${gl('Non ora', 'Not now')}</button><button class="btn b-main" type="button" id="gdVia">${gl('Inizia', 'Start')}</button></div>`;
  document.getElementById('gdDim').classList.add('on'); I.classList.add('on');
  document.getElementById('gdNo').onclick = gdFerma;
  document.getElementById('gdVia').onclick = () => {
    document.getElementById('gdDim').classList.remove('on'); I.classList.remove('on');
    clearInterval(GD.t); GD.t = setInterval(gdPasso, 300); gdPasso();
  };
}
function gdFerma() {
  clearInterval(GD.t); GD.g = null;
  ['gdHole', 'gdTip', 'gdDim', 'gdIntro'].forEach(id => { const e = document.getElementById(id); if (e) e.remove(); });
}
function gdPasso() {
  const G = GUIDE[GD.g]; if (!G) return gdFerma();
  const fin = G.done();
  let i = fin ? G.S.length : G.S.findIndex(s => !s.ok());
  if (i < 0) i = G.S.length - 1;
  const s = G.S[i], el = s && !fin ? s.el() : null, h = document.getElementById('gdHole'), t = document.getElementById('gdTip');
  if (!h || !t) return;
  const N = G.S.length;
  if (i !== GD.i) {
    GD.i = i; GD.giri = 0;
    const pall = Array.from({length: N}, (_, j) => `<span class="${j <= i ? 'on' : ''}"></span>`).join('');
    t.innerHTML = fin ? `<div class="gd-n">${gl('Fatto', 'Done')}</div><b>${esc(gt(G.n))}</b><p>${esc(gt(G.end))}</p><div class="gd-bar"><span></span><button class="btn b-ghost b-sm" type="button" id="gdChiudi">${gl('Chiudi', 'Close')}</button></div>`
      : `<div class="gd-n">${gl('Passo', 'Step')} ${i + 1} ${gl('di', 'of')} ${N} · ${esc(gt(G.n))}</div><b>${esc(gt(s.t))}</b><p>${esc(gt(s.p))}</p>${s.w ? `<div class="gd-why"><b>${gl('Perché:', 'Why:')}</b> ${esc(gt(s.w))}</div>` : ''}<div class="gd-bar"><span class="gd-pall">${pall}</span><button class="gd-x" type="button" id="gdChiudi">${gl('Esci dalla guida', 'Exit the guide')}</button></div>`;
    document.getElementById('gdChiudi').onclick = gdFerma;
    if (el) try { el.scrollIntoView({block: 'center', behavior: 'smooth'}); } catch (e) {}
    if (fin) { clearInterval(GD.t); gdFatta(GD.g); }
  }
  GD.giri++;
  if (fin || !el) {
    h.style.display = 'none';
    t.style.left = Math.max(12, (innerWidth - t.offsetWidth) / 2) + 'px';
    t.style.top = Math.max(12, innerHeight - t.offsetHeight - 90) + 'px';
    return;
  }
  let r = el.getBoundingClientRect();
  // 07/11/2026 (prova iPhone coi tocchi veri): sull'iPhone il dito che tocca «Inizia» può fermare lo scorrimento morbido:
  // il tasto restava sotto lo schermo e il fumetto finiva fuori. Se il tasto non si vede, lo riporto in vista.
  if ((r.bottom > innerHeight - 10 || r.top < 0) && GD.giri < 8) { try { el.scrollIntoView({block: 'center'}); } catch (e) {} r = el.getBoundingClientRect(); }
  h.style.display = 'block';
  h.style.left = (r.left - 6) + 'px'; h.style.top = (r.top - 6) + 'px'; h.style.width = (r.width + 12) + 'px'; h.style.height = (r.height + 12) + 'px';
  t.style.left = Math.max(12, Math.min(innerWidth - t.offsetWidth - 12, r.left + r.width / 2 - t.offsetWidth / 2)) + 'px';
  const sotto = r.bottom + 16;
  const top = sotto + t.offsetHeight < innerHeight - 70 ? sotto : r.top - t.offsetHeight - 16;
  t.style.top = Math.max(12, Math.min(innerHeight - t.offsetHeight - 12, top)) + 'px';   // mai fuori dallo schermo
}
// i tasti toccati durante la guida (per i passi «hai toccato…»)
document.addEventListener('click', e => { const b = e.target && e.target.closest && e.target.closest('[data-a]'); if (GD.g && b) GD.clk.add(b.dataset.a); }, true);
setInterval(() => { try { gdDecora(); } catch (e) {} }, 800);
// le guide in inglese, frase per frase (la chiave e' la frase italiana qui sopra)
const GD_EN = {
"Apri «Registra»": "Open «Record»",
"Tocca «Registra» nel menu.": "Tap «Record» in the menu.",
"Da Registra partono le lezioni nuove e si importa quello che hai già.": "New lectures start from Record, and it is where you import what you already have.",
"Apri le tue lezioni": "Open your lectures",
"Tocca «Lezioni» nel menu.": "Tap «My recordings» in the menu.",
"Ogni cosa che riguarda una lezione (appunti, mappa, domande…) si fa dalla sua pagina.": "Everything about a lecture (notes, map, questions…) is done from its page.",
"Apri una lezione": "Open a lecture",
"Tocca una lezione dell'elenco: se è dentro una cartella, prima tocca la cartella (se non ce n'è ancora una, prima registrane o importane una).": "Tap a lecture in the list: if it is inside a folder, tap the folder first (if there isn't one yet, record or import one first).",
"Gli strumenti di studio sono nella pagina della lezione.": "The study tools are on the lecture's page.",
"Apri «Impostazioni»": "Open «Settings»",
"Tocca «Impostazioni» nel menu.": "Tap «Settings» in the menu.",
"Qui ci sono i collegamenti tra PC, telefono e cloud.": "This is where PC, phone and cloud are linked.",
"Apri «Studia»": "Open «Study»",
"Tocca «Studia» nel menu.": "Tap «Study» in the menu.",
"In Studia ogni materia ha la sua pagina: date d'esame, libro, ripasso.": "In Study every course has its own page: exam dates, textbook, review.",
"Apri la materia": "Open the course",
"Tocca la materia che vuoi (es. «Analisi 1»).": "Tap the course you want (e.g. «Calculus 1»).",
"Libro e date valgono per tutta la materia, non per una sola lezione.": "Textbook and dates apply to the whole course, not just one lecture.",
"Registra in aula": "Record in class",
"Registra una lezione in aula": "Record a lecture in class",
"Il telefono o il PC ascolta il docente dal microfono; alla fine trascrive la lezione e prepara gli appunti da solo.": "The phone or PC listens to the lecturer through the microphone; at the end it transcribes the lecture and prepares the notes by itself.",
"Avere tutta la lezione scritta, anche quello che non hai fatto in tempo ad annotare": "Having the whole lecture in writing, even what you didn't have time to note down",
"Appunti, mappa, flashcard e domande pronte per studiare": "Notes, map, flashcards and questions ready for studying",
"Prima chiedi al docente il permesso di registrare.": "Ask the lecturer for permission to record first.",
"Scegli «Lezione»": "Choose «Lecture»",
"In alto, il primo riquadro.": "At the top, the first box.",
"Così gli appunti sono quelli di una lezione: Cornell o Formato Esame, flashcard e domande.": "This way the notes are lecture notes: Cornell or Exam Format, flashcards and questions.",
"Scegli «In aula»": "Choose «In the classroom»",
"Il docente è lì davanti: registro dal microfono.": "The lecturer is right in front of you: I record from the microphone.",
"In aula conta solo il microfono; online servono anche schermo e audio del PC.": "In class only the microphone matters; online I also need the PC's screen and audio.",
"Scrivi la materia": "Type the course",
"Per esempio «Analisi 1».": "For example «Calculus 1».",
"Le lezioni della stessa materia finiscono insieme in Studia, con le date d'esame e il ripasso.": "Lectures of the same course end up together in Study, with the exam dates and the review.",
"Tocca «Registra»": "Tap «Record»",
"Appoggia il telefono vicino al docente.": "Put the phone near the lecturer.",
"Da qui registro: puoi mettere il telefono in tasca o spegnere lo schermo.": "From here I record: you can put the phone in your pocket or turn the screen off.",
"Sto registrando. Quando il docente finisce tocca «Fine»: la trascrizione e gli appunti arrivano da soli, li trovi in «Lezioni».": "I'm recording. When the lecturer finishes, tap «Stop»: the transcript and notes arrive by themselves, in «My recordings».",
"Registra online": "Record online",
"Registra una lezione online": "Record an online lecture",
"Meet, Teams, Zoom: registro l'audio e fotografo le slide dallo schermo del PC.": "Meet, Teams, Zoom: I record the audio and capture the slides from the PC screen.",
"Gli appunti con le slide al punto giusto": "Notes with the slides in the right place",
"Anche se ti distrai, la lezione resta tutta": "Even if you get distracted, you keep the whole lecture",
"Apri prima la lezione online, poi torna qui.": "Open the online lecture first, then come back here.",
"Scegli «Online»": "Choose «Online»",
"Il secondo riquadro.": "The second box.",
"Online registro schermo e audio del PC, non il microfono.": "Online I record the PC's screen and audio, not the microphone.",
"Per esempio «Diritto privato».": "For example «Contract Law».",
"Così la lezione finisce nella materia giusta.": "This way the lecture goes into the right course.",
"Lascia aperta la finestra della lezione online.": "Leave the online lecture window open.",
"Il programma si mette piccolo in un angolo e lavora mentre segui.": "The program shrinks into a corner and works while you follow.",
"Sto registrando. Alla fine tocca «Fine»: appunti e slide arrivano da soli in «Lezioni».": "I'm recording. At the end tap «Stop»: notes and slides arrive by themselves in «My recordings».",
"Importa un PDF": "Import a PDF",
"Importa un PDF e fanne gli appunti": "Import a PDF and turn it into notes",
"Hai già un PDF (dispense, una tesi, la trascrizione di una lezione)? Il programma lo legge e ne fa gli appunti, come se fosse una lezione registrata.": "Already have a PDF (handouts, a thesis, a lecture transcript)? The program reads it and makes notes from it, as if it were a recorded lecture.",
"Studiarlo con mappa, flashcard e domande": "Studying it with a map, flashcards and questions",
"Chiedere a Claude cosa vuol dire un punto": "Asking Claude what a passage means",
"Ritrovarlo su PC e telefono": "Finding it on PC and phone",
"Il PDF deve avere il testo vero (non foto di pagine). Ci vogliono pochi minuti e qualche centesimo.": "The PDF must contain real text (not photos of pages). It takes a few minutes and a few cents.",
"Tocca «Importa un testo…»": "Tap «Import a text…»",
"Scorri un po' in basso: «Hai già la trascrizione?». Si apre l'elenco dei file: scegli il PDF.": "Scroll down a little: «Already have the lecture transcript?». The file list opens: choose the PDF.",
"Da qui entrano nel programma le cose che non hai registrato tu.": "This is how things you didn't record yourself get into the program.",
"Scrivi il nome della lezione": "Type the lecture's name",
"Per esempio «Riproduzione del cane».": "For example «Introduction to genetics».",
"Con questo nome la ritrovi in Lezioni e in Studia.": "You'll find it under this name in My recordings and in Study.",
"Tocca «Crea gli appunti»": "Tap «Create the notes»",
"Sul tasto gira la rotella finché non ha finito di partire.": "The spinner turns on the button until it has started.",
"Claude scrive gli appunti; poi trovi anche mappa e flashcard.": "Claude writes the notes; then you also get the map and flashcards.",
"Fatto! La lezione è in «Lezioni»: quando gli appunti sono pronti aprila per leggerli, con la mappa e le flashcard.": "Done! The lecture is in «My recordings»: when the notes are ready, open it to read them, with the map and flashcards.",
"Importa audio o video": "Import audio or video",
"Importa un audio o un video": "Import an audio or video file",
"Una lezione registrata con un'altra app, un vocale lungo, il video di una lezione: lo trascrivo e ne faccio gli appunti.": "A lecture recorded with another app, a long voice note, a lecture video: I transcribe it and make the notes.",
"Non perdere le lezioni registrate prima": "Not losing lectures you recorded before",
"Appunti anche dai video delle lezioni": "Notes from lecture videos too",
"Più è lungo, più ci mette a trascrivere.": "The longer it is, the longer the transcription takes.",
"Tocca «Importa un video…»": "Tap «Import a video or audio…»",
"Si apre l'elenco dei file: scegli l'audio o il video.": "The file list opens: choose the audio or video.",
"Il file originale resta dov'è: ne faccio una copia.": "The original file stays where it is: I make a copy.",
"Il nome con cui la ritroverai.": "The name you'll find it under.",
"Come per le lezioni registrate: nome e materia.": "As with recorded lectures: name and course.",
"Tocca «Importa»": "Tap «Import and prepare the notes»",
"Parte la trascrizione.": "The transcription starts.",
"Quando finisce arrivano gli appunti, come per una lezione registrata.": "When it finishes the notes arrive, as with a recorded lecture.",
"La lezione è in «Lezioni»: la trascrizione va avanti da sola, poi arrivano gli appunti.": "The lecture is in «My recordings»: the transcription goes on by itself, then the notes arrive.",
"PC e telefono insieme": "PC and phone together",
"Le stesse lezioni su PC e telefono": "The same lectures on PC and phone",
"Il telefono si collega al PC inquadrando un QR: da lì le lezioni, gli appunti e il ripasso sono gli stessi da tutte e due le parti.": "The phone links to the PC by scanning a QR code: from then on lectures, notes and review are the same on both.",
"Il PC mostra un QR: il telefono lo inquadra e da lì le lezioni, gli appunti e il ripasso sono gli stessi da tutte e due le parti.": "The PC shows a QR code: the phone scans it and from then on lectures, notes and review are the same on both.",
"Registri col telefono e studi sul PC (o il contrario)": "Recording on the phone and studying on the PC (or the other way round)",
"Anche fuori casa, passando dal tuo Google Drive": "Away from home too, through your Google Drive",
"Servono il PC e il telefono a portata di mano.": "You need the PC and the phone at hand.",
"In «Sincronizza» tocca «Apri…»": "In «Sync» tap «Open…»",
"Il riquadro «Sincronizza».": "The «Sync» box.",
"Qui c'è tutto quello che collega i tuoi dispositivi.": "Everything that links your devices is here.",
"Tocca «Collegati al PC»": "Tap «Link to PC»",
"Poi inquadra il QR che il PC mostra in Impostazioni › Sincronizza.": "Then scan the QR code the PC shows in Settings › Sync.",
"Il QR porta al telefono il collegamento e la password delle lezioni: non devi scrivere niente.": "The QR code gives the phone the link and the lectures' password: you don't have to type anything.",
"Mostra il QR al telefono": "Show the QR code to the phone",
"Sul telefono: Impostazioni › Sincronizza › «Collegati al PC», poi inquadra questo QR.": "On the phone: Settings › Sync › «Link to PC», then scan this QR code.",
"Il QR porta al telefono il collegamento e la password delle lezioni.": "The QR code gives the phone the link and the lectures' password.",
"Collegati! Da adesso le lezioni passano da sole tra PC e telefono.": "Linked! From now on lectures move between PC and phone by themselves.",
"Con Google Drive: entri con lo stesso account Google sul PC e sul telefono, e basta. Niente codici né QR: le lezioni, gli appunti e il ripasso sono gli stessi da tutte e due le parti, anche quando siete lontani.": "With Google Drive: sign in with the same Google account on the PC and on the phone, and that's it. No codes or QR: lectures, notes and reviews are the same on both, even when far apart.",
"Anche fuori casa e con i dati del telefono": "Away from home too, and on mobile data",
"La password delle lezioni arriva da sola": "The lectures' password arrives by itself",
"Serve un account Google (quello di Gmail va benissimo). La stessa cosa va fatta sul PC e sul telefono.": "You need a Google account (your Gmail one is fine). Do the same on the PC and on the phone.",
"Tocca «Apri» in «Sincronizza»": "Tap «Open» in «Sync»",
"È il primo riquadro in alto: dice se PC e telefono sono già collegati.": "It's the first box at the top: it says whether PC and phone are already connected.",
"Tocca «Accedi con Google»": "Tap «Sign in with Google»",
"Si apre la pagina di Google: entra con il tuo account e dai il permesso.": "Google's page opens: sign in with your account and allow access.",
"Verba Manent usa solo una cartella sua nel tuo Drive, con le lezioni chiuse da una password. Se sul PC hai già fatto lo stesso, la password arriva da sola.": "Verba Manent only uses its own folder in your Drive, with the lectures locked by a password. If you already did the same on the PC, the password arrives by itself.",
"Verba Manent usa solo una cartella sua nel tuo Drive, con le lezioni chiuse da una password. Poi fai lo stesso sul telefono, con lo stesso account.": "Verba Manent only uses its own folder in your Drive, with the lectures locked by a password. Then do the same on the phone, with the same account.",
"Collegati! Le lezioni del PC arrivano da sole sul telefono, e quelle del telefono sul PC.": "Connected! The PC's lectures reach the phone by themselves, and the phone's reach the PC.",
"Collegato! Ora fai «Accedi con Google» anche sul telefono, con lo stesso account: le lezioni passano da sole.": "Connected! Now do «Sign in with Google» on the phone too, with the same account: lectures move by themselves.",
"Chiedi alla lezione": "Ask the lecture",
"Fai una domanda sulla lezione": "Ask a question about the lecture",
"Non hai capito un punto? Chiedilo: risponde Claude, usando solo quello che è stato detto a lezione.": "Didn't understand a point? Ask: Claude answers, using only what was said in the lecture.",
"Farti rispiegare un passaggio": "Getting a passage explained again",
"Sapere se una cosa è stata detta o no": "Knowing whether something was said or not",
"Meno di un centesimo a domanda.": "Less than a cent per question.",
"Tocca «Chiedi alla lezione»": "Tap «Ask the lecture»",
"Uno dei riquadri della lezione.": "One of the lecture's boxes.",
"Le domande valgono per questa lezione (o per tutta la materia).": "Questions are about this lecture (or the whole course).",
"Scrivi la domanda": "Type the question",
"Per esempio «Cos'è un limite notevole?».": "For example «What is a standard limit?».",
"Più è precisa, migliore è la risposta.": "The more precise it is, the better the answer.",
"Tocca «Chiedi»": "Tap «Ask»",
"La risposta arriva in pochi secondi.": "The answer arrives in a few seconds.",
"Le risposte restano: puoi rileggerle dopo.": "Answers are kept: you can read them again later.",
"Ecco la risposta. Puoi continuare a chiedere: «Nuova conversazione» ricomincia da capo.": "Here is the answer. You can keep asking: «New conversation» starts over.",
"La mappa": "The mind map",
"La mappa della lezione": "The lecture's mind map",
"Tutta la lezione in una pagina: il tema al centro e i rami con le cose da sapere.": "The whole lecture on one page: the topic in the middle and branches with what you need to know.",
"Ripassare in due minuti": "Reviewing in two minutes",
"Ascoltarla ramo per ramo": "Listening to it branch by branch",
"Modificarla o costruirla tu": "Editing it or building it yourself",
"La prima volta Claude ci mette qualche secondo a prepararla.": "The first time Claude takes a few seconds to prepare it.",
"Tocca «Mappa»": "Tap «Mind map»",
"Ogni lezione ha la sua mappa.": "Every lecture has its own map.",
"Tocca «Grafica»": "Tap «Diagram»",
"La mappa intera, con le linee: ingrandisci con due dita.": "The whole map, with lines: zoom with two fingers.",
"Sul telefono «Guarda» la mostra a elenco, più comoda da leggere; «Grafica» la mostra come sul PC.": "On the phone «View» shows it as a list, easier to read; «Diagram» shows it as on the PC.",
"Tocca l'altoparlante di un ramo": "Tap a branch's speaker",
"Senti il ramo letto ad alta voce.": "You hear the branch read aloud.",
"Ascoltare aiuta a ricordare.": "Listening helps you remember.",
"Con «Modifica» la cambi, con «Costruiscila tu» la rifai da solo per allenarti; «Stampa o PDF» la salva.": "«Edit» changes it, «Build it yourself» lets you redo it alone for practice; «Print or PDF» saves it.",
"Le flashcard": "Flashcards",
"Ripassa con le flashcard": "Review with flashcards",
"Domande e risposte prese dalla lezione: tu provi a rispondere, poi giri la carta e dici se la sapevi.": "Questions and answers from the lecture: you try to answer, then flip the card and say whether you knew it.",
"Ricordare a lungo (te le ripropongo quando stai per dimenticarle)": "Remembering for a long time (I bring them back when you are about to forget them)",
"Prepararti all'esame poco alla volta": "Preparing for the exam a little at a time",
"Bastano pochi minuti al giorno.": "A few minutes a day are enough.",
"Tocca «Flashcard»": "Tap «Flashcards»",
"Il riquadro con le carte.": "The box with the cards.",
"Le carte sono di questa lezione; in Studia trovi il ripasso di tutta la materia.": "The cards are from this lecture; in Study you'll find the review of the whole course.",
"Prova a rispondere, poi gira la carta": "Try to answer, then flip the card",
"Tocca la carta per vedere la risposta.": "Tap the card to see the answer.",
"Lo sforzo di ricordare è quello che fa imparare.": "The effort of remembering is what makes you learn.",
"Dì se la sapevi: quelle che non sapevi tornano prima. Il «Ripasso del giorno» in Studia te le ripropone da solo.": "Say whether you knew it: the ones you didn't come back sooner. The «Daily review» in Study brings them back by itself.",
"Ascolta gli appunti": "Listen to the notes",
"Una voce ti legge gli appunti della lezione, con la parola che senti evidenziata.": "A voice reads you the lecture notes, with the word you hear highlighted.",
"Ripassare mentre cammini o sei in macchina": "Reviewing while you walk or drive",
"Leggere meno fatica (utile con un DSA)": "Less reading effort (useful with dyslexia)",
"Puoi scegliere la velocità.": "You can choose the speed.",
"Tocca «Ascolta»": "Tap «Listen to the notes»",
"Il riquadro con l'altoparlante.": "The box with the speaker.",
"Legge gli appunti di questa lezione.": "It reads this lecture's notes.",
"Tocca «Leggi»": "Tap «Read aloud»",
"Parte la voce.": "The voice starts.",
"Puoi fermarla e riprendere quando vuoi.": "You can stop it and resume whenever you like.",
"Sta leggendo. Con la velocità sotto la rallenti o la acceleri; con «Modalità DSA» il testo diventa più facile da leggere.": "It's reading. With the speed below you slow it down or speed it up; with «Dyslexia mode» the text becomes easier to read.",
"Il libro della materia": "The course textbook",
"Aggiungi il libro di testo": "Add the textbook",
"Il PDF del libro (o le dispense) di una materia: per ogni lezione ti dico le pagine giuste e cosa a lezione non si è detto.": "The PDF of a course's textbook (or handouts): for each lecture I tell you the right pages and what was not said in class.",
"Sapere cosa studiare sul libro dopo ogni lezione": "Knowing what to study in the book after each lecture",
"Non perdere le parti che il prof ha saltato": "Not missing the parts the lecturer skipped",
"Il libro resta sul tuo dispositivo: non va su internet.": "The book stays on your device: it doesn't go online.",
"Tocca «Libro»": "Tap «Textbook»",
"Nella pagina della materia, il riquadro del libro.": "On the course page, the textbook box.",
"Il libro vale per tutte le lezioni della materia.": "The book applies to all the lectures of the course.",
"Tocca «Scegli il PDF del libro»": "Tap «Choose the book PDF»",
"Si apre l'elenco dei file: scegli il PDF.": "The file list opens: choose the PDF.",
"Lo leggo qui sul tuo dispositivo, una volta sola.": "I read it here on your device, only once.",
"Il libro è collegato: nella pagina di ogni lezione trovi le pagine da studiare.": "The book is linked: on each lecture's page you'll find the pages to study.",
"Data d'esame e piano": "Exam date and plan",
"La data dell'esame e il piano di studio": "The exam date and the study plan",
"Scrivi quando hai l'esame: ti preparo un piano giorno per giorno e il ripasso si regola da solo.": "Enter when your exam is: I prepare a day-by-day plan and the review adjusts by itself.",
"Sapere ogni giorno cosa ripassare": "Knowing every day what to review",
"Arrivare all'esame senza ansia dell'ultimo momento": "Getting to the exam without last-minute panic",
"La data si può cambiare quando vuoi.": "You can change the date whenever you like.",
"Tocca «Data d'esame» o «Piano»": "Tap «Exam date» or «Study plan»",
"Nella pagina della materia, in alto.": "On the course page, at the top.",
"Il piano dipende dalla data.": "The plan depends on the date.",
"Scegli la data dell'esame": "Choose the exam date",
"Tocca la casella della data.": "Tap the date box.",
"Da qui calcolo quanti giorni hai.": "From here I work out how many days you have.",
"Fatto: nel piano vedi cosa fare ogni giorno, e in Studia il conto alla rovescia.": "Done: in the plan you see what to do each day, and in Study the countdown.",
"Copia nel cloud": "Copy to the cloud",
"Una copia delle lezioni nel cloud": "A copy of your lectures in the cloud",
"Ogni lezione pronta va anche nel tuo Google Drive o OneDrive: la ritrovi dal telefono o da un altro computer.": "Every finished lecture also goes to your Google Drive or OneDrive: you find it from your phone or another computer.",
"Non perdere le lezioni se il PC si rompe": "Not losing your lectures if the PC breaks",
"Leggere gli appunti dal telefono": "Reading the notes on your phone",
"Si imposta una volta sola.": "You set it up only once.",
"In «Copia nel cloud» tocca «Apri…»": "In «Copy to the cloud» tap «Open…»",
"Il riquadro con la nuvola.": "The box with the cloud.",
"Lì scegli dove copiare e cosa.": "There you choose where to copy and what.",
"Scegli Google Drive o OneDrive, spunta cosa copiare e tocca «Copia anche le lezioni già fatte».": "Choose Google Drive or OneDrive, tick what to copy and tap «Also copy the lectures already done».",
"Registra": "Record",
"Lezioni": "My recordings",
"Lezione": "Lecture",
"Studia": "Study",
"Impostazioni": "Settings",
"Modalità DSA": "Dyslexia mode",
"Guida": "Guide"
};
