/* «Università e Master» (anteprima 71, approvata il 09/11/2026).
   Pagine: uni (il percorso e i quattro riquadri), ul (libretto), ue (un esame), ua (appelli e scadenze), ut (tesi).
   «Cose da fare» resta la sua pagina: sul telefono si apre da qui (la voce della barra in basso è questa).
   I dati: A.uni_* (app/universita.py), file esami/_universita.json che va sugli altri dispositivi. */
'use strict';
Object.assign(TESTI.it, {
  'nav.uni': 'Università e Master', 'nav.uni.c': 'Univ. e Master', 'un.h': 'Università e Master', 'un.sub': 'Il tuo percorso, gli esami e le scadenze',
  'un.mod': 'Modifica', 'un.nuovo.t': 'Comincia dal tuo percorso', 'un.nuovo.s': 'Scrivi il corso e il tipo (triennale, magistrale, master…): poi riempi il libretto con una foto o a mano.', 'un.nuovo.b': 'Scrivi il tuo percorso',
  'un.cred': '{f} {c} su {t} · ne mancano {m}', 'un.cred.f': '{f} {c} su {t} · tutti fatti', 'un.media': 'media ponderata', 'un.part': 'voto di partenza alla laurea', 'un.alto': 'voto più alto', 'un.classe': 'classe di laurea',
  'un.fatti': 'esami fatti su {n}', 'un.h.it': 'Voto di partenza = media × 110 ÷ 30. La tua università aggiunge i punti della tesi con le sue regole.',
  'un.h.itm': 'Voti in trentesimi, media pesata sui crediti formativi universitari (CFU).',
  'un.h.nl': 'Voti da 1 a 10, si passa con 6. La media è pesata sui crediti ECTS (European Credit Transfer System, i crediti europei).',
  'un.h.uk': 'Voti in percentuale. La classe di laurea si calcola sulla media; la tua università dice quali anni contano.',
  'un.h.altro': 'Media pesata sui crediti, con il voto massimo e minimo che hai scelto.',
  'un.c.first': 'First (prima classe)', 'un.c.21': '2:1 (seconda classe, alta)', 'un.c.22': '2:2 (seconda classe, bassa)', 'un.c.third': 'Third (terza classe)', 'un.c.distinction': 'Distinction (con lode)', 'un.c.merit': 'Merit (con merito)', 'un.c.pass': 'Pass (superato)',
  'un.lib': 'Libretto', 'un.lib.s': 'Esami, voti e crediti', 'un.app': 'Appelli e scadenze', 'un.app.s': 'Iscrizioni, tasse, promemoria', 'un.app.sub': 'Con il promemoria nel calendario del telefono o del PC',
  'un.fare.s': 'Gli impegni delle riunioni', 'un.tesi': 'Tesi', 'un.tesi.s': 'Relatore, scadenze, documenti', 'un.pw': 'Project work e tesi', 'un.pw.s': 'Azienda, tutor, scadenze', 'un.tesi.sub': 'Tutto quello che serve per arrivare alla discussione',
  'un.t.triennale': 'Triennale', 'un.t.magistrale': 'Magistrale', 'un.t.ciclo': 'Ciclo unico', 'un.t.master': 'Master',
  'un.tl.triennale': 'Laurea triennale', 'un.tl.magistrale': 'Laurea magistrale', 'un.tl.ciclo': 'Laurea a ciclo unico', 'un.tl.master': 'Master', 'un.anno': '{n}° anno',
  'un.p.it': 'Italia', 'un.p.nl': 'Paesi Bassi', 'un.p.uk': 'Regno Unito', 'un.p.altro': 'Altro',
  'un.ph.it': 'Voti in trentesimi con la lode, crediti formativi universitari (CFU), voto di laurea su 110.',
  'un.ph.nl': 'Voti da 1 a 10 (si passa con 6), crediti ECTS (European Credit Transfer System, i crediti europei), niente voto di laurea su 110.',
  'un.ph.uk': 'Voti in percentuale e classi di laurea (First, 2:1…), crediti britannici.',
  'un.ph.altro': 'Scegli tu il voto massimo, quello per passare e il nome dei crediti.',
  'un.perc.t': 'Il tuo percorso', 'un.f.corso': 'Nome del corso, es. Ingegneria gestionale', 'un.f.uni': 'Università, es. Università di Ferrara', 'un.f.paese': 'Paese (cambia voti e crediti)',
  'un.f.anno': 'Anno di corso', 'un.f.tot': 'Crediti di tutto il corso', 'un.f.max': 'Voto massimo', 'un.f.min': 'Voto per passare', 'un.f.ncred': 'Nome dei crediti, es. CFU',
  'un.salva': 'Salva', 'un.foto': 'Fotografa il libretto o il piano di studi', 'un.mano': '+ A mano', 'un.foto.h': 'Anche il PDF dal sito dell’università: Claude legge esami, crediti e voti e tu controlli prima di salvare.',
  'un.f.tutti': 'Tutti', 'un.f.fatti': 'Fatti', 'un.f.dafare': 'Da fare', 'un.vuoto.lib': 'Ancora nessun esame: fotografa il libretto o aggiungili a mano.', 'un.niente': 'Niente qui.',
  'un.lib.sub': '{n} esami · {f} fatti · tocca un esame per aprirlo', 'un.dafare': 'da fare', 'un.idoneo': 'idoneo', 'un.lode': 'L',
  'un.es.t': 'Aggiungi un esame', 'un.es.mod': 'Cambia l’esame', 'un.f.nome': 'Nome dell’esame, es. Statistica', 'un.f.cfu': 'Crediti, es. 9', 'un.f.voto': 'Voto (se l’hai già dato), es. 28, 30 e lode, idoneo',
  'un.f.annoes': 'Anno o semestre (facoltativo)', 'un.f.data': 'Data dell’esame dato (facoltativo)', 'un.togli': 'Togli', 'un.togli.q': 'Togliere «{n}» dal libretto? Vanno via anche i suoi appelli.',
  'un.es.sub': '{c} crediti{a} · {s}', 'un.es.fatto': 'fatto: {v}', 'un.pross': 'Prossimo appello', 'un.nessun.app': 'Nessun appello segnato.', 'un.add.app': '+ Aggiungi un appello', 'un.voto.b': 'Segna il voto',
  'un.invm': 'In Verba Manent', 'un.mat': 'Materia delle lezioni', 'un.mat.no': 'Collega le lezioni di questo esame', 'un.mat.s': 'Scegli la materia delle tue registrazioni: da qui apri piano di studio, «Preparati all’esame» e tutor.',
  'un.mat.lez': '{n} lezioni registrate', 'un.mat.lez1': '1 lezione registrata', 'un.mat.cart': 'materia «{m}»', 'un.mat.scegli': 'Scegli la materia', 'un.mat.nessuna': 'Nessuna', 'un.mat.vuote': 'Non hai ancora lezioni con la materia: quando registri, scrivi la materia e poi collegala qui.',
  'un.prep': 'Preparati all’esame', 'un.prep.s': 'piano di studio fino all’appello · domande più probabili', 'un.prep.s2': 'piano di studio fino al {d} · domande più probabili', 'un.tutor.s': 'ti dice cosa fare oggi', 'un.apri': 'Apri', 'un.cambia': 'Cambia',
  'un.sc.t': 'Aggiungi una scadenza', 'un.sc.mod': 'Cambia la scadenza', 'un.sc.tipo': 'Cos’è', 'un.st.iscrizione': 'Iscrizione', 'un.st.esame': 'Esame', 'un.st.tasse': 'Tasse', 'un.st.altro': 'Altro',
  'un.f.quando': 'Giorno', 'un.f.ora': 'Ora (facoltativa)', 'un.f.esame': 'Esame del libretto', 'un.f.cosa': 'Cosa, es. Seconda rata delle tasse', 'un.f.nota': 'Nota, es. scritto · aula 3',
  'un.add': '+ Aggiungi', 'un.foto.app': 'Fotografa il calendario degli appelli', 'un.cal': 'Metti nel calendario', 'un.cal.t': 'Nel calendario', 'un.cal.s': 'Le scadenze da oggi in poi, con il promemoria.',
  'un.vuoto.app': 'Nessuna scadenza: aggiungi gli appelli, le iscrizioni e le tasse, o fotografa il calendario degli appelli.', 'un.fatta': 'Fatto', 'un.passate': 'Passate', 'un.gg0': 'oggi', 'un.gg1': 'domani', 'un.gg': 'tra {n} giorni', 'un.ggp': '{n} giorni fa',
  'un.iscriviti': 'iscriviti', 'un.letti.t': 'Ho letto {n} esami', 'un.letti.app': 'Ho letto {n} appelli', 'un.letti.s': 'Controlla e togli la spunta a quelli sbagliati. I voti si possono correggere dopo.',
  'un.salva.n': 'Salva {n}', 'un.legge': 'Claude legge esami, crediti e voti dalla foto…', 'un.legge.app': 'Claude legge gli appelli dalla foto…', 'un.foto.q': 'Leggere {n} foto? Costa circa {c} € di Claude.',
  'un.foto.come': 'Da dove?', 'un.foto.gal': 'Dalle foto', 'un.foto.scatta': 'Scatta una foto', 'un.foto.pdf': 'Un PDF', 'un.ok.lib': '{n} esami nuovi, {c} aggiornati', 'un.ok.app': '{n} scadenze aggiunte',
  'un.t.titolo': 'Titolo e relatore', 'un.t.vuoto': 'Ancora niente: scrivi titolo e relatore quando li hai.', 'un.t.az': 'Azienda: {a}', 'un.t.rel': 'Relatore: {r}', 'un.t.corr': 'correlatore: {c}',
  'un.f.titolo': 'Titolo della tesi', 'un.f.rel': 'Relatore', 'un.f.corr': 'Correlatore (facoltativo)', 'un.f.az': 'Azienda o ente (project work)', 'un.f.note': 'Note',
  'un.t.scad': 'Scadenze', 'un.t.scad.s': 'Domanda di laurea, consegna, discussione: aggiungile in «Appelli e scadenze», tipo «Altro».', 'un.t.doc': 'I documenti da cui studi',
  'un.t.doc.s': 'Articoli, libri e pagine web della tesi: mettili nel «Libro di testo» della materia «{m}», così puoi fare domande e Claude risponde citando la pagina.', 'un.t.doc.b': 'Apri il Libro di testo',
  'un.t.note': 'Note', 'un.pross.app': 'Prossima scadenza: {t}, {d}',
  'un.cc.t': 'Collega il calendario', 'un.cc.s': 'Appelli, scadenze e date d’esame di Studia arrivano da sole nel calendario del telefono o del PC, con il promemoria, e si aggiornano quando le cambi.',
  'un.cc.b': 'Collega il calendario', 'un.cc.ok': 'Calendario collegato: le date arrivano da sole', 'un.cc.altro': 'Aggiungi a un altro calendario', 'un.cc.via': 'Scollega',
  'un.cc.lav': 'Preparo il tuo calendario…', 'un.cc.ult': 'Ultimo passo: scegli il tuo calendario', 'un.cc.ult.s': 'Si fa una volta sola: da qui in poi le date nuove o cambiate arrivano da sole. Google Calendar le aggiorna ogni qualche ora.',
  'un.cc.ios': 'iPhone, iPad o Mac', 'un.cc.goo': 'Google Calendar', 'un.cc.out': 'Outlook', 'un.cc.copia': 'Copia l’indirizzo', 'un.cc.via.q': 'Scollegare il calendario? Le date spariscono dal calendario alla prossima volta che si aggiorna.',
  'un.cc.st': 'Nel calendario', 'un.av.t': 'Promemoria di oggi', 'un.av.b': 'Apri le scadenze',
});
Object.assign(TESTI.en, {
  'nav.uni': 'University and Master', 'nav.uni.c': 'University', 'un.h': 'University and Master', 'un.sub': 'Your degree, exams and deadlines',
  'un.mod': 'Edit', 'un.nuovo.t': 'Start from your degree', 'un.nuovo.s': 'Write the course and the type (bachelor, master…): then fill the transcript with a photo or by hand.', 'un.nuovo.b': 'Write your degree',
  'un.cred': '{f} {c} out of {t} · {m} to go', 'un.cred.f': '{f} {c} out of {t} · all done', 'un.media': 'weighted average', 'un.part': 'starting graduation mark', 'un.alto': 'highest mark', 'un.classe': 'degree class',
  'un.fatti': 'exams passed out of {n}', 'un.h.it': 'Starting mark = average × 110 ÷ 30. Your university adds the thesis points with its own rules.',
  'un.h.itm': 'Marks out of 30, average weighted on university credits (CFU).',
  'un.h.nl': 'Marks from 1 to 10, pass with 6. The average is weighted on ECTS credits (European Credit Transfer System).',
  'un.h.uk': 'Marks in percent. The degree class comes from the average; your university says which years count.',
  'un.h.altro': 'Average weighted on credits, with the highest and pass marks you chose.',
  'un.c.first': 'First', 'un.c.21': '2:1 (upper second)', 'un.c.22': '2:2 (lower second)', 'un.c.third': 'Third', 'un.c.distinction': 'Distinction', 'un.c.merit': 'Merit', 'un.c.pass': 'Pass',
  'un.lib': 'Transcript', 'un.lib.s': 'Exams, marks and credits', 'un.app': 'Exams and deadlines', 'un.app.s': 'Registrations, fees, reminders', 'un.app.sub': 'With a reminder in your phone or PC calendar',
  'un.fare.s': 'Commitments from meetings', 'un.tesi': 'Thesis', 'un.tesi.s': 'Supervisor, deadlines, documents', 'un.pw': 'Project work and thesis', 'un.pw.s': 'Company, tutor, deadlines', 'un.tesi.sub': 'Everything you need to get to the defence',
  'un.t.triennale': 'Bachelor', 'un.t.magistrale': 'Master’s degree', 'un.t.ciclo': 'Single-cycle', 'un.t.master': 'Master',
  'un.tl.triennale': 'Bachelor’s degree', 'un.tl.magistrale': 'Master’s degree', 'un.tl.ciclo': 'Single-cycle degree', 'un.tl.master': 'Master', 'un.anno': 'Year {n}',
  'un.p.it': 'Italy', 'un.p.nl': 'Netherlands', 'un.p.uk': 'United Kingdom', 'un.p.altro': 'Other',
  'un.ph.it': 'Marks out of 30 with honours (lode), university credits (CFU), graduation mark out of 110.',
  'un.ph.nl': 'Marks from 1 to 10 (pass with 6), ECTS credits (European Credit Transfer System), no graduation mark out of 110.',
  'un.ph.uk': 'Marks in percent and degree classes (First, 2:1…), UK credits.',
  'un.ph.altro': 'You choose the highest mark, the pass mark and the name of the credits.',
  'un.perc.t': 'Your degree', 'un.f.corso': 'Course name, e.g. Business Engineering', 'un.f.uni': 'University, e.g. Tilburg University', 'un.f.paese': 'Country (changes marks and credits)',
  'un.f.anno': 'Year of study', 'un.f.tot': 'Credits for the whole course', 'un.f.max': 'Highest mark', 'un.f.min': 'Pass mark', 'un.f.ncred': 'Name of the credits, e.g. ECTS',
  'un.salva': 'Save', 'un.foto': 'Photograph your transcript or study plan', 'un.mano': '+ By hand', 'un.foto.h': 'The PDF from the university website works too: Claude reads exams, credits and marks and you check before saving.',
  'un.f.tutti': 'All', 'un.f.fatti': 'Passed', 'un.f.dafare': 'To do', 'un.vuoto.lib': 'No exams yet: photograph your transcript or add them by hand.', 'un.niente': 'Nothing here.',
  'un.lib.sub': '{n} exams · {f} passed · tap an exam to open it', 'un.dafare': 'to do', 'un.idoneo': 'pass', 'un.lode': 'L',
  'un.es.t': 'Add an exam', 'un.es.mod': 'Edit the exam', 'un.f.nome': 'Exam name, e.g. Statistics', 'un.f.cfu': 'Credits, e.g. 6', 'un.f.voto': 'Mark (if you have taken it), e.g. 7.5, 68%, pass',
  'un.f.annoes': 'Year or semester (optional)', 'un.f.data': 'Date you took it (optional)', 'un.togli': 'Remove', 'un.togli.q': 'Remove «{n}» from the transcript? Its exam dates go too.',
  'un.es.sub': '{c} credits{a} · {s}', 'un.es.fatto': 'passed: {v}', 'un.pross': 'Next exam date', 'un.nessun.app': 'No exam date yet.', 'un.add.app': '+ Add an exam date', 'un.voto.b': 'Enter the mark',
  'un.invm': 'In Verba Manent', 'un.mat': 'Subject of your lectures', 'un.mat.no': 'Link the lectures of this exam', 'un.mat.s': 'Choose the subject of your recordings: from here you open the study plan, «Get ready for the exam» and the tutor.',
  'un.mat.lez': '{n} lectures recorded', 'un.mat.lez1': '1 lecture recorded', 'un.mat.cart': 'subject «{m}»', 'un.mat.scegli': 'Choose the subject', 'un.mat.nessuna': 'None', 'un.mat.vuote': 'You have no lectures with a subject yet: when you record, write the subject and then link it here.',
  'un.prep': 'Get ready for the exam', 'un.prep.s': 'study plan up to the exam · most likely questions', 'un.prep.s2': 'study plan up to {d} · most likely questions', 'un.tutor.s': 'tells you what to do today', 'un.apri': 'Open', 'un.cambia': 'Change',
  'un.sc.t': 'Add a deadline', 'un.sc.mod': 'Edit the deadline', 'un.sc.tipo': 'What is it', 'un.st.iscrizione': 'Registration', 'un.st.esame': 'Exam', 'un.st.tasse': 'Fees', 'un.st.altro': 'Other',
  'un.f.quando': 'Day', 'un.f.ora': 'Time (optional)', 'un.f.esame': 'Exam from your transcript', 'un.f.cosa': 'What, e.g. Second tuition instalment', 'un.f.nota': 'Note, e.g. written · room 3',
  'un.add': '+ Add', 'un.foto.app': 'Photograph the exam timetable', 'un.cal': 'Add to calendar', 'un.cal.t': 'In the calendar', 'un.cal.s': 'The deadlines from today on, with a reminder.',
  'un.vuoto.app': 'No deadlines: add exams, registrations and fees, or photograph the exam timetable.', 'un.fatta': 'Done', 'un.passate': 'Past', 'un.gg0': 'today', 'un.gg1': 'tomorrow', 'un.gg': 'in {n} days', 'un.ggp': '{n} days ago',
  'un.iscriviti': 'register', 'un.letti.t': 'I read {n} exams', 'un.letti.app': 'I read {n} exam dates', 'un.letti.s': 'Check them and untick the wrong ones. Marks can be fixed later.',
  'un.salva.n': 'Save {n}', 'un.legge': 'Claude is reading exams, credits and marks from the photo…', 'un.legge.app': 'Claude is reading the exam dates from the photo…', 'un.foto.q': 'Read {n} photos? It costs about €{c} of Claude.',
  'un.foto.come': 'From where?', 'un.foto.gal': 'From photos', 'un.foto.scatta': 'Take a photo', 'un.foto.pdf': 'A PDF', 'un.ok.lib': '{n} new exams, {c} updated', 'un.ok.app': '{n} deadlines added',
  'un.t.titolo': 'Title and supervisor', 'un.t.vuoto': 'Nothing yet: write the title and supervisor when you have them.', 'un.t.az': 'Company: {a}', 'un.t.rel': 'Supervisor: {r}', 'un.t.corr': 'co-supervisor: {c}',
  'un.f.titolo': 'Thesis title', 'un.f.rel': 'Supervisor', 'un.f.corr': 'Co-supervisor (optional)', 'un.f.az': 'Company or organisation (project work)', 'un.f.note': 'Notes',
  'un.t.scad': 'Deadlines', 'un.t.scad.s': 'Graduation application, hand-in, defence: add them in «Exams and deadlines», type «Other».', 'un.t.doc': 'The documents you study from',
  'un.t.doc.s': 'Articles, books and web pages for the thesis: put them in the «Textbook» of the subject «{m}», so you can ask questions and Claude answers quoting the page.', 'un.t.doc.b': 'Open the Textbook',
  'un.t.note': 'Notes', 'un.pross.app': 'Next deadline: {t}, {d}',
  'un.cc.t': 'Connect your calendar', 'un.cc.s': 'Exam dates, deadlines and the exam dates from Study arrive by themselves in your phone or PC calendar, with a reminder, and update when you change them.',
  'un.cc.b': 'Connect your calendar', 'un.cc.ok': 'Calendar connected: dates arrive by themselves', 'un.cc.altro': 'Add to another calendar', 'un.cc.via': 'Disconnect',
  'un.cc.lav': 'Preparing your calendar…', 'un.cc.ult': 'Last step: choose your calendar', 'un.cc.ult.s': 'You do it only once: from then on new or changed dates arrive by themselves. Google Calendar updates them every few hours.',
  'un.cc.ios': 'iPhone, iPad or Mac', 'un.cc.goo': 'Google Calendar', 'un.cc.out': 'Outlook', 'un.cc.copia': 'Copy the address', 'un.cc.via.q': 'Disconnect the calendar? The dates disappear from the calendar the next time it updates.',
  'un.cc.st': 'In the calendar', 'un.av.t': 'Today’s reminders', 'un.av.b': 'Open the deadlines',
});

var UN = {d: null, filtro: 'tutti', es: null};
const UN_PAESI = ['it', 'nl', 'uk', 'altro'], UN_TIPI = ['triennale', 'magistrale', 'ciclo', 'master'], UN_ST = ['esame', 'iscrizione', 'tasse', 'altro'];
const unIco = (ico, fam) => `<span class="ico ${fam}"><svg><use href="#${ico}"/></svg></span>`;
const unNum = x => x == null ? '—' : num(Math.round(x * 100) / 100);
const unPw = () => UN.d && UN.d.percorso.tipo === 'master';
function unVoto(e) {
  if (e.idoneo) return t('un.idoneo');
  if (e.voto == null) return '';
  return num(e.voto) + (e.lode ? ' ' + t('un.lode') : '');
}
function unGiorni(g) { return g === 0 ? t('un.gg0') : g === 1 ? t('un.gg1') : g > 1 ? t('un.gg', {n: g}) : t('un.ggp', {n: -g}); }
async function unCarica() { UN.d = await A.uni_info(); unConta(); return UN.d; }
function unConta() {
  if (!UN.d || !$('navUni')) return;
  const n = UN.d.scadenze.filter(s => !s.fatto && s.giorni >= 0 && s.giorni <= 7).length;
  $('navUni').textContent = n; $('navUni').classList.toggle('hidden', !n);
}
function contaUni() { if (A && A.uni_info) A.uni_info().then(d => { if (d && d.ok) { UN.d = d; unConta(); unAvvisi(d); } }).catch(() => {}); }
/* Sul PC e sul web i promemoria di oggi (esame tra 14, 7, 1 giorni…) si vedono all'apertura, una volta al giorno;
   sul telefono arrivano come notifiche (anche ad app chiusa). */
function unAvvisi(d) {
  if (ANDROID || !d.promemoria || !d.promemoria.length) return;
  const k = 'unAvvisi:' + d.oggi;
  try { if (localStorage.getItem(k)) return; localStorage.setItem(k, '1'); } catch (e) {}
  setTimeout(() => dialogo({titolo: t('un.av.t'), html: `<div class="unletti">${d.promemoria.map(p => `<div class="unck"><svg class="unccv" style="color:#b45309"><use href="#g-cal"/></svg><span class="sp"><b style="color:var(--ink)">${esc(p.titolo)}</b><small style="display:block">${esc(p.testo)}</small></span></div>`).join('')}</div>`,
    bottoni: [{t: t('annulla'), v: false}, {t: t('un.av.b'), cls: 'b-main', fn: () => { const v = document.querySelector('.velo'); if (v) v.remove(); vai('ua'); }}]}), 2500);
}
function unVai(p) {
  if (p === 'uni') unPrincipale();
  if (p === 'ul') unLibretto();
  if (p === 'ue') unEsame();
  if (p === 'ua') unAppelli();
  if (p === 'ut') unTesi();
}
function unNome(p) {
  if (p === 'ue' && UN.es) { const e = UN.d && UN.d.esami.find(x => x.id === UN.es); return e ? e.nome : t('un.lib'); }
  if (p === 'ut') return t(unPw() ? 'un.pw' : 'un.tesi');
  return {uni: t('un.h'), ul: t('un.lib'), ua: t('un.app')}[p] || '';
}

/* --------------------------------------------------------------- pagina principale */
async function unPrincipale() {
  const d = await unCarica();
  if (pagina !== 'uni') return;
  const p = d.percorso, r = d.riepilogo, sc = r.scala;
  const cred = sc.crediti || '';
  let testa;
  if (!p.corso && !d.esami.length) {
    testa = `<div class="card unperc"><div class="row unvuoto" style="gap:12px;flex-wrap:wrap">${unIco('g-uni', 'fam-studio')}<div class="sp"><b style="color:var(--ink)">${esc(t('un.nuovo.t'))}</b><div class="hint">${esc(t('un.nuovo.s'))}</div></div><button class="btn b-main b-sm" data-un="perc">${esc(t('un.nuovo.b'))}</button></div></div>`;
  } else {
    const tipo = [t('un.tl.' + r.tipo), p.anno ? t('un.anno', {n: p.anno}) : '', p.uni].filter(Boolean).join(' · ');
    const pr = r.totale ? Math.min(100, Math.round(r.crediti / r.totale * 100)) : 0;
    const terzo = sc.paese === 'it' && r.tipo !== 'master' ? [r.partenza == null ? '—' : num(r.partenza), t('un.part')]
      : sc.paese === 'uk' ? [r.classe ? t('un.c.' + r.classe).split(' ')[0] : '—', t('un.classe')] : [r.piu_alto == null ? '—' : num(r.piu_alto), t('un.alto')];
    const nota = sc.paese === 'it' ? t(r.tipo === 'master' ? 'un.h.itm' : 'un.h.it') : t('un.h.' + sc.paese);
    testa = `<div class="card unperc"><div class="row"><div class="sp"><b class="unc">${esc(p.corso || t('un.tl.' + r.tipo))}</b><div class="hint" style="margin:2px 0 0">${esc(tipo)}</div></div><button class="btn b-ghost b-sm" data-un="perc">${esc(t('un.mod'))}</button></div>
      <div class="unprog"><i style="width:${pr}%"></i></div><small class="hint">${esc(t(r.mancano ? 'un.cred' : 'un.cred.f', {f: num(r.crediti), c: cred, t: num(r.totale), m: num(r.mancano)}))}</small>
      <div class="un3"><div><b>${esc(unNum(r.media))}</b><small>${esc(t('un.media'))}</small></div><div><b>${esc(terzo[0])}</b><small>${esc(terzo[1])}</small></div><div><b>${r.fatti}</b><small>${esc(t('un.fatti', {n: r.esami}))}</small></div></div>
      <div class="hint" style="margin-top:8px">${esc(nota)}</div></div>`;
  }
  const vicine = d.scadenze.filter(s => !s.fatto && s.giorni >= 0 && s.giorni <= 7).length;
  const prossima = d.scadenze.find(s => !s.fatto && s.giorni >= 0);
  const fare = $('navFare') && !$('navFare').classList.contains('hidden') ? +$('navFare').textContent : 0;
  const tl = (k, ico, fam, tit, sub, n) => `<button class="tile untile" data-ut="${k}">${unIco(ico, fam)}<span><b>${esc(tit)}</b><small>${esc(sub)}</small></span>${n ? `<span class="unbd">${n}</span>` : ''}</button>`;
  $('unBox').innerHTML = testa + `<div class="tiles untiles">
      ${tl('ul', 'g-libro', 'fam-studio', t('un.lib'), t('un.lib.s'), 0)}
      ${tl('ua', 'g-cal', 'fam-prova', t('un.app'), prossima ? t('un.pross.app', {t: prossima.titolo, d: unGiorni(prossima.giorni)}) : t('un.app.s'), vicine)}
      ${tl('fare', 'g-ok', 'fam-mappe', t('nav.fare'), t('un.fare.s'), fare)}
      ${tl('ut', 'g-uni', 'fam-scrivi', t(unPw() ? 'un.pw' : 'un.tesi'), t(unPw() ? 'un.pw.s' : 'un.tesi.s'), 0)}</div>`;
  $('unBox').querySelectorAll('[data-un="perc"]').forEach(b => b.onclick = unPercorso);
  $('unBox').querySelectorAll('[data-ut]').forEach(b => b.onclick = () => {
    if (b.dataset.ut === 'fare') { STORIA = ['uni']; vai('fare', true); return; }
    vai(b.dataset.ut);
  });
}

/* finestra con i campi: torna {chiave: valore} o null */
function unForm(titolo, html, si, extra) {
  return new Promise(ok => {
    const v = document.createElement('div'); v.className = 'velo';
    v.innerHTML = `<div class="dlg unform"><h3>${esc(titolo)}</h3>${html}<div class="bt">${extra ? `<button class="btn b-sm b-ghost unx" data-v="extra" style="margin-right:auto">${esc(extra)}</button>` : ''}<button class="btn b-sm b-ghost" data-v="no">${esc(t('annulla'))}</button><button class="btn b-sm b-main" data-v="si">${esc(si || t('un.salva'))}</button></div></div>`;
    v.querySelectorAll('.unseg').forEach(g => g.querySelectorAll('span').forEach(s => s.onclick = () => {
      g.querySelectorAll('span').forEach(x => x.classList.toggle('on', x === s)); g.dataset.v = s.dataset.v;
      if (g.onscelta) g.onscelta(s.dataset.v);
    }));
    v.querySelectorAll('.bt button').forEach(b => b.onclick = () => {
      if (b.dataset.v === 'no') { v.remove(); ok(null); return; }
      const out = {};
      v.querySelectorAll('[data-k]').forEach(e => { if (e.type === 'radio') { if (e.checked) out[e.dataset.k] = e.value; return; } out[e.dataset.k] = e.classList.contains('unseg') ? e.dataset.v : e.type === 'checkbox' ? e.checked : e.value; });
      if (b.dataset.v === 'extra') out._extra = true;
      v.remove(); ok(out);
    });
    v.addEventListener('keydown', e => { if (e.key === 'Escape') { v.remove(); ok(null); } });
    document.body.appendChild(v);
    if (unForm.dopo) { unForm.dopo(v); unForm.dopo = null; }
  });
}
const unSeg = (k, valori, scelto, nome) => `<div class="unseg" data-k="${k}" data-v="${esc(scelto)}">${valori.map(x => `<span data-v="${x}" class="${x === scelto ? 'on' : ''}">${esc(nome(x))}</span>`).join('')}</div>`;
const unIn = (k, val, ph, tipo = 'text', extra = '') => `<input class="in unin" data-k="${k}" type="${tipo}" value="${esc(val ?? '')}" placeholder="${esc(ph)}" ${extra}>`;
const unLab = s => `<div class="lbl" style="margin:10px 0 4px">${esc(s)}</div>`;

async function unPercorso() {
  const p = (UN.d && UN.d.percorso) || {};
  const paese = p.paese || 'it', tipo = p.tipo || 'triennale';
  const html = unIn('corso', p.corso, t('un.f.corso')) + unSeg('tipo', UN_TIPI, tipo, x => t('un.t.' + x)) + unIn('uni', p.uni, t('un.f.uni')) +
    unLab(t('un.f.paese')) + unSeg('paese', UN_PAESI, paese, x => t('un.p.' + x)) + `<div class="hint" id="unPH">${esc(t('un.ph.' + paese))}</div>` +
    `<div class="un2"><label>${esc(t('un.f.anno'))}${unIn('anno', p.anno, '1', 'number', 'min="1" max="8"')}</label><label>${esc(t('un.f.tot'))}${unIn('cfu_tot', p.cfu_tot, '', 'number', 'min="1"')}</label></div>` +
    `<div class="un2" id="unAltro" style="${paese === 'altro' ? '' : 'display:none'}"><label>${esc(t('un.f.max'))}${unIn('voto_max', p.voto_max, '30', 'number')}</label><label>${esc(t('un.f.min'))}${unIn('voto_min', p.voto_min, '18', 'number')}</label><label>${esc(t('un.f.ncred'))}${unIn('nome_crediti', p.nome_crediti, 'CFU')}</label></div>`;
  unForm.dopo = v => {
    const g = v.querySelector('.unseg[data-k="paese"]');
    g.onscelta = x => { v.querySelector('#unPH').textContent = t('un.ph.' + x); v.querySelector('#unAltro').style.display = x === 'altro' ? '' : 'none'; };
  };
  const r = await unForm(t('un.perc.t'), html);
  if (!r) return;
  UN.d = await A.uni_percorso(r); unConta();
  unPrincipale();
}

/* --------------------------------------------------------------- libretto */
async function unLibretto() {
  if (!UN.d) await unCarica();
  if (pagina !== 'ul') return;
  const d = UN.d, r = d.riepilogo;
  $('ulSub').textContent = t('un.lib.sub', {n: d.esami.length, f: r.fatti});
  const fatto = e => e.idoneo || e.voto != null;
  const L = d.esami.filter(e => UN.filtro === 'tutti' || (UN.filtro === 'fatti' ? fatto(e) : !fatto(e)));
  const cred = r.scala.crediti || '';
  $('ulBox').innerHTML = `<div class="row" style="gap:8px;flex-wrap:wrap"><button class="btn b-main b-sm" id="ulFoto"><svg><use href="#g-foto"/></svg>${esc(t('un.foto'))}</button><button class="btn b-ghost b-sm" id="ulMano">${esc(t('un.mano'))}</button></div>
    <div class="hint" style="margin:8px 0 4px">${esc(t('un.foto.h'))}</div>
    ${unSeg('', ['tutti', 'fatti', 'dafare'], UN.filtro, x => t('un.f.' + x)).replace('data-k=""', 'id="ulFil"')}
    <div class="card">${!d.esami.length ? `<div class="hint">${esc(t('un.vuoto.lib'))}</div>` : !L.length ? `<div class="hint">${esc(t('un.niente'))}</div>` :
      L.map(e => `<div class="unes" data-id="${e.id}"><div class="sp"><b>${esc(e.nome)}</b><small>${esc([e.cfu ? `${num(e.cfu)} ${cred}`.trim() : '', e.anno, e.materia ? '● ' + e.materia : ''].filter(Boolean).join(' · '))}</small></div><span class="unv ${fatto(e) ? 'ok' : 'no'}">${esc(fatto(e) ? unVoto(e) : t('un.dafare'))}</span></div>`).join('')}</div>`;
  $('ulFil').querySelectorAll('span').forEach(s => s.onclick = () => { UN.filtro = s.dataset.v; unLibretto(); });
  $('ulBox').querySelectorAll('.unes').forEach(x => x.onclick = () => { UN.es = x.dataset.id; vai('ue'); });
  $('ulMano').onclick = () => unEsameForm(null);
  $('ulFoto').onclick = () => unFoto('libretto');
}
async function unEsameForm(e) {
  const html = unIn('nome', e && e.nome, t('un.f.nome')) + `<div class="un2"><label>${esc(t('un.f.cfu'))}${unIn('cfu', e && e.cfu, '', 'number', 'min="0" step="0.5"')}</label><label>${esc(t('un.f.voto'))}${unIn('voto', e ? (e.idoneo ? t('un.idoneo') : e.voto == null ? '' : String(e.voto) + (e.lode ? ' L' : '')) : '', '')}</label></div>` +
    `<div class="un2"><label>${esc(t('un.f.annoes'))}${unIn('anno', e && e.anno, '')}</label><label>${esc(t('un.f.data'))}${unIn('data', e && e.data, '', 'date')}</label></div>`;
  const r = await unForm(t(e ? 'un.es.mod' : 'un.es.t'), html, null, e ? t('un.togli') : '');
  if (!r) return;
  if (r._extra) {
    if (!await conferma(t('un.togli'), t('un.togli.q', {n: e.nome}), t('un.togli'), t('annulla'), 'b-red')) return;
    UN.d = await A.uni_esame({id: e.id, togli: true}); unConta();
    if (pagina === 'ue') { const b = document.querySelector('#v-ue .torna'); if (b) b.click(); else vai('ul'); } else unLibretto();
    return;
  }
  if (!String(r.nome || '').trim()) return;
  delete r._extra;
  UN.d = await A.uni_esame(e ? {...r, id: e.id} : r); unConta();
  if (pagina === 'ue') unEsame(); else unLibretto();
}

/* --------------------------------------------------------------- un esame */
async function unEsame() {
  if (!UN.d) await unCarica();
  const e = UN.d.esami.find(x => x.id === UN.es);
  if (!e) { vai('ul'); return; }
  if (!LZ) await caricaLezioni();
  if (pagina !== 'ue') return;
  if (STORIA.length) barraPercorso('ue');
  const r = UN.d.riepilogo, fatto = e.idoneo || e.voto != null;
  $('ueH').textContent = e.nome;
  $('ueSub').textContent = t('un.es.sub', {c: num(e.cfu || 0), a: e.anno ? ' · ' + e.anno : '', s: fatto ? t('un.es.fatto', {v: unVoto(e)}) : t('un.dafare')});
  const app = UN.d.scadenze.filter(s => s.esame === e.id && !s.fatto && s.giorni >= 0);
  const M = materieStudia(), m = e.materia && M.find(x => x.m.toLowerCase() === e.materia.toLowerCase());
  const esApp = app.find(s => s.tipo === 'esame');
  const vm = !e.materia ? `<div class="unrg"><div class="sp"><b>${esc(t('un.mat.no'))}</b><small>${esc(t('un.mat.s'))}</small></div><button class="btn b-ghost b-sm" data-ue="mat">${esc(t('un.mat.scegli'))}</button></div>`
    : `<div class="unrg"><div class="sp"><b>${esc(m ? t(m.lez.length === 1 ? 'un.mat.lez1' : 'un.mat.lez', {n: m.lez.length}) : e.materia)}</b><small>${esc(t('un.mat.cart', {m: e.materia}))}</small></div>${m ? `<button class="btn b-ghost b-sm" data-ue="studia">${esc(t('un.apri'))}</button>` : ''}<button class="btn b-ghost b-sm" data-ue="mat">${esc(t('un.cambia'))}</button></div>` +
      (m ? `<div class="unrg"><div class="sp"><b>${esc(t('un.prep'))}</b><small>${esc(esApp ? t('un.prep.s2', {d: fmtG(esApp.data, {day: 'numeric', month: 'long'})}) : t('un.prep.s'))}</small></div><button class="btn b-ghost b-sm" data-ue="prep">${esc(t('un.apri'))}</button></div>
        <div class="unrg"><div class="sp"><b>${esc(t('tl.tu'))}</b><small>${esc(t('un.tutor.s'))}</small></div><button class="btn b-ghost b-sm" data-ue="tutor">${esc(t('un.apri'))}</button></div>` : '');
  $('ueBox').innerHTML = `<div class="card"><div class="lbl">${esc(t('un.pross'))}</div>${app.length ? app.map(unRigaScad).join('') : `<div class="hint">${esc(t('un.nessun.app'))}</div>`}
      <div class="row mt" style="gap:8px;flex-wrap:wrap"><button class="btn b-ghost b-sm" data-ue="app">${esc(t('un.add.app'))}</button><button class="btn b-ghost b-sm" data-ue="voto">${esc(fatto ? t('un.mod') : t('un.voto.b'))}</button></div></div>
    <div class="card mt"><div class="lbl">${esc(t('un.invm'))}</div>${vm}</div>`;
  unCollegaScad($('ueBox'));
  $('ueBox').querySelectorAll('[data-ue]').forEach(b => b.onclick = async () => {
    const a = b.dataset.ue;
    if (a === 'app') return unScadForm(null, {esame: e.id, tipo: 'esame'});
    if (a === 'voto') return unEsameForm(e);
    if (a === 'mat') return unMateria(e);
    if (a === 'studia') return apriStudia(m.m);
    if (a === 'prep') return apriEsame({m: m.m, cartelle: m.cartelle});
    if (a === 'tutor') return apriTutor(m);
  });
}
async function unMateria(e) {
  const M = materieStudia();
  const html = M.length ? `<div class="unscelta">${[...M.map(x => x.m), ''].map(x => `<label class="ck"><input type="radio" name="unm" data-k="materia" value="${esc(x)}" ${(e.materia || '').toLowerCase() === x.toLowerCase() ? 'checked' : ''}> ${esc(x || t('un.mat.nessuna'))}</label>`).join('')}</div>`
    : `<div class="hint">${esc(t('un.mat.vuote'))}</div>`;
  const r = await unForm(t('un.mat.scegli'), html);
  if (!r || !M.length || r.materia == null) return;
  UN.d = await A.uni_esame({id: e.id, materia: r.materia});
  unEsame();
}

/* --------------------------------------------------------------- appelli e scadenze */
function unRigaScad(s) {
  const dt = new Date(s.data + 'T12:00'), gg = dt.getDate(), mm = dt.toLocaleDateString(LINGUA === 'en' ? 'en-GB' : 'it-IT', {month: 'short'}).replace('.', '');
  const tag = s.fatto ? `<span class="untag ok">${esc(t('un.fatta'))}</span>` : s.giorni >= 0 && s.giorni <= 14 ? `<span class="untag ar">${esc(s.tipo === 'iscrizione' && s.giorni <= 7 ? t('un.iscriviti') + ' · ' + unGiorni(s.giorni) : unGiorni(s.giorni))}</span>` : '';
  return `<div class="unsc${s.fatto ? ' fatta' : ''}" data-sid="${s.id}"><div class="undata"><b>${gg}</b><small>${esc(mm)}</small></div><div class="sp"><b>${esc(s.titolo)}</b><small>${esc([s.ora, s.nota].filter(Boolean).join(' · '))}</small></div>${tag}</div>`;
}
function unCollegaScad(box) {
  box.querySelectorAll('.unsc[data-sid]').forEach(x => x.onclick = () => { const s = UN.d.scadenze.find(y => y.id === x.dataset.sid); if (s) unScadForm(s); });
}
async function unAppelli() {
  if (!UN.d) await unCarica();
  if (pagina !== 'ua') return;
  const prossime = UN.d.scadenze.filter(s => s.giorni >= 0), passate = UN.d.scadenze.filter(s => s.giorni < 0).reverse().slice(0, 30);
  $('uaBox').innerHTML = `<div class="row" style="gap:8px;flex-wrap:wrap;margin-bottom:10px"><button class="btn b-main b-sm" id="uaAdd">${esc(t('un.add'))}</button><button class="btn b-ghost b-sm" id="uaFoto"><svg><use href="#g-foto"/></svg>${esc(t('un.foto.app'))}</button></div><div id="uaCC"></div>
    <div class="card">${prossime.length ? prossime.map(unRigaScad).join('') : `<div class="hint">${esc(t('un.vuoto.app'))}</div>`}</div>
    ${passate.length ? `<details class="card mt unpass"><summary class="lbl" style="cursor:pointer">${esc(t('un.passate'))} (${passate.length})</summary>${passate.map(unRigaScad).join('')}</details>` : ''}`;
  unCollegaScad($('uaBox'));
  $('uaAdd').onclick = () => unScadForm(null, {tipo: 'esame'});
  $('uaFoto').onclick = () => unFoto('appelli');
  unCalCard($('uaCC'));
}
/* calendario sempre aggiornato (scelta 1A di Paolo, 09/11/2026) */
async function unCalCard(box) {
  if (!box) return;
  const c = await A.uni_calendario_stato();
  if (!box.isConnected) return;
  box.innerHTML = c.attivo
    ? `<div class="card unccok"><div class="row" style="gap:10px;flex-wrap:wrap"><svg class="unccv"><use href="#g-ok"/></svg><b class="sp" style="color:var(--ink);min-width:180px">${esc(t('un.cc.ok'))}</b><button class="btn b-ghost b-sm" id="ccAltro">${esc(t('un.cc.altro'))}</button><button class="lnk" id="ccVia">${esc(t('un.cc.via'))}</button></div></div>`
    : `<div class="card"><div class="row unvuoto" style="gap:12px;flex-wrap:wrap">${unIco('g-cal', 'fam-prova')}<div class="sp"><b style="color:var(--ink)">${esc(t('un.cc.t'))}</b><div class="hint">${esc(t('un.cc.s'))}</div></div><button class="btn b-main b-sm" id="ccSi">${esc(t('un.cc.b'))}</button></div></div>`;
  if ($('ccSi')) $('ccSi').onclick = () => unCalCollega(() => unCalCard(box));
  if ($('ccAltro')) $('ccAltro').onclick = () => unCalScegli(c);
  if ($('ccVia')) $('ccVia').onclick = async () => { if (!await conferma(t('un.cc.via'), t('un.cc.via.q'), t('un.cc.via'), t('annulla'), 'b-red')) return; await A.uni_calendario_collega(false); unCalCard(box); };
}
async function unCalCollega(dopo) {
  const v = document.createElement('div'); v.className = 'velo';
  v.innerHTML = `<div class="dlg"><div class="row" style="gap:10px"><span class="spin"></span>${esc(t('un.cc.lav'))}</div></div>`;
  document.body.appendChild(v);
  let r; try { r = await A.uni_calendario_collega(true); } finally { v.remove(); }
  if (!r || !r.ok) { await dialogo({titolo: t('un.cc.t'), testo: (r && r.msg) || ''}); if (dopo) dopo(); return; }
  if (dopo) dopo();
  unCalScegli(r);
}
function unCalScegli(c) {
  const ios = typeof IPHONE !== 'undefined' && IPHONE, and = ANDROID && !ios;
  const vai_ = u => { apriUrl(u); const x = document.querySelector('.velo'); if (x) x.remove(); };
  dialogo({titolo: t('un.cc.ult'), testo: t('un.cc.ult.s'), bottoni: [
    {t: t('un.cc.copia'), fn: () => copiaTesto(c.ics)},
    ...(and ? [] : [{t: t('un.cc.ios'), cls: ios ? 'b-main' : 'b-ghost', fn: () => vai_(c.webcal)}]),
    {t: t('un.cc.out'), fn: () => vai_(c.outlook)},
    {t: t('un.cc.goo'), cls: ios ? 'b-ghost' : 'b-main', fn: () => vai_(c.google)}]});
}
/* Studia: accanto alla data dell'esame, se il calendario non è collegato */
async function unCalStudia() {
  const g = document.querySelector('#stBox2 .stgg');
  if (!g || g.querySelector('.unccst')) return;
  const c = await A.uni_calendario_stato();
  if (!g.isConnected || g.querySelector('.unccst')) return;
  const b = document.createElement('button');
  b.className = 'btn b-ghost b-sm unccst';
  b.innerHTML = c.attivo ? `<svg><use href="#g-ok"/></svg>${esc(t('un.cc.st'))}` : `<svg><use href="#g-cal"/></svg>${esc(t('un.cc.st'))}`;
  b.onclick = () => c.attivo ? unCalScegli(c) : unCalCollega(() => { b.remove(); unCalStudia(); });
  g.appendChild(b);
}
async function unScadForm(s, base = {}) {
  const x = s || base;
  const esami = UN.d.esami.filter(e => !(e.idoneo || e.voto != null) || e.id === x.esame);
  const html = unLab(t('un.sc.tipo')) + unSeg('tipo', UN_ST, x.tipo || 'esame', y => t('un.st.' + y)) +
    (esami.length ? `<label>${esc(t('un.f.esame'))}<select class="in unin" data-k="esame"><option value="">—</option>${esami.map(e => `<option value="${e.id}" ${e.id === x.esame ? 'selected' : ''}>${esc(e.nome)}</option>`).join('')}</select></label>` : '') +
    unIn('cosa', x.cosa, t('un.f.cosa')) +
    `<div class="un2"><label>${esc(t('un.f.quando'))}${unIn('data', x.data || UN.d.oggi, '', 'date')}</label><label>${esc(t('un.f.ora'))}${unIn('ora', x.ora, '', 'time')}</label></div>` + unIn('nota', x.nota, t('un.f.nota')) +
    (s ? `<label class="ck"><input type="checkbox" data-k="fatto" ${s.fatto ? 'checked' : ''}> ${esc(t('un.fatta'))}</label>` : '');
  const r = await unForm(t(s ? 'un.sc.mod' : 'un.sc.t'), html, null, s ? t('un.togli') : '');
  if (!r) return;
  if (r._extra) UN.d = await A.uni_scadenza({id: s.id, togli: true});
  else {
    delete r._extra;
    if (!r.data || (!r.esame && !String(r.cosa || '').trim())) return;
    UN.d = await A.uni_scadenza(s ? {...r, id: s.id} : r);
  }
  unConta();
  unVai(pagina);
}
async function unCalendario() {
  const fai = modo => { A.uni_calendario(null, modo); const v = document.querySelector('.velo'); if (v) v.remove(); };
  dialogo({titolo: t('un.cal.t'), testo: t('un.cal.s'), bottoni: ANDROID || SUL_WEB() ? [{t: t('annulla'), v: false}, {t: t('cd.cal.tel'), cls: 'b-main', fn: () => fai('telefono')}]
    : [{t: t('annulla'), v: false}, {t: 'Google Calendar', fn: () => fai('google')}, {t: 'Outlook', cls: 'b-main', fn: () => fai('outlook')}]});
}

/* --------------------------------------------------------------- foto del libretto / degli appelli */
async function unFoto(cosa) {
  if (SUL_WEB()) { $('unFile').dataset.cosa = cosa; $('unFile').click(); return; }
  const come = await dialogo({titolo: t(cosa === 'appelli' ? 'un.foto.app' : 'un.foto'), testo: t('un.foto.come'), bottoni: [{t: t('annulla'), v: false}, {t: t('un.foto.pdf'), v: 'p'},
    ...(ANDROID ? [{t: t('un.foto.scatta'), v: 's'}] : []), {t: t('un.foto.gal'), cls: 'b-main', v: 'g'}]});
  if (!come) return;
  let per = [];
  if (come === 'p') { const f = await A.scegli_pdf(); if (f && f.ok && f.percorso) per = [f.percorso]; }
  else { const s = come === 's' ? await A.scatta_foglio() : await A.scegli_immagini(); per = s && s.ok ? (s.percorsi || []) : []; }
  if (!per.length) return;
  if (come !== 'p' && !await conferma(t(cosa === 'appelli' ? 'un.foto.app' : 'un.foto'), t('un.foto.q', {n: per.length, c: num((per.length * 0.01).toFixed(2))}), t('si'), t('annulla'))) return;
  unLetti(cosa, () => A.uni_leggi(per, cosa));
}
async function unLetti(cosa, chiama) {
  const v = document.createElement('div'); v.className = 'velo';
  v.innerHTML = `<div class="dlg"><div class="row" style="gap:10px"><span class="spin"></span>${esc(t(cosa === 'appelli' ? 'un.legge.app' : 'un.legge'))}</div></div>`;
  document.body.appendChild(v);
  let r; try { r = await chiama(); } finally { v.remove(); }
  if (!r || !r.ok) { if (r && r.msg) dialogo({titolo: t(cosa === 'appelli' ? 'un.app' : 'un.lib'), testo: r.msg}); return; }
  const L = cosa === 'appelli' ? r.appelli : r.esami;
  const riga = (x, i) => cosa === 'appelli'
    ? `<label class="ck unck"><input type="checkbox" checked data-i="${i}"> <span class="sp">${esc(x.esame)} · ${esc(fmtG(x.data, {day: 'numeric', month: 'short', year: 'numeric'}))}${x.ora ? ' ' + esc(x.ora) : ''}</span><small>${esc(x.tipo || '')}</small></label>`
    : `<label class="ck unck"><input type="checkbox" checked data-i="${i}"> <span class="sp">${esc(x.nome)}${x.cfu ? ' · ' + esc(num(x.cfu)) : ''}</span><b>${esc(x.voto || '')}</b></label>`;
  dialogo({titolo: t(cosa === 'appelli' ? 'un.letti.app' : 'un.letti.t', {n: L.length}), testo: t('un.letti.s'),
    html: `<div class="unletti">${L.map(riga).join('')}</div>`, bottoni: [{t: t('annulla'), v: false}, {t: t('un.salva.n', {n: L.length}), cls: 'b-main', fn: async () => {
      const box = document.querySelector('.velo .unletti');
      const scelti = [...box.querySelectorAll('input[data-i]')].filter(i => i.checked).map(i => L[+i.dataset.i]);
      document.querySelector('.velo').remove();
      const x = await A.uni_salva_letti(scelti, cosa, r.corso || '', r.uni || '');
      UN.d = x; unConta();
      toast(cosa === 'appelli' ? t('un.ok.app', {n: x.n}) : t('un.ok.lib', {n: x.n, c: x.cambiati}));
      unVai(pagina);
    }}]});
}
function unDaFile(f) {
  const cosa = $('unFile').dataset.cosa || 'libretto';
  const fr = new FileReader();
  fr.onload = () => { const b64 = String(fr.result).split(',')[1] || ''; unLetti(cosa, () => A.uni_leggi_file(f.name, b64, cosa)); };
  fr.readAsDataURL(f);
}

/* --------------------------------------------------------------- tesi */
async function unTesi() {
  if (!UN.d) await unCarica();
  if (pagina !== 'ut') return;
  const x = UN.d.tesi || {}, pw = unPw(), nome = t(pw ? 'un.pw' : 'un.tesi');
  $('utH').textContent = nome;
  if (STORIA.length) barraPercorso('ut');
  const chi = [x.relatore ? t('un.t.rel', {r: x.relatore}) : '', x.correlatore ? t('un.t.corr', {c: x.correlatore}) : '', x.azienda ? t('un.t.az', {a: x.azienda}) : ''].filter(Boolean).join(' · ');
  const scad = UN.d.scadenze.filter(s => !s.fatto && s.giorni >= 0 && (s.tipo === 'altro' || s.tipo === 'tasse')).slice(0, 6);
  const M = materieStudia(), mt = M.find(m => /tesi|thesis|project/i.test(m.m));
  $('utBox').innerHTML = `<div class="card"><div class="row"><div class="lbl sp" style="margin:0">${esc(t('un.t.titolo'))}</div><button class="btn b-ghost b-sm" id="utMod">${esc(t('un.mod'))}</button></div>
      ${x.titolo || chi ? `<b style="color:var(--ink);display:block;margin-top:6px">${esc(x.titolo || '')}</b><div class="hint">${esc(chi)}</div>` : `<div class="hint">${esc(t('un.t.vuoto'))}</div>`}
      ${x.note ? `<div class="lbl" style="margin:10px 0 2px">${esc(t('un.t.note'))}</div><div class="hint" style="white-space:pre-wrap">${esc(x.note)}</div>` : ''}</div>
    <div class="card mt"><div class="lbl">${esc(t('un.t.scad'))}</div>${scad.length ? scad.map(unRigaScad).join('') : ''}<div class="hint">${esc(t('un.t.scad.s'))}</div>
      <div class="row" style="margin-top:6px"><button class="btn b-ghost b-sm" id="utScad">${esc(t('un.add'))}</button></div></div>
    <div class="card mt"><div class="lbl">${esc(t('un.t.doc'))}</div><div class="hint">${esc(t('un.t.doc.s', {m: mt ? mt.m : nome}))}</div>${mt ? `<div class="row" style="margin-top:6px"><button class="btn b-ghost b-sm" id="utLibro">${esc(t('un.t.doc.b'))}</button></div>` : ''}</div>`;
  unCollegaScad($('utBox'));
  $('utScad').onclick = () => unScadForm(null, {tipo: 'altro'});
  if ($('utLibro')) $('utLibro').onclick = () => apriLibro(mt);
  $('utMod').onclick = async () => {
    const html = unIn('titolo', x.titolo, t('un.f.titolo')) + unIn('relatore', x.relatore, t('un.f.rel')) + unIn('correlatore', x.correlatore, t('un.f.corr')) +
      (pw ? unIn('azienda', x.azienda, t('un.f.az')) : '') + `<textarea class="in unin" data-k="note" rows="4" placeholder="${esc(t('un.f.note'))}">${esc(x.note || '')}</textarea>`;
    const r = await unForm(nome, html);
    if (!r) return;
    UN.d = await A.uni_tesi(r);
    unTesi();
  };
}

document.addEventListener('DOMContentLoaded', () => {
  const f = $('unFile');
  if (f) f.onchange = () => { const x = f.files[0]; f.value = ''; if (x) unDaFile(x); };
});
