/* Registra più corta (anteprima 43, approvata da Paolo il 03/11/2026: «per registrare bisogna scorrere tutta la pagina»).
   Solo Verba Manent (Scripta Manent ha la sua impaginazione in schede.js).
   - In cima un riquadro solo: Materia e Nome della lezione, Online / In aula (sul PC) con le lineette del microfono,
     il tasto REGISTRA e una riga con le scelte di adesso.
   - «Altre scelte» (riquadro chiuso): Lezione/Riunione/Webinar, i dettagli di Online e In aula, la lingua del docente,
     i Materiali del prof e (sul telefono) «Quando trascrivo».
   - Sotto, ben visibile: «Hai già un video, un audio o il testo della lezione? Importa un file…».
   Sposta gli elementi che ci sono già (stessi id, stessi tasti): non cambia cosa fa ogni tasto. */
'use strict';
(function () {
  const q = (s, r) => (r || document).querySelector(s);
  const tr = (it, en) => (typeof LINGUA !== 'undefined' && LINGUA === 'en' ? en : it);
  const scripta = () => document.documentElement.classList.contains('scripta');
  const tel = () => document.documentElement.classList.contains('android');

  function monta() {
    const pg = q('#v-pronto');
    if (!pg || pg.dataset.qk || scripta() || typeof t !== 'function' || typeof R === 'undefined' || Object.keys(R || {}).length < 3) return;   // dopo il riepilogo: lingua ed edizione sono gia' quelle giuste
    const tipo = q('#tipoBox', pg), dove = q('#doveBox', pg), nome = q('#nome', pg), mat = q('#materia', pg), recw = q('.recwrap', pg);
    if (!tipo || !dove || !nome || !mat || !recw || !q('#hoPronto', pg)) return;
    pg.dataset.qk = 1;
    const ct = tipo.closest('.card'), cd = dove.closest('.card'), cm = nome.closest('.card');
    // 1. il riquadro in cima
    const qk = document.createElement('div'); qk.className = 'card qk'; qk.id = 'qkCard';
    const due = document.createElement('div'); due.className = 'qk2';
    const c1 = document.createElement('div'), c2 = document.createElement('div');
    c1.innerHTML = `<div class="lbl">${esc(t('mt.h'))}</div>`;
    c2.innerHTML = `<div class="lbl" id="qkNomeLbl">${esc(tr('Nome della lezione', 'Lecture name'))}</div>`;
    c1.append(mat); const rec = q('#recenti', pg); if (rec) c1.append(rec);
    c2.append(nome); ['#nomeMsg', '#nomeAnt'].forEach(s => { const e = q(s, pg); if (e) c2.append(e); });
    due.append(c1, c2); qk.append(due);
    ['#calOra', '#modBox', '#partBox'].forEach(s => { const e = q(s, pg); if (e) qk.append(e); });
    const riga = document.createElement('div'); riga.className = 'qkriga';
    if (!tel()) {
      const dv = document.createElement('div'); dv.className = 'qkdove'; dv.id = 'qkDove';
      dv.innerHTML = `<span data-m="online"><svg><use href="#i-scr"/></svg><div>${esc(t('pr.online.t'))}<small>Meet, Teams, Zoom</small></div></span>`
        + `<span data-m="aula"><svg><use href="#i-mic"/></svg><div>${esc(t('pr.aula.t'))}<small>${esc(tr('microfono del portatile', 'laptop microphone'))}</small></div></span>`;
      dv.addEventListener('click', e => { const s = e.target.closest('[data-m]'); const o = s && q(`#doveBox [data-m="${s.dataset.m}"]`); if (o) { o.click(); stato(); } });
      riga.append(dv);
    }
    riga.append(recw); qk.append(riga);
    const aula = q('#srcAula', pg); if (aula && !tel()) { aula.classList.add('qkmic'); qk.append(aula); }
    const sum = document.createElement('div'); sum.className = 'qksum'; sum.id = 'qkSum'; qk.append(sum);
    q('#hoPronto', pg).after(qk);
    q('#matBox', pg).classList.add('qk-via');
    const nl = q('#nomeLbl', pg); if (nl) nl.classList.add('qk-via');
    // 2. «Altre scelte»
    const det = document.createElement('details'); det.className = 'qkaltro'; det.id = 'qkAltro';
    det.innerHTML = `<summary><span class="ico"><svg><use href="#i-set"/></svg></span><span class="t"><b>${esc(tr('Altre scelte', 'More options'))}</b>`
      + `<small>${esc(tel() ? tr('Lezione o riunione, lingua del docente, materiali del prof, quando trascrivo', 'Lecture or meeting, lecturer\'s language, lecturer\'s materials, when to transcribe')
                           : tr('Lezione o riunione, lingua del docente, materiali del prof', 'Lecture or meeting, lecturer\'s language, lecturer\'s materials'))}</small></span>`
      + `<span class="apri">${esc(tr('Mostra', 'Show'))}</span></summary><div class="qkdentro"></div>`;
    det.addEventListener('toggle', () => { q('.apri', det).textContent = det.open ? tr('Nascondi', 'Hide') : tr('Mostra', 'Show'); });
    qk.after(det);
    [ct, cd, cm, q('#mpCard', pg), q('#quandoCard', pg)].forEach(e => { if (e) q('.qkdentro', det).append(e); });
    // 3. Importa
    const imp = document.createElement('div'); imp.className = 'qkimp'; imp.id = 'qkImp';
    imp.innerHTML = `<span class="ico"><svg><use href="#i-imp"/></svg></span><div class="t"><b>${esc(tr('Hai già un video, un audio o il testo della lezione?', 'Already have a video, an audio or the text of the lecture?'))}</b>`
      + `<small>${esc(tel() ? tr('Un file: ne faccio trascrizione e appunti.', 'A file: I turn it into a transcript and notes.')
                           : tr('Un file, più file o una cartella intera: ne faccio trascrizione e appunti.', 'One file, several files or a whole folder: I turn them into transcripts and notes.'))}</small></div>`
      + `<button class="btn" type="button" id="qkImpB">${esc(tr('Importa un file…', 'Import a file…'))}</button>`;
    det.after(imp);
    q('#qkImpB', imp).onclick = importaQualcosa;
    ['#btnImporta', '#btnImportaTesto', '#prPrima'].forEach(s => { const e = q(s, pg); if (e) e.classList.add('qk-via'); });
    stato();
  }

  window.importaQualcosa = importaQualcosa;
  async function importaQualcosa() {
    if (typeof S !== 'undefined' && S && (S.registro || S.occupato)) { toast(t('aspetta')); return; }
    const b = [{t: t('annulla'), v: null}, {t: tr('Un video o un audio', 'A video or an audio'), cls: 'b-ghost', v: 'vid'}];
    if (tel()) b.push({t: tr('Un testo (PDF, Word…)', 'A text (PDF, Word…)'), cls: 'b-main', v: 'uno'});
    else b.push({t: tr('Una cartella di testi', 'A folder of texts'), cls: 'b-ghost', v: 'cart'}, {t: tr('Uno o più testi', 'One or more texts'), cls: 'b-main', v: 'file'});
    const v = await dialogo({titolo: tr('Cosa vuoi importare?', 'What do you want to import?'),
      testo: tr('Testi: PDF, Word o file di testo con quello che ha detto il docente. Ogni file diventa una lezione.',
                'Texts: PDF, Word or text files with what the lecturer said. Each file becomes a lecture.'), bottoni: b});
    if (v === 'vid') return scegliVideo();
    if (v === 'uno') return scegliTesto();
    if (v === 'file' || v === 'cart') return scegliTesti(v === 'cart');
  }

  // la riga sotto il tasto: cosa registro adesso
  function stato() {
    const sum = q('#qkSum'); if (!sum) return;
    const tp = q('#tipoBox .aiopt.on b'), lg = q('#lingue .chip.on'), m = (q('#doveBox .aiopt.on') || {}).dataset || {};
    document.querySelectorAll('#qkDove [data-m]').forEach(s => s.classList.toggle('on', s.dataset.m === m.m));
    const come = tel() ? tr('microfono del telefono', 'phone microphone')
      : m.m === 'aula' ? tr('microfono', 'microphone') + ((q('#selMic') || {}).selectedOptions?.[0] ? ': ' + q('#selMic').selectedOptions[0].textContent : '')
      : tr('schermo, audio del PC e slide automatiche', 'screen, PC audio and automatic slides');
    const l = lg ? (lg.dataset.l === 'auto' ? tr('lingua riconosciuta da sola', 'language detected automatically') : tr('docente in ', 'lecturer in ') + lg.textContent.toLowerCase()) : '';
    const testo = [tp ? tp.textContent : '', l, come].filter(Boolean).join(' · ');
    if (sum.textContent !== testo) sum.textContent = testo;
    const nl = q('#qkNomeLbl'), k = (q('#tipoBox .aiopt.on') || {}).dataset || {};
    if (nl) nl.textContent = k.k && k.k !== 'lezione' ? t('pr.nome') : tr('Nome della lezione', 'Lecture name');
  }

  document.addEventListener('DOMContentLoaded', () => {
    new MutationObserver(() => { clearTimeout(monta.t); monta.t = setTimeout(monta, 40); }).observe(document.body, {childList: true, subtree: true});
    setInterval(() => { if (!document.hidden) stato(); }, 700);
  });
})();
