# -*- coding: utf-8 -*-
"""
Registra Lezione - tasto Aggiorna.

Il programma e' diviso in due:
  - le librerie (dentro l'exe, 300-400 MB): cambiano quasi mai;
  - il codice (questa cartella "app", qualche MB): cambia a ogni versione.
Aggiorna controlla l'ultima versione pubblicata su GitHub e scarica solo il codice; i video della guida
si scaricano uno per uno, solo quelli cambiati (sincronizza_video; prima tutti insieme in video.zip, 114 MB).
Se la versione nuova richiede librerie diverse, lo dice e apre la pagina per
scaricare il pacchetto completo.
"""
import json
import logging
import shutil
import ssl
import sys
import tempfile
import urllib.request
import zipfile
from pathlib import Path

log = logging.getLogger("registra_lezione")

REPO = "zonerosse/registra-lezione"
QUI = Path(__file__).resolve().parent          # cartella app
RADICE = QUI.parent                            # cartella del programma (dove c'e' l'exe)
NUOVA = RADICE / "app_nuova"


def _leggi(p):
    try:
        return json.loads(Path(p).read_text(encoding="utf-8"))
    except Exception:
        return {}


def versione_locale():
    return _leggi(QUI / "versione.json")


def librerie_installate():
    """Versione delle librerie dentro l'exe (scritta nel modulo dipendenze)."""
    try:
        import dipendenze
        return int(dipendenze.LIBRERIE)
    except Exception:
        return int(versione_locale().get("librerie", 1))


def impronta_video(cartella=None):
    """L'impronta dei video della guida (nomi e grandezze): se e' uguale a quella pubblicata, i video non si riscaricano.
    (01/11/2026, Paolo: «ci mette un casino a scaricare»: l'aggiornamento era di 99 MB, 97 dei video della guida.)"""
    import hashlib
    v = Path(cartella) if cartella else QUI / "interfaccia" / "video"
    righe = sorted(f"{f.relative_to(v).as_posix()}:{f.stat().st_size}" for f in v.rglob("*") if f.is_file()) if v.is_dir() else []
    return hashlib.sha1("\n".join(righe).encode("utf-8")).hexdigest()[:16] if righe else ""


# ------------------------------------------------------------------ video della guida, uno per uno
# 09/11/2026, Paolo: «gli aggiornamenti sono troppo pesanti». Prima bastava cambiare un video perche' si riscaricassero
# tutti (video.zip, 114 MB, anche quelli del telefono). Ora versione.json ha l'elenco «video_file» {nome: [byte, impronta]}
# dei video di quel dispositivo e ogni video sta da solo nel ramo pubblico «video-guida» (f/<impronta><estensione>):
# si scaricano solo quelli nuovi o cambiati e si tolgono quelli che non servono piu'.
VIDEO_URL = "https://raw.githubusercontent.com/zonerosse/registra-lezione/video-guida/f/"
_REMOTA = {}            # l'ultimo versione.json letto da cerca(): serve a video_sottofondo()


def del_telefono(nome):
    """I video della guida del telefono (Android): tel-* e sm-tel-*. Gli altri sono del PC e del Mac."""
    return nome.startswith(("tel-", "sm-tel-"))


def impronta_file(p):
    import hashlib
    h = hashlib.sha1()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()[:16]


def elenco_video(cartella, telefono=False):
    """{nome: [byte, impronta]} dei video della guida di un dispositivo (PC e Mac, oppure telefono)."""
    v = Path(cartella)
    return {f.name: [f.stat().st_size, impronta_file(f)] for f in sorted(v.iterdir())
            if f.is_file() and f.suffix in (".webm", ".mp4") and del_telefono(f.name) == telefono} if v.is_dir() else {}


def video_da_fare(voluti, cartella):
    """(da scaricare, da togliere): i video che mancano o sono diversi, e quelli che non servono piu'."""
    v = Path(cartella)
    scarica = []
    for nome, (byte, imp) in sorted(voluti.items()):
        f = v / nome
        try:
            if f.stat().st_size == byte and impronta_file(f) == imp:
                continue
        except OSError:
            pass
        scarica.append(nome)
    togli = sorted(f.name for f in v.iterdir() if f.is_file() and f.suffix in (".webm", ".mp4") and f.name not in voluti) if v.is_dir() else []
    return scarica, togli


def _scarica_file(url, dest):
    with _apri(url, timeout=60) as r, open(dest, "wb") as f:
        shutil.copyfileobj(r, f, 1 << 16)


SCARICA_FILE = _scarica_file                                  # il telefono usa il suo (Ponte.scarica)
CARTELLA_VIDEO = lambda: QUI / "interfaccia" / "video"         # noqa: E731  (il telefono usa la sua)


def peso_video(voluti, cartella):
    return sum(voluti[n][0] for n in video_da_fare(voluti, cartella)[0])


def sincronizza_video(voluti, cartella, base=VIDEO_URL, progresso=lambda f: None, rigido=True):
    """Scarica i video nuovi o cambiati e toglie quelli che non servono piu'. Ogni video arriva prima in «.nuovo»
    e prende il posto del vecchio solo se e' completo (byte e impronta giusti). rigido=False (in sottofondo): un video
    che non arriva o e' aperto si salta e si riprova la prossima volta. Ritorna quanti video ha scaricato."""
    v = Path(cartella)
    v.mkdir(parents=True, exist_ok=True)
    scarica, togli = video_da_fare(voluti, v)
    tot = sum(voluti[n][0] for n in scarica) or 1
    fatti = letti = 0
    for nome in scarica:
        byte, imp = voluti[nome]
        tmp = v / (nome + ".nuovo")
        try:
            SCARICA_FILE(base + imp + Path(nome).suffix, tmp)
            if tmp.stat().st_size != byte or impronta_file(tmp) != imp:
                raise RuntimeError("video della guida incompleto: " + nome)
            import os
            os.replace(tmp, v / nome)
            fatti += 1
        except Exception:
            try:
                tmp.unlink()
            except OSError:
                pass
            if rigido:
                raise
            log.warning("video della guida %s: non scaricato, riprovo la prossima volta", nome)
        letti += byte
        progresso(min(1.0, letti / tot))
    for nome in togli:
        try:
            (v / nome).unlink()
        except OSError:
            pass
    if scarica or togli:
        log.info("video della guida: %d scaricati, %d tolti", fatti, len(togli))
    return fatti


def video_sottofondo():
    """All'apertura, se il programma e' gia' aggiornato: rimette in pari i video della guida con quelli pubblicati
    (serve anche la prima volta, dopo un aggiornamento fatto dalla versione di prima)."""
    voluti = _REMOTA.get("video_file")
    if not isinstance(voluti, dict) or not voluti:
        return 0
    try:
        return sincronizza_video(voluti, CARTELLA_VIDEO(), _REMOTA.get("video_url") or VIDEO_URL, rigido=False)
    except Exception:
        log.exception("video della guida in sottofondo")
        return 0


class NonTrovato(Exception):
    """GitHub risponde 404: repository privato o senza versioni pubblicate."""


def _num(v):
    try:
        return tuple(int(x) for x in str(v).lstrip("v").split("."))
    except ValueError:
        return (0,)


def _apri(url, timeout=30):
    req = urllib.request.Request(url, headers={"User-Agent": "RegistraLezione",
                                               "Accept": "application/vnd.github+json"})
    return urllib.request.urlopen(req, timeout=timeout, context=ssl.create_default_context())


def cerca():
    """Ritorna None se non ci sono novita', altrimenti un dizionario con:
    versione, novita, completo (True = servono le librerie nuove), url_zip, peso, pagina."""
    import urllib.error
    try:
        with _apri(f"https://api.github.com/repos/{REPO}/releases/latest") as r:
            rel = json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        if e.code == 404:
            raise NonTrovato() from e
        raise
    asset = {a["name"]: a for a in rel.get("assets", [])}
    if "versione.json" not in asset or "aggiornamento.zip" not in asset:
        return None
    with _apri(asset["versione.json"]["browser_download_url"]) as r:
        remota = json.loads(r.read().decode("utf-8"))
    _REMOTA.clear()
    _REMOTA.update(remota)
    # ogni edizione si aggiorna solo quando c'e' qualcosa per lei: «ultima_sm» / «ultima_vm» = l'ultima versione
    # che ha cambiato Scripta Manent / Verba Manent IA (se mancano, vale «versione»: si aggiornano tutte e due)
    import edizione
    meta = remota.get("ultima_sm" if edizione.SCRIPTA else "ultima_vm") or remota.get("versione")
    if _num(meta) <= _num(versione_locale().get("versione", "0")):
        return None
    d = {
        "versione": remota.get("versione"),
        "novita": remota.get("novita", ""),
        "novita_en": remota.get("novita_en", ""),
        "novita_sm": remota.get("novita_sm", ""),
        "novita_sm_en": remota.get("novita_sm_en", ""),
        "completo": int(remota.get("librerie", 1)) != librerie_installate(),
        "url_zip": asset["aggiornamento.zip"]["browser_download_url"],
        "peso": asset["aggiornamento.zip"].get("size", 0),
        # i video della guida a parte (video.zip): solo se sono cambiati
        "video": remota.get("video", ""),
        "url_video": (asset.get("video.zip") or {}).get("browser_download_url", ""),
        # dal 4.82: i video uno per uno, solo quelli cambiati
        "video_file": remota.get("video_file") or {},
        "video_url": remota.get("video_url") or VIDEO_URL,
        "pagina": rel.get("html_url", f"https://github.com/{REPO}/releases/latest"),
    }
    if d["video_file"]:
        try:
            d["peso"] += peso_video(d["video_file"], CARTELLA_VIDEO())
        except Exception:
            pass
    elif video_da_scaricare(d):
        d["peso"] += (asset.get("video.zip") or {}).get("size", 0)
    return d


def _scarica(url, zp, peso, progresso, da=0.0, a=0.9):
    with _apri(url, timeout=60) as r, open(zp, "wb") as f:
        tot = int(r.headers.get("Content-Length") or peso or 0)
        letti = 0
        while True:
            b = r.read(65536)
            if not b:
                break
            f.write(b)
            letti += len(b)
            if tot:
                progresso(da + (a - da) * min(1.0, letti / tot))


def _estrai(zp, dest):
    with zipfile.ZipFile(zp) as z:
        for n in z.namelist():
            d = (dest / n).resolve()
            if not str(d).startswith(str(dest.resolve())):
                raise RuntimeError("file non valido nell'aggiornamento")
        z.extractall(dest)


def video_da_scaricare(agg):
    """True se i video della guida pubblicati sono diversi da quelli che ci sono (e c'e' video.zip)."""
    return bool(agg.get("url_video") and agg.get("video") and agg["video"] != impronta_video())


def installa(agg, progresso=lambda f: None):
    """Scarica il codice nuovo e lo copia SUBITO sopra la cartella app (i file .py non sono bloccati
    da Windows mentre il programma gira). Prima fa una copia di sicurezza in app_vecchia: se la
    versione nuova non parte, il lanciatore rimette quella.
    (Prima si scaricava in app_nuova e la si scambiava al riavvio, ma se la cartella era ancora
    in uso lo scambio non riusciva e restava la versione vecchia.)"""
    uno = bool(agg.get("video_file"))         # dal 4.82: i video uno per uno
    video = uno or video_da_scaricare(agg)
    with tempfile.TemporaryDirectory() as tmp:
        zp = Path(tmp) / "agg.zip"
        _scarica(agg["url_zip"], zp, agg.get("peso"), progresso, 0.0, 0.4 if video else 0.9)
        nuovo = Path(tmp) / "nuovo"
        nuovo.mkdir()
        _estrai(zp, nuovo)
        if not (nuovo / "registra_lezione.py").exists():
            raise RuntimeError("l'aggiornamento scaricato e' incompleto")
        # i video della guida: dal 4.47 non sono piu' in aggiornamento.zip; si scaricano a parte solo se cambiano
        if uno:          # solo quelli nuovi o cambiati, direttamente al loro posto (prima di copiare il codice)
            sincronizza_video(agg["video_file"], CARTELLA_VIDEO(), agg.get("video_url") or VIDEO_URL,
                              lambda f: progresso(0.4 + 0.5 * f))
        elif video:
            zv = Path(tmp) / "video.zip"
            _scarica(agg["url_video"], zv, 0, progresso, 0.4, 0.9)
            dv = nuovo / "interfaccia" / "video"
            shutil.rmtree(dv, ignore_errors=True)
            dv.mkdir(parents=True)
            _estrai(zv, dv)
            if impronta_video(dv) != agg["video"]:
                raise RuntimeError("i video della guida scaricati sono incompleti")
        vecchia = RADICE / "app_vecchia"
        shutil.rmtree(vecchia, ignore_errors=True)
        try:   # la copia di sicurezza senza i video (sono 100 MB e restano dove sono)
            shutil.copytree(QUI, vecchia, ignore=shutil.ignore_patterns("__pycache__", "video"))
        except Exception:
            log.exception("copia di sicurezza della versione attuale")
        shutil.rmtree(NUOVA, ignore_errors=True)        # resti del vecchio sistema
        if video and not uno:      # i video vecchi via (anche quelli che non ci sono piu')
            shutil.rmtree(QUI / "interfaccia" / "video", ignore_errors=True)
        for f in nuovo.rglob("*"):
            dest = QUI / f.relative_to(nuovo)
            if f.is_dir():
                dest.mkdir(parents=True, exist_ok=True)
            else:
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(f, dest)
        shutil.rmtree(QUI / "__pycache__", ignore_errors=True)
    log.info("aggiornamento copiato nella cartella app: versione %s", agg.get("versione"))
    progresso(1.0)


def riavvia():
    """Riapre il programma (il lanciatore mette al suo posto la versione nuova)."""
    import subprocess
    if getattr(sys, "frozen", False):
        if sys.platform == "win32":
            # aspetto qualche secondo: la finestra (e i processi di Edge) devono chiudersi del tutto,
            # altrimenti la cartella "app" e' ancora in uso e la versione nuova non prende il suo posto
            exe = str(sys.executable).replace("'", "''")
            subprocess.Popen(["powershell", "-NoProfile", "-WindowStyle", "Hidden", "-Command",
                              f"Start-Sleep -Seconds 6; Start-Process -FilePath '{exe}' -WorkingDirectory '{str(RADICE).replace(chr(39), chr(39) * 2)}'"],
                             cwd=str(RADICE), creationflags=0x08000000)
        else:
            subprocess.Popen([sys.executable], cwd=str(RADICE))
    else:
        subprocess.Popen([sys.executable, str(RADICE / "avvio.py")], cwd=str(RADICE))
