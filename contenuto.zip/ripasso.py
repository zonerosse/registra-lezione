"""Ripasso con le flashcard: le domande sono quelle gia' scritte negli appunti (Cornell o Formato Esame),
quindi non si chiama Claude e non costa niente.

Per ogni lezione il file ripasso.json ricorda come e' andata ogni carta:
    {"<id>": {"ok": 2, "no": 1, "ultimo": 1, "quando": "2026-10-15T12:30:00"}}
"ultimo" = 1 se l'ultima volta la sapevi, 0 se era "da rivedere".
"""
import base64
import datetime
import hashlib
import io
import logging
import random
import threading
from pathlib import Path

import appunti as ap
import elaborazione as el

log = logging.getLogger("registra_lezione")


def _id(formato, k, domanda):
    return hashlib.md5(f"{formato}|{k}|{domanda}".encode("utf-8")).hexdigest()[:12]


def _lista(x):
    if isinstance(x, list):
        return [str(v) for v in x if v]
    return [str(x)] if x else []


def carte_lezione(cartella):
    """Le carte di una lezione, senza immagini: prima quelle del Formato Esame (stelle e schema della risposta), poi
    quelle del Cornell (03/11/2026, Paolo «1A»: anche le domande del Cornell contano nel Ripasso del giorno, cosi'
    «La sapevo / Da rivedere» del foglio Cornell vale anche li'). Dentro il Cornell la stessa domanda compare una volta sola."""
    cart = Path(cartella)
    info = el.leggi_json(cart / "info.json", {}) or {}
    nome = info.get("nome", cart.name)
    tutte, viste = [], set()
    for formato in ("esame", "cornell"):
        carte = []
        # Formato Esame con la classifica di tutta la lezione: quella (niente doppioni fra le parti)
        classifica = el.leggi_json(ap.file_classifica(cart)) if formato == "esame" else None
        if classifica and classifica.get("domande_probabili"):
            fonti = [(int(v.get("parte") or 1), {"domande_probabili": [v]}) for v in classifica["domande_probabili"] if isinstance(v, dict)]
        else:
            fonti = []
            for f in sorted(cart.glob("appunti_esame_*.json" if formato == "esame" else "appunti_[0-9]*.json")):
                try:
                    k = int(f.stem.rsplit("_", 1)[1])
                except ValueError:
                    continue
                d = el.leggi_json(f)
                if isinstance(d, dict) and d:
                    fonti.append((k, ap.normalizza(d)))
        for k, d in fonti:
            if (formato == "esame") != bool(ap.e_esame(d)):
                continue
            mappa = {m.get("n"): m for m in (el.leggi_json(cart / f"pacchetto_{k:03d}.json", []) or []) if isinstance(m, dict)}
            voci = d.get("domande_probabili") if formato == "esame" else d.get("blocchi")
            for v in voci if isinstance(voci, list) else []:
                if not isinstance(v, dict):       # appunti scritti male (una riga di testo al posto della domanda)
                    continue
                dom = str(v.get("domanda") or "").strip()
                if not dom or (formato == "cornell" and dom.lower() in viste):
                    continue
                if formato == "cornell":
                    viste.add(dom.lower())     # come il foglio Cornell: la stessa domanda in due parti, una volta
                try:
                    n = int(v.get("slide") or 0)
                except (TypeError, ValueError):
                    n = 0
                m = mappa.get(n) or {}
                try:
                    stelle = max(1, min(3, int(v.get("stelle") or 0))) if formato == "esame" else 0
                except (TypeError, ValueError):
                    stelle = 1
                carte.append({
                    "id": _id(formato, k, dom), "cartella": str(cart), "lezione": nome, "formato": formato,
                    "domanda": dom, "stelle": stelle, "idea": str(v.get("idea") or "").strip(),
                    "schema": _lista(v.get("schema") if formato == "esame" else v.get("appunti")),
                    "parole": _lista(v.get("parole_chiave")),
                    "errore": (v.get("errore") or "") if formato == "esame" else "",
                    "aggiunte": _lista(v.get("aggiunte")), "avvisi": _lista(v.get("avvisi")),
                    "dove": v.get("dove") or "",
                    "slide_n": n if m.get("file") else 0, "slide_file": m.get("file") or "",
                    "minuto": int((m.get("inizio") or 0) // 60) if m.get("file") else None,
                })
        tutte += carte       # (le domande del Cornell restano con il loro id anche se uguali a una del Formato Esame:
                             # lo stesso id del foglio Cornell)
    return tutte


def foglio_cornell(cartella):
    """«Ripasso Cornell» (anteprima 33, 01/11/2026: «il formato Cornell e' il vero ripasso»): il foglio degli appunti
    della lezione, domanda per domanda, con gli appunti da coprire e il riassunto in fondo.
    Le domande hanno lo stesso id delle carte (_id), cosi' «La sapevo / Da rivedere» vale anche per il Ripasso del giorno.
    Senza appunti Cornell uso il Formato Esame (domanda + schema della risposta)."""
    cart = Path(cartella)
    info = el.leggi_json(cart / "info.json", {}) or {}
    st = _stat(cart)
    for formato in ("cornell", "esame"):
        blocchi, riass = [], []
        for f in sorted(cart.glob("appunti_[0-9]*.json" if formato == "cornell" else "appunti_esame_*.json")):
            try:
                k = int(f.stem.rsplit("_", 1)[1])
            except ValueError:
                continue
            d = el.leggi_json(f)
            if not isinstance(d, dict) or not d:
                continue
            d = ap.normalizza(d)
            if (formato == "esame") != bool(ap.e_esame(d)):
                continue
            voci = d.get("blocchi") if formato == "cornell" else d.get("domande_probabili")
            for v in voci if isinstance(voci, list) else []:
                if not isinstance(v, dict):
                    continue
                dom = str(v.get("domanda") or "").strip()
                if not dom:
                    continue
                if dom.lower() in {b["domanda"].lower() for b in blocchi}:     # la stessa domanda in due parti: una volta sola
                    continue
                cid = _id(formato, k, dom)
                blocchi.append({"id": cid, "domanda": dom, "parole": _lista(v.get("parole_chiave")), "idea": str(v.get("idea") or "").strip(),
                                "appunti": _lista(v.get("appunti") if formato == "cornell" else v.get("schema")),
                                "ultimo": (st.get(cid) or {}).get("ultimo")})
            r = str(d.get("riassunto") or "").strip()
            if r:
                riass.append(r)
        if formato == "esame" and blocchi:
            # 03/11/2026: le stesse carte (e gli stessi id) del Ripasso del giorno, che con la classifica della lezione
            # usa quella: prima «La sapevo» qui segnava carte che il Ripasso del giorno non vedeva
            carte = [c for c in carte_lezione(cart) if c["formato"] == "esame"]
            if carte:
                blocchi = [{"id": c["id"], "domanda": c["domanda"], "parole": c["parole"], "appunti": c["schema"], "idea": c.get("idea") or "",
                            "ultimo": (st.get(c["id"]) or {}).get("ultimo")} for c in carte]
        if blocchi:
            return {"cartella": str(cart), "nome": info.get("nome", cart.name), "materia": info.get("materia") or "",
                    "inizio": info.get("inizio", ""), "formato": formato, "blocchi": blocchi, "riassunto": "\n\n".join(riass)}
    return None


def _stat(cartella):
    return el.leggi_json(Path(cartella) / "ripasso.json", {}) or {}


def conta(cartella):
    """{"n": domande, "no": da rivedere, "tre": quante ★★★} di una lezione."""
    carte = carte_lezione(cartella)
    st = _stat(cartella)
    return {"n": len(carte), "no": sum(1 for c in carte if (st.get(c["id"]) or {}).get("ultimo") == 0),
            "tre": sum(1 for c in carte if c["stelle"] >= 3)}


def _miniatura(cartella, file):
    if not file:
        return ""
    try:
        from PIL import Image
        p = el.immagine_slide(cartella, file)
        with Image.open(p) as im:
            im.thumbnail((360, 220))
            b = io.BytesIO()
            im.convert("RGB").save(b, "JPEG", quality=72)
        return "data:image/jpeg;base64," + base64.b64encode(b.getvalue()).decode()
    except Exception:
        log.exception("miniatura ripasso %s", file)
        return ""


def prepara(cartelle, modo="prima"):
    """Le carte da ripassare, in ordine.
    modo: "prima"  = prima quelle da rivedere (e quelle mai viste), poi le altre
          "tutte"  = tutte in ordine sparso
          "stelle" = solo le ★★★ (Formato Esame)
          "no"     = solo quelle da rivedere"""
    carte = []
    for c in cartelle:
        st = _stat(c)
        for x in carte_lezione(c):
            s = st.get(x["id"]) or {}
            x["ultimo"] = s.get("ultimo")
            carte.append(x)
    random.shuffle(carte)
    if modo == "stelle":
        carte = [c for c in carte if c["stelle"] >= 3]
    elif modo == "no":
        carte = [c for c in carte if c["ultimo"] == 0]
    elif modo == "prima":
        # da rivedere -> mai viste -> sapute
        carte.sort(key=lambda c: {0: 0, None: 1, 1: 2}.get(c["ultimo"], 1))
    for c in carte:
        c["img"] = _miniatura(c["cartella"], c.pop("slide_file"))
    return carte


INTERVALLI = [1, 2, 4, 8, 16, 30]       # «Ripasso del giorno»: dopo quanti giorni torna una carta, per scatola


def stato_carta(s):
    """(scatola, scadenza) di una carta; anche per quelle votate prima che ci fosse il ripasso del giorno."""
    if not s:
        return None, None
    oggi = datetime.date.today()
    try:
        scad = datetime.date.fromisoformat(str(s.get("scad"))[:10]) if s.get("scad") else None
    except ValueError:
        scad = None
    box = s.get("box")
    if box is None:
        try:
            quando = datetime.date.fromisoformat(str(s.get("quando"))[:10])
        except ValueError:
            quando = oggi
        box = 0 if s.get("ultimo") == 0 else 1
        scad = quando + datetime.timedelta(days=INTERVALLI[box])
    return int(box), scad or oggi


def giorni_dopo(box, sapevo=True, esame=None, oggi=None):
    """Fra quanti giorni torna la carta dopo il voto (la stessa regola per il voto e per «torna tra N giorni»)."""
    box = min(len(INTERVALLI) - 1, (box or 0) + 1) if sapevo else 0
    oggi = oggi or datetime.date.today()
    giorni = INTERVALLI[box]
    if esame and esame > oggi:
        mancano = (esame - oggi).days
        giorni = max(1, min(giorni, max(1, mancano // 3), max(1, mancano - 1)))
    return box, giorni


_BLOCCO = threading.Lock()      # due voti insieme (tocchi veloci, test corretto) non si cancellano a vicenda (03/11/2026)


def voto(cartella, cid, sapevo, esame=None):
    """esame: la data dell'esame della materia (le carte tornano piu' spesso quando si avvicina)."""
    with _BLOCCO:
        return _voto(cartella, cid, sapevo, esame)


def _voto(cartella, cid, sapevo, esame=None):
    p = Path(cartella) / "ripasso.json"
    st = _stat(cartella)
    s = st.get(cid) or {"ok": 0, "no": 0}
    box, _ = stato_carta(s if s.get("quando") else None)
    oggi = datetime.date.today()
    box, giorni = giorni_dopo(box, sapevo, esame, oggi)
    s["box"] = box
    s["scad"] = (oggi + datetime.timedelta(days=giorni)).isoformat()
    s["ok" if sapevo else "no"] = s.get("ok" if sapevo else "no", 0) + 1
    s["ultimo"] = 1 if sapevo else 0
    s["quando"] = datetime.datetime.now().isoformat(timespec="seconds")
    st[cid] = s
    el.scrivi_json(p, st)
    return True
