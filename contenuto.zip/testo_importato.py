# -*- coding: utf-8 -*-
"""«Importa una trascrizione»: il testo di una lezione (PDF, Word, .txt) diventa una registrazione senza audio,
con la sua trascrizione e il suo pacchetto, cosi' gli appunti si fanno come per le altre."""
import re
import zipfile
from pathlib import Path

PAROLE_MINUTO = 140        # per dare un orario finto alle frasi (serve ai capitoli e ai rimandi «al minuto»)
TIPI = (".pdf", ".docx", ".txt", ".md")


class ErroreTesto(Exception):
    pass


def leggi(percorso):
    """Il testo del file. ErroreTesto se il tipo non va o se dentro non c'e' testo (es. PDF fatto di foto)."""
    p = Path(percorso)
    est = p.suffix.lower()
    if est == ".pdf":
        import docente
        lettore = docente._pypdf().PdfReader(str(p))
        testo = sistema_pdf([(pg.extract_text() or "") for pg in lettore.pages])
    elif est == ".docx":
        with zipfile.ZipFile(p) as z:
            xml = z.read("word/document.xml").decode("utf-8", "replace")
        paragrafi = re.findall(r"<w:p[ >].*?</w:p>", xml, flags=re.S)
        testo = "\n".join("".join(re.findall(r"<w:t[^>]*>(.*?)</w:t>", x, flags=re.S)) for x in paragrafi)
        import html
        testo = html.unescape(testo)
    elif est in (".txt", ".md"):
        b = p.read_bytes()
        for cod in ("utf-8-sig", "cp1252", "latin-1"):
            try:
                testo = b.decode(cod)
                break
            except UnicodeDecodeError:
                continue
    else:
        raise ErroreTesto("tipo")
    testo = testo.replace("\r", "")
    if len(testo.split()) < 30:
        raise ErroreTesto("vuoto")
    return testo


_FINE = re.compile(r"[.!?…:;»\"”)]$")
_PAROLA = re.compile(r"[A-Za-zÀ-ÖØ-öø-ÿ]+")


def _righe_in_paragrafi(pagine):
    """Il PDF da' il testo riga per riga, come e' stampato: le righe si riuniscono in paragrafi veri.
    Si va a capo dopo una riga che chiude la frase, o dopo una riga corta (titolo, ultima riga del paragrafo),
    se la riga dopo comincia in grande; «paro-\nla» torna «parola»; i numeri di pagina da soli si tolgono;
    la frase continua anche alla pagina dopo."""
    righe = []
    for pg in pagine:
        for r in pg.replace("\r", "").split("\n"):
            r = r.strip()
            if not r or re.fullmatch(r"(pag\.?\s*)?\d{1,4}", r, flags=re.I):      # numero di pagina
                continue
            righe.append(r)
    lunghe = sorted(len(r) for r in righe)
    tipica = lunghe[int(len(lunghe) * 0.8)] if lunghe else 80          # lunghezza di una riga piena
    paragrafi, cur, ultima = [], "", ""
    for r in righe:
        if not cur:
            cur = ultima = r
            continue
        if cur.endswith("-") and r[:1].islower():                       # a capo col trattino
            cur, ultima = cur[:-1] + r, r
            continue
        inizia = r[:1].isupper() or r[:1].isdigit() or r[:1] in "•–«\"“"
        chiude = bool(_FINE.search(ultima))
        corta = len(ultima) < tipica * 0.6
        if inizia and (chiude or corta):
            paragrafi.append(cur)
            cur = r
        else:
            cur += " " + r
        ultima = r
    if cur:
        paragrafi.append(cur)
    return paragrafi


def _ripara_parole(testo, conta=None):
    """Parole spezzate da spazi finti («indivi duare», «pi ù», «affidab ile», «ta l»): due pezzi vicini si
    riuniscono quando la parola intera compare scritta per bene nel testo e almeno un pezzo, da solo, non e'
    una parola del testo."""
    from collections import Counter
    if conta is None:
        conta = Counter(w.lower() for w in _PAROLA.findall(testo))

    def parola(w):
        return conta.get(w.lower(), 0) >= 2

    prima_re = re.compile(r"^(\W*)([A-Za-zÀ-ÖØ-öø-ÿ]+)$")      # «(vaginos»
    dopo_re = re.compile(r"^([a-zà-öø-ÿ]+)(\W*)$")               # «copia:»
    out = []
    for p in testo.split(" "):
        ma = prima_re.match(out[-1]) if out else None
        mb = dopo_re.match(p)
        if ma and mb:
            a, b = ma.group(2), mb.group(1)
            if conta.get((a + b).lower(), 0) >= 1 and (not parola(a) or not parola(b)):
                out[-1] = ma.group(1) + a + b + mb.group(2)
                continue
        out.append(p)
    return " ".join(out)


def sistema_pdf(pagine):
    """Testo di un PDF pronto come una trascrizione: paragrafi interi e parole senza spazi finti (06/11/2026,
    tesi di Paolo: frasi interrotte a meta' e «pi ù», «indivi duare»)."""
    from collections import Counter
    paragrafi = _righe_in_paragrafi(pagine)
    conta = Counter(w.lower() for w in _PAROLA.findall(" ".join(paragrafi)))     # dizionario: il testo intero
    return "\n\n".join(_ripara_parole(p, conta) for p in paragrafi)


def segmenti(testo):
    """Frasi di circa 40 parole con orari finti (PAROLE_MINUTO), come quelle di una trascrizione vera."""
    righe = [r.strip() for r in re.split(r"\n\s*\n|\n", testo) if r.strip()]
    out, t, pezzo = [], 0.0, []

    def chiudi():
        nonlocal t, pezzo
        if pezzo:
            s = " ".join(pezzo)
            d = max(2.0, len(s.split()) * 60 / PAROLE_MINUTO)
            out.append({"inizio": round(t, 2), "fine": round(t + d, 2), "testo": s})
            t += d
            pezzo = []

    for r in righe:
        for frase in re.split(r"(?<=[.!?…])\s+", r):
            pezzo.append(frase)
            if len(" ".join(pezzo).split()) >= 40:
                chiudi()
        chiudi()            # un paragrafo non si mescola col successivo
    return out


PARTE_TESTO = 1800      # 06/11/2026 (tesi di 76 pagine, appunti tagliati): un testo lungo si divide in parti di
                        # circa 4200 parole (~10 pagine), come le registrazioni; gli appunti si fanno parte per parte


def dividi(cartella, parte=PARTE_TESTO):
    """Le frasi del testo (trascrizione_001.json, …) divise in parti da `parte` secondi finti: trascrizione_00k.json.
    Torna il numero di parti. Scrive anche parte_secondi in info.json."""
    import elaborazione as el
    cart = Path(cartella)
    vecchi = sorted(cart.glob("trascrizione_[0-9][0-9][0-9].json"))
    segs = []
    for f in vecchi:
        segs += el.leggi_json(f, []) or []
    segs.sort(key=lambda s: float(s.get("inizio") or 0))
    parti = {}
    for s in segs:
        parti.setdefault(int(float(s.get("inizio") or 0) // parte) + 1, []).append(s)
    n = max(parti) if parti else 1
    for k in range(1, n + 1):
        el.scrivi_json(cart / f"trascrizione_{k:03d}.json", parti.get(k, []))
    for f in vecchi:
        try:
            if int(f.stem.split("_")[1]) > n:
                f.unlink()
        except (ValueError, OSError):
            pass
    el.aggiorna_info(cart, parte_secondi=parte)
    return n


def da_dividere(info):
    """Un testo importato tutto in una parte sola, piu' lungo di una parte: va diviso."""
    return bool(info.get("da_testo")) and float(info.get("durata") or 0) > PARTE_TESTO + 60 \
        and int(info.get("parte_secondi") or 0) > PARTE_TESTO
