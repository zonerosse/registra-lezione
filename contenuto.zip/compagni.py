"""«Manda a un compagno» (anteprima 66, 08/11/2026): una lezione (o una cartella intera) in un file solo,
«.vmlezione» (uno zip), che il compagno apre nel suo Verba Manent.

Dentro: appunti e flashcard sempre; trascrizione e slide se scelte; la registrazione (audio/video) se scelta.
Mai le cose personali: domande fatte a «Chiedi» (chiedi.json), ripassi (ripasso.json), note durante la
registrazione (note.json), righe evidenziate e note di «Correggi e sottolinea», traduzioni, pacchetti per Claude,
nome dello studente, percorsi del suo computer. Chi riceve: la lezione arriva con «da <nome>» e i PDF si rifanno
da soli nella sua cartella (gratis, senza Claude)."""
import json
import re
import shutil
import zipfile
from pathlib import Path

import appunti as ap
import elaborazione as el

ESTENSIONE = ".vmlezione"
_PERSONALI = {"chiedi.json", "ripasso.json", "note.json", "coperte.json", "mano.json", "Lezione.html", "trascrizione.txt"}
_CARTELLE_NO = {"pacchetti", "traduzioni", "ritagli_tmp", "mano"}
_INFO_NO = ("file_originale", "studente", "spesa_appunti", "spesa_server", "server", "corretta", "da_compagno", "sync")


def _media(p):
    n = p.name.lower()
    return (n.startswith(("video.", "audio.", "audio_originale.")) or n.endswith(".wav")) and p.suffix.lower() not in (".json", ".txt")


def _trascr(rel):
    return rel.parts[0] == "slide" or rel.name.startswith("trascrizione_") or rel.name in ("meta.json", "docente.json", "capitoli.json")


def _file_della_lezione(cart, trascr, media):
    """[(percorso, nome nello zip)] di una lezione, senza le cose personali."""
    out = []
    for p in sorted(cart.rglob("*")):
        if not p.is_file():
            continue
        rel = p.relative_to(cart)
        if rel.parts[0] in _CARTELLE_NO or rel.name in _PERSONALI or rel.name.startswith(("Per Claude", "~", ".")):
            continue
        if _media(p) and not media:
            continue
        if _trascr(rel) and not trascr:
            continue
        out.append((p, rel))
    return out


def stima(cartelle):
    """MB di ogni parte: {"base", "trascr", "media"}."""
    mb = {"base": 0, "trascr": 0, "media": 0}
    for c in cartelle:
        c = Path(c)
        for p in c.rglob("*"):
            if not p.is_file():
                continue
            rel = p.relative_to(c)
            if rel.parts[0] in _CARTELLE_NO or rel.name in _PERSONALI:
                continue
            k = "media" if _media(p) else "trascr" if _trascr(rel) else "base"
            mb[k] += p.stat().st_size
    return {k: round(v / 1_048_576, 1) for k, v in mb.items()}


def _pulisci_info(info):
    info = {k: v for k, v in info.items() if k not in _INFO_NO}
    for f in ap.FORMATI:
        if isinstance(info.get(ap.chiave_info(f)), dict):
            info[ap.chiave_info(f)] = {k: Path(str(v)).name for k, v in info[ap.chiave_info(f)].items() if v}
        if isinstance(info.get(ap.chiave_completi(f)), str):
            info[ap.chiave_completi(f)] = Path(info[ap.chiave_completi(f)]).name
    info["pacchetti"] = {}
    return info


def prepara(cartelle, dest, nome, trascr=True, media=False):
    """Scrive il file .vmlezione. Torna (file, quante lezioni)."""
    cartelle = [Path(c) for c in cartelle if (Path(c) / "info.json").exists()]
    if not cartelle:
        raise ValueError("nessuna lezione")
    dest = Path(dest)
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_name(dest.name + ".tmp")
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("vmlezione.json", json.dumps({"v": 1, "da": str(nome or "")[:40], "lezioni": [c.name for c in cartelle],
                                                 "trascrizione": bool(trascr), "registrazione": bool(media)}, ensure_ascii=False))
        for c in cartelle:
            for p, rel in _file_della_lezione(c, trascr, media):
                arc = f"{c.name}/{rel.as_posix()}"
                if rel.as_posix() == "info.json":
                    z.writestr(arc, json.dumps(_pulisci_info(el.leggi_json(p, {}) or {}), ensure_ascii=False, indent=1))
                elif re.fullmatch(r"appunti_.*\.json", rel.name):
                    d = el.leggi_json(p)
                    if isinstance(d, dict):
                        d.pop("_evid", None)
                        d.pop("_mie", None)
                    z.writestr(arc, json.dumps(d, ensure_ascii=False))
                elif _media(p):
                    z.write(p, arc, compress_type=zipfile.ZIP_STORED)        # gia' compressi: non serve rifarlo
                else:
                    z.write(p, arc)
    tmp.replace(dest)
    return dest, len(cartelle)


def _sicuro(nome):
    return nome and ".." not in Path(nome).parts and not Path(nome).is_absolute() and "\\" not in nome and ":" not in nome


def _nome_pdf(v, da):
    """Il PDF del compagno con «da Marco» nel nome: non va sopra un PDF che c'e' gia'."""
    n = Path(str(v)).name
    return n if n.startswith("da ") else f"da {el.nome_sicuro(da or '?')} – {n}"


def importa(file, base, cartella_pacchetti):
    """Apre il file di un compagno: le lezioni vanno in base con un nome nuovo. Torna (cartelle, nome)."""
    base, pac = Path(base), Path(cartella_pacchetti)
    with zipfile.ZipFile(file) as z:
        try:
            man = json.loads(z.read("vmlezione.json").decode("utf-8"))
        except (KeyError, ValueError):
            raise ValueError("non e' una lezione di Verba Manent")
        da = str(man.get("da") or "").strip()[:40]
        fatte = []
        for nome in man.get("lezioni") or []:
            if not _sicuro(nome) or "/" in nome:
                continue
            dest = base / nome
            i = 2
            while dest.exists():
                dest = base / f"{nome} ({i})"
                i += 1
            pre = nome + "/"
            voci = [n for n in z.namelist() if n.startswith(pre) and not n.endswith("/")]
            if f"{pre}info.json" not in voci:
                continue
            for n in voci:
                rel = n[len(pre):]
                if not _sicuro(rel):
                    continue
                out = dest / rel
                out.parent.mkdir(parents=True, exist_ok=True)
                with z.open(n) as src, open(out, "wb") as f:
                    shutil.copyfileobj(src, f)
            info = el.leggi_json(dest / "info.json", {}) or {}
            for f in ap.FORMATI:
                if isinstance(info.get(ap.chiave_info(f)), dict):
                    info[ap.chiave_info(f)] = {k: str(pac / _nome_pdf(v, da)) for k, v in info[ap.chiave_info(f)].items()}
                if isinstance(info.get(ap.chiave_completi(f)), str):
                    info[ap.chiave_completi(f)] = str(pac / _nome_pdf(info[ap.chiave_completi(f)], da))
            info["da_compagno"] = da or "?"
            info["pdf_v"] = 0
            el.scrivi_json(dest / "info.json", info)
            try:
                ap.rifai_pdf(dest, pac)
            except Exception:
                pass
            fatte.append(dest)
    return fatte, da
