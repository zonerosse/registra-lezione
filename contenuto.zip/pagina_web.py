"""«Aggiungi una pagina web» (anteprima 68, 08/11/2026): il testo di un articolo, di Wikipedia o del sito del prof
diventa un documento del «Libro di testo» della materia, cosi' «Chiedi alla materia» e il tutor lo usano.
Si legge sul dispositivo, senza Claude: si tiene l'articolo (<article>, <main>) e si tolgono menu, pubblicita',
script e piedi di pagina."""
import html
import re
import urllib.request
from html.parser import HTMLParser

_SALTA = {"script", "style", "noscript", "nav", "header", "footer", "aside", "form", "svg", "button", "select", "iframe",
          "figure", "template"}
_BLOCCO = {"p", "div", "br", "li", "h1", "h2", "h3", "h4", "h5", "h6", "tr", "section", "article", "main", "blockquote",
           "pre", "dd", "dt", "table", "ul", "ol"}
_VUOTI = {"br", "img", "hr", "meta", "link", "input", "source", "wbr", "col", "area", "base", "embed", "param", "track"}


class _Lettore(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.salta, self.salta_tag = 0, ""
        self.dentro = {"article": 0, "main": 0}
        self.parti = {"article": [], "main": [], "body": []}
        self.titolo, self.h1, self._t, self._h1 = "", "", False, False

    def handle_starttag(self, tag, attrs):
        if self.salta:                          # dentro un pezzo da saltare: conto solo lo stesso tag (i <li> non chiusi non contano)
            if tag == self.salta_tag:
                self.salta += 1
            return
        a = dict(attrs)
        classi = (a.get("class") or "") + " " + (a.get("id") or "")
        if tag not in _VUOTI and (tag in _SALTA or re.search(r"\b(cookie|banner|menu|navbox|sidebar|footer|advert|pubblicit|share|social|noprint)\b", classi, re.I)):
            self.salta, self.salta_tag = 1, tag
            return
        if tag in self.dentro:
            self.dentro[tag] += 1
        if tag == "title":
            self._t = True
        if tag == "h1":
            self._h1 = True
        if tag in _BLOCCO:
            self._scrivi("\n")

    def handle_endtag(self, tag):
        if self.salta:
            if tag == self.salta_tag:
                self.salta -= 1
            return
        if tag in self.dentro and self.dentro[tag]:
            self.dentro[tag] -= 1
        if tag == "title":
            self._t = False
        if tag == "h1":
            self._h1 = False
        if tag in _BLOCCO:
            self._scrivi("\n")

    def _scrivi(self, x):
        for k in ("article", "main"):
            if self.dentro[k]:
                self.parti[k].append(x)
        self.parti["body"].append(x)

    def handle_data(self, data):
        if self._t:
            self.titolo += data
        if self.salta:
            return
        if self._h1:
            self.h1 += data
        self._scrivi(data)


def testo_html(sorgente):
    """(titolo, testo) di una pagina HTML."""
    p = _Lettore()
    p.feed(sorgente)
    p.close()
    def pulito(pezzi):
        t = html.unescape("".join(pezzi))
        t = re.sub(r"[ \t ]+", " ", t)
        t = re.sub(r"\[\s*(modifica|edit|\d+)\s*\]", "", t)          # Wikipedia: [modifica], note [1]
        righe = [r.strip() for r in t.split("\n")]
        return "\n".join(r for r in righe if len(r) > 1)
    testo = ""
    for k in ("article", "main", "body"):
        t = pulito(p.parti[k])
        if len(t) > 400:
            testo = t
            break
    testo = testo or pulito(p.parti["body"])
    titolo = re.sub(r"\s+", " ", (p.h1 or p.titolo)).strip()
    return titolo[:120], testo


def leggi(url, timeout=25):
    """Scarica la pagina e torna (titolo, testo). ValueError se non si legge o se non c'e' testo (pagina riservata)."""
    url = str(url or "").strip()
    if not re.match(r"^https?://", url, re.I):
        url = "https://" + url
    rq = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (VerbaManentIA) AppleWebKit/537.36 Chrome/124 Safari/537.36",
                                              "Accept-Language": "it,en;q=0.8"})
    with urllib.request.urlopen(rq, timeout=timeout) as r:
        tipo = r.headers.get("Content-Type") or ""
        if "html" not in tipo and "text" not in tipo:
            raise ValueError("tipo")
        dati = r.read(4_000_000)
        cs = r.headers.get_content_charset() or (re.search(rb'charset=["\']?([\w-]+)', dati[:3000]) or [None, b"utf-8"])[1].decode()
    try:
        sorgente = dati.decode(cs, "replace")
    except LookupError:
        sorgente = dati.decode("utf-8", "replace")
    titolo, testo = testo_html(sorgente)
    if len(testo) < 300:
        raise ValueError("vuota")
    return titolo or url, testo


def pagine(testo, n=3000):
    """Il testo diviso in «pagine» di circa n caratteri, a fine frase (i paragrafi lunghi si spezzano)."""
    pezzi = []
    for par in testo.split("\n"):
        pezzi += [x + " " for x in re.split(r"(?<=[.!?])\s+", par) if x] if len(par) > n else [par]
        pezzi[-1:] = [pezzi[-1].rstrip() + "\n"] if pezzi else []
    out, pezzo = [], ""
    for x in pezzi:
        if len(pezzo) > n * 0.4 and len(pezzo) + len(x) > n:
            out.append(pezzo.strip())
            pezzo = ""
        pezzo += x
    if pezzo.strip():
        out.append(pezzo.strip())
    return [{"n": i, "et": str(i), "t": t[:12000], "cap": ""} for i, t in enumerate(out, 1)]
