# -*- coding: utf-8 -*-
"""
«Trascrivi sul server»: la trascrizione la fa un server con scheda grafica (RunPod, a consumo) invece del PC
o del telefono. Il server e' quello dell'utente (il suo conto RunPod, il suo «endpoint» con l'immagine
runpod/ai-api-faster-whisper): si paga solo il tempo in cui lavora.

L'audio va al server compresso (Opus o AAC), a pezzi di massimo 10 minuti tagliati in un silenzio, e il server
lo cancella finito il lavoro. Se qualcosa non va (niente internet, chiave sbagliata, server spento) chi chiama
trascrive sul dispositivo: la registrazione non si perde mai.
"""
import base64
import json
import logging
import os
import ssl
import subprocess
import time
import urllib.error
import urllib.request

log = logging.getLogger("registra_lezione")

API = os.environ.get("RL_RUNPOD_API") or "https://api.runpod.ai/v2/"     # (le prove usano un server finto)
REST = os.environ.get("RL_RUNPOD_REST") or "https://rest.runpod.io/v1/"    # impostazioni e spesa del conto (10/11/2026)
MODELLI = ["large-v3", "turbo", "large-v2"]    # il primo che il server conosce (l'immagine 0.4.1 non ha «turbo»)
_MODELLO = {"i": 0}
PEZZO_MAX = 600                 # secondi per richiesta (il server accetta al massimo circa 10 MB)
PREZZO_SECONDO = 0.69 / 3600    # scheda da 24 GB: 0,69 $ l'ora, si paga a millisecondi
ATTESA_MAX = 900                # un pezzo non puo' metterci piu' di 15 minuti (con l'accensione del server)


class ErroreServer(Exception):
    pass


def _chiama(url, chiave, corpo=None, timeout=60):
    dati = json.dumps(corpo).encode("utf-8") if corpo is not None else None
    req = urllib.request.Request(url, data=dati, method="POST" if dati else "GET",
                                 headers={"Authorization": "Bearer " + chiave, "Content-Type": "application/json",
                                          "User-Agent": "VerbaManentIA"})
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=ssl.create_default_context()) as r:
            return json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        from testi import tr
        if e.code in (401, 403):
            raise ErroreServer(tr("srv_chiave"))
        if e.code == 404:
            raise ErroreServer(tr("srv_codice"))
        if e.code == 402:
            raise ErroreServer(tr("srv_credito"))
        raise ErroreServer(tr("srv_err", e=f"HTTP {e.code}"))
    except (urllib.error.URLError, TimeoutError, OSError):
        from testi import tr
        raise ErroreServer(tr("srv_rete"))


def comprimi(audio):
    """Campioni 16 kHz -> Opus in un contenitore Ogg (circa 3 MB l'ora). Sul telefono si cambia (AAC)."""
    import numpy as np
    import elaborazione as el
    r = subprocess.run([el.ffmpeg_exe(), "-nostdin", "-loglevel", "error", "-f", "f32le", "-ar", "16000", "-ac", "1",
                        "-i", "-", "-c:a", "libopus", "-b:a", "32k", "-application", "voip", "-f", "ogg", "-"],
                       input=np.asarray(audio, dtype=np.float32).tobytes(), stdout=subprocess.PIPE,
                       stderr=subprocess.PIPE, creationflags=el.NO_WINDOW)
    if r.returncode != 0 or not r.stdout:
        raise ErroreServer("audio: " + r.stderr.decode("utf-8", "replace")[-300:])
    return r.stdout


def _pezzo(audio, endpoint, chiave, lingua, parole, progresso, precisa=True):
    """Un pezzo (<= 10 minuti): lo manda, aspetta il risultato. Ritorna (segmenti, secondi pagati, lingua)."""
    dati = base64.b64encode(comprimi(audio)).decode("ascii")
    while True:
        try:
            return _lavoro(dati, len(audio), endpoint, chiave, lingua, parole, progresso, precisa, MODELLI[_MODELLO["i"]])
        except ErroreModello:
            if _MODELLO["i"] + 1 >= len(MODELLI):
                raise ErroreServer("modello")
            _MODELLO["i"] += 1
            log.info("il server non ha questo modello: provo %s", MODELLI[_MODELLO["i"]])


class ErroreModello(Exception):
    pass


def _lavoro(dati, n_campioni, endpoint, chiave, lingua, parole, progresso, precisa, modello):
    corpo = {"input": {"audio_base64": dati, "model": modello,
                       "language": None if lingua in (None, "", "auto") else lingua,
                       "initial_prompt": ", ".join(parole) if parole else None,
                       "beam_size": 5 if precisa else 1, "best_of": 5 if precisa else 1,
                       "condition_on_previous_text": False, "enable_vad": True, "transcription": "plain_text"}}
    base = API + endpoint.strip() + "/"
    lavoro = _chiama(base + "run", chiave, corpo)
    jid = lavoro.get("id")
    if not jid:
        raise ErroreServer(str(lavoro)[:200])
    t0 = time.monotonic()
    while True:
        st = _chiama(base + "status/" + jid, chiave)
        stato = st.get("status")
        if stato == "COMPLETED":
            break
        if stato in ("FAILED", "CANCELLED", "TIMED_OUT"):
            err = str(st.get("error") or st.get("output"))
            if "not found" in err.lower() and "model" in err.lower() or "Invalid model" in err:
                raise ErroreModello(err)
            log.warning("server: %s %s", stato, err[:2000])
            from testi import tr
            raise ErroreServer(tr("srv_err", e=stato))
        if time.monotonic() - t0 > ATTESA_MAX:
            try:
                _chiama(base + "cancel/" + jid, chiave, {})
            except ErroreServer:
                pass
            raise ErroreServer("timeout")
        # il server non dice a che punto e' arrivato: avanzo piano verso il 90%
        progresso(min(0.9, (time.monotonic() - t0) / max(20.0, n_campioni / 16000 / 30)))
        time.sleep(1.5)
    out = st.get("output") or {}
    if isinstance(out, dict) and out.get("error"):
        if "Invalid model" in str(out["error"]) or "not found" in str(out["error"]).lower():
            raise ErroreModello(str(out["error"]))
        raise ErroreServer(str(out["error"])[:300])
    segs = [{"inizio": float(s["start"]), "fine": float(s["end"]), "testo": (s.get("text") or "").strip()}
            for s in (out.get("segments") or [])]
    pagati = (float(st.get("delayTime") or 0) + float(st.get("executionTime") or 0)) / 1000
    pagati += _attesa_pagata(endpoint, chiave)
    return segs, pagati, out.get("detected_language")


# --------------------------------------------------------------------------- attesa, spesa e server per chi ha un invito
# (10/11/2026, Paolo: su RunPod la spesa era 10 volte quella mostrata). Dopo ogni pezzo il server resta acceso
# «Idle timeout» secondi e anche quelli si pagano: si contano qui, e chi ha messo il server vede la spesa vera,
# presa dal conto RunPod, divisa per server (ogni invito ha un server suo, uguale a quello di chi invita).

_ATTESA = {}          # endpoint -> secondi di «Idle timeout» (letti una volta)
_ULTIMO = {}          # endpoint -> quando e' finito l'ultimo pezzo (time.monotonic)


def _rest(percorso, chiave, metodo="GET", corpo=None, timeout=30):
    dati = json.dumps(corpo).encode("utf-8") if corpo is not None else None
    req = urllib.request.Request(REST + percorso, data=dati, method=metodo,
                                 headers={"Authorization": "Bearer " + chiave, "Content-Type": "application/json",
                                          "User-Agent": "VerbaManentIA"})
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=ssl.create_default_context()) as r:
            return json.loads(r.read().decode("utf-8") or "null")
    except urllib.error.HTTPError as e:
        from testi import tr
        if e.code in (401, 403):
            raise ErroreServer(tr("srv_permesso"))
        if e.code == 404:
            raise ErroreServer(tr("srv_codice"))
        raise ErroreServer(tr("srv_err", e=f"HTTP {e.code}"))
    except (urllib.error.URLError, TimeoutError, OSError, ValueError):
        from testi import tr
        raise ErroreServer(tr("srv_rete"))


def impostazioni(endpoint, chiave):
    """Le impostazioni del server su RunPod (idleTimeout, name, templateId, gpuTypeIds, workersMax…)."""
    d = _rest("endpoints/" + endpoint.strip(), chiave) or {}
    if isinstance(d.get("idleTimeout"), (int, float)):
        _ATTESA[endpoint.strip()] = int(d["idleTimeout"])
    return d


def attesa(endpoint, chiave):
    """Secondi in cui il server resta acceso dopo un pezzo (None se non si riesce a leggerlo)."""
    e = endpoint.strip()
    if e not in _ATTESA:
        try:
            impostazioni(e, chiave)
        except ErroreServer:
            _ATTESA[e] = None
    return _ATTESA.get(e)


def _attesa_pagata(endpoint, chiave):
    """Secondi di attesa da aggiungere a questo pezzo: l'«Idle timeout», meno quello che il pezzo prima non ha
    usato perche' questo e' arrivato prima (il server era ancora acceso)."""
    e = endpoint.strip()
    sec = attesa(e, chiave) or 0
    ora = time.monotonic()
    prima = _ULTIMO.get(e)
    _ULTIMO[e] = ora
    if prima is not None and ora - prima < sec:
        return max(0.0, ora - prima)       # l'attesa del pezzo prima e' stata piu' corta: questa si conta alla fine
    return float(sec)


def abbassa_attesa(endpoint, chiave, secondi=10):
    """«Abbassa a 10 secondi»: cambia l'«Idle timeout» del server su RunPod."""
    d = _rest("endpoints/" + endpoint.strip(), chiave, "PATCH", {"idleTimeout": int(secondi)}) or {}
    _ATTESA[endpoint.strip()] = int(d.get("idleTimeout") or secondi)
    return _ATTESA[endpoint.strip()]


NOME_INVITO = "Verba Manent · "


def crea_server_per(endpoint, chiave, per):
    """Un server tutto suo per chi riceve un invito: uguale a quello di chi invita, con 10 secondi di attesa."""
    src = impostazioni(endpoint, chiave)
    if not src.get("templateId"):
        raise ErroreServer("template")
    try:
        import edizione
        pre = "Scripta Manent · " if edizione.SCRIPTA else NOME_INVITO
    except Exception:
        pre = NOME_INVITO
    corpo = {"name": (pre + (per or "invito"))[:191], "templateId": src["templateId"],
             "idleTimeout": 10, "flashboot": True, "workersMin": 0, "workersMax": int(src.get("workersMax") or 3)}
    for k in ("gpuTypeIds", "gpuCount", "executionTimeoutMs", "dataCenterIds", "allowedCudaVersions", "scalerType", "scalerValue"):
        if src.get(k):
            corpo[k] = src[k]
    nuovo = _rest("endpoints", chiave, "POST", corpo) or {}
    if not nuovo.get("id"):
        raise ErroreServer(str(nuovo)[:200])
    return nuovo["id"]


def spesa(chiave, anno, mese):
    """La spesa vera del mese, per server: [{"id", "nome", "dollari", "secondi"}] dal conto RunPod."""
    import datetime
    a = datetime.datetime(anno, mese, 1, tzinfo=datetime.timezone.utc)
    b = datetime.datetime(anno + (mese == 12), mese % 12 + 1, 1, tzinfo=datetime.timezone.utc)
    q = "billing/endpoints?bucketSize=month&grouping=endpointId&startTime=%s&endTime=%s" % (
        a.strftime("%Y-%m-%dT%H:%M:%SZ"), b.strftime("%Y-%m-%dT%H:%M:%SZ"))
    righe = _rest(q, chiave) or []
    nomi = {}
    try:
        for e in _rest("endpoints", chiave) or []:
            nomi[e.get("id")] = e.get("name") or ""
    except ErroreServer:
        pass
    tot = {}
    for r in righe if isinstance(righe, list) else []:
        i = r.get("endpointId") or "?"
        x = tot.setdefault(i, {"id": i, "nome": nomi.get(i, ""), "dollari": 0.0, "secondi": 0})
        x["dollari"] += float(r.get("amount") or 0)
        x["secondi"] += int((r.get("timeBilledMs") or 0) / 1000)
    return sorted(tot.values(), key=lambda x: -x["dollari"])


def trascrivi(audio, endpoint, chiave, lingua="it", parole=None, progresso=lambda f: None, precisa=True):
    """Trascrive dei campioni (16 kHz) sul server. Ritorna (segmenti con gli orari dall'inizio, dollari, lingua)."""
    import elaborazione as el
    tot = len(audio) / 16000
    tagli, da = [], 0.0
    while tot - da > PEZZO_MAX:
        a = el._taglio(audio, da + PEZZO_MAX - 30, da + PEZZO_MAX)
        tagli.append((da, a))
        da = a
    tagli.append((da, tot))
    out, pagati, rilevata = [], 0.0, None
    for i, (a, b) in enumerate(tagli):
        segs, sec, lg = _pezzo(audio[int(a * 16000):int(b * 16000)], endpoint, chiave, lingua, parole,
                               lambda f, i=i: progresso((i + f) / len(tagli)), precisa)
        out += [{"inizio": round(a + s["inizio"], 2), "fine": round(a + s["fine"], 2), "testo": s["testo"]} for s in segs]
        pagati += sec
        rilevata = rilevata or lg
    progresso(1.0)
    return out, round(pagati * PREZZO_SECONDO, 5), rilevata


def prova(endpoint, chiave):
    """«Collega e prova»: 20 secondi di audio di prova. Ritorna i secondi che ci ha messo e quanto e' costato."""
    import numpy as np
    t = np.arange(20 * 16000) / 16000
    audio = (0.05 * np.sin(2 * np.pi * 180 * t) * ((t % 3) < 2)).astype(np.float32)
    t0 = time.monotonic()
    _, dollari, _ = trascrivi(audio, endpoint, chiave, "it", None, precisa=False)
    return {"secondi": round(time.monotonic() - t0), "dollari": dollari}
