# -*- coding: utf-8 -*-
"""
Unire due (o piu') registrazioni della stessa lezione in una lezione sola (anteprima 80, 13/11/2026).

Esempio: la prima meta' registrata da te, la seconda da un compagno. Dopo l'unione c'e' UNA lezione:
  - la trascrizione delle due, una dopo l'altra (gli orari della seconda partono da dove finisce la prima);
  - le slide delle due, sulla stessa linea del tempo (le immagini come si vedevano negli appunti);
  - l'audio unito in audio.m4a (sul PC con ffmpeg, sul telefono con il ponte: vedi android_motore);
  - le parti per gli appunti rifatte sulla lezione intera.
Le registrazioni di prima non si cancellano: vanno nella cartella nascosta «.unite» accanto alle lezioni
(non compaiono nell'elenco e non vanno nel cloud).
"""
import datetime
import logging
import math
import shutil
import subprocess
from pathlib import Path

import elaborazione as el

log = logging.getLogger("registra_lezione")

CARTELLA_UNITE = ".unite"
CAMPI_DAL_PRIMO = ("studente", "lingua_appunti", "lingua_lezione", "tipo", "materia", "modo", "parole", "mio",
                   "modello", "modello_mio", "partecipanti", "precisa", "rumorosa", "da_compagno")


def _durata(cart, info):
    d = float(info.get("durata") or 0)
    if d > 0:
        return d
    fine = 0.0
    for p in Path(cart).glob("trascrizione_[0-9][0-9][0-9].json"):
        for s in el.leggi_json(p, []) or []:
            fine = max(fine, float(s.get("fine") or 0))
    return fine


def media_di(cart):
    """Il file con l'audio della lezione (o None)."""
    cart = Path(cart)
    for nome in ("audio.m4a", "video.mp4"):
        if (cart / nome).exists():
            return cart / nome
    for p in sorted(cart.glob("video.*")) + sorted(cart.glob("audio_originale.*")):
        if p.suffix.lower() not in (".txt", ".json"):
            return p
    parti = el.file_parti(cart)
    return None if not parti else list(parti.values())


def unisci_audio(medie, out, durate):
    """PC: le registrazioni una dopo l'altra in un solo audio AAC. Ogni pezzo e' tagliato o allungato con silenzio
    alla sua durata, cosi' la seconda parte comincia esattamente dove la trascrizione la mette."""
    ff = el.ffmpeg_exe()
    cmd, filtri = [ff, "-y"], []
    n = 0
    for m, d in zip(medie, durate):
        if isinstance(m, list):            # parti audio_00k.wav non ancora unite
            lista = Path(out).with_name(f"unisci_lista_{n}.txt")
            lista.write_text("".join(f"file '{p}'\n" for p in m), encoding="utf-8")
            cmd += ["-f", "concat", "-safe", "0", "-i", str(lista)]
        else:
            cmd += ["-i", str(m)]
        filtri.append(f"[{n}:a:0]aresample=44100,aformat=channel_layouts=mono,apad,atrim=0:{d:.3f}[a{n}]")
        n += 1
    filtri.append("".join(f"[a{i}]" for i in range(n)) + f"concat=n={n}:v=0:a=1[out]")
    cmd += ["-filter_complex", ";".join(filtri), "-map", "[out]", "-c:a", "aac", "-b:a", "96k", str(out)]
    r = subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, creationflags=el.NO_WINDOW)
    for p in Path(out).parent.glob("unisci_lista_*.txt"):
        try:
            p.unlink()
        except OSError:
            pass
    if r.returncode != 0 or not Path(out).exists():
        log.error("unisci audio: %s", r.stderr.decode("utf-8", "replace")[-1500:])
        return False
    return True


def _nuova_cartella(base, quando, nome):
    c = Path(base) / f"{quando:%Y-%m-%d %H%M} - {el.nome_sicuro(nome)}"
    n = 2
    while c.exists():
        c = Path(base) / f"{quando:%Y-%m-%d %H%M} - {el.nome_sicuro(nome)} ({n})"
        n += 1
    return c


def unisci(base, cartelle, nome, cartella_pacchetti, avanzamento=lambda f: None):
    """Unisce le lezioni (in quest'ordine) in una nuova. Torna la cartella nuova."""
    cartelle = [Path(c) for c in cartelle]
    infos = [el.leggi_json(c / "info.json", {}) or {} for c in cartelle]
    durate = [_durata(c, i) for c, i in zip(cartelle, infos)]
    i0 = infos[0]
    try:
        quando = datetime.datetime.fromisoformat(i0.get("inizio", ""))
    except Exception:
        quando = datetime.datetime.now()
    P = el.parte_secondi(cartelle[0])
    totale = sum(durate)
    nuova = _nuova_cartella(base, quando, nome)
    nuova.mkdir(parents=True)
    try:
        # 1. trascrizione: una dopo l'altra, poi divisa nelle parti della lezione nuova
        segmenti, off = [], 0.0
        for c, d in zip(cartelle, durate):
            for p in sorted(c.glob("trascrizione_[0-9][0-9][0-9].json")):
                for s in el.leggi_json(p, []) or []:
                    s = dict(s)
                    s["inizio"] = round(float(s.get("inizio") or 0) + off, 3)
                    s["fine"] = round(float(s.get("fine") or 0) + off, 3)
                    for w in s.get("parole") or []:
                        if isinstance(w, dict):
                            for k in ("inizio", "fine", "start", "end"):
                                if isinstance(w.get(k), (int, float)):
                                    w[k] = round(w[k] + off, 3)
                    segmenti.append(s)
            off += d
        segmenti.sort(key=lambda s: s["inizio"])
        n_parti = max(1, math.ceil(totale / P)) if totale else 1
        parti = {k: [] for k in range(1, n_parti + 1)}
        for s in segmenti:
            parti[min(n_parti, int(s["inizio"] // P) + 1)].append(s)
        for k, segs in parti.items():
            el.scrivi_json(nuova / f"trascrizione_{k:03d}.json", segs)
        avanzamento(0.15)

        # 2. slide: le immagini come erano negli appunti, sulla linea del tempo nuova
        (nuova / "slide").mkdir()
        slides, off = [], 0.0
        for i, (c, d) in enumerate(zip(cartelle, durate), 1):
            meta = el.leggi_json(c / "meta.json", {}) or {}
            for n, sl in enumerate(el.slide_in_tempo_audio(meta, c), 1):
                try:
                    src = el.immagine_slide(c, sl["file"])
                    if not Path(src).exists():
                        continue
                    nome_f = f"foto_u{i}_{n:04d}{Path(src).suffix.lower() or '.jpg'}"
                    shutil.copy2(src, nuova / "slide" / nome_f)
                    slides.append({"file": nome_f, "t": round(float(sl["t"]) + off, 3)})
                except Exception:
                    log.exception("unisci: slide %s di %s", sl.get("file"), c.name)
            off += d
        el.scrivi_json(nuova / "meta.json", {"slides": slides, "audio_t0": 0, "video_t0": 0})
        avanzamento(0.3)

        # 3. audio unito
        medie = [media_di(c) for c in cartelle]
        if all(medie):
            try:
                if not unisci_audio(medie, nuova / "audio.m4a", durate):
                    log.warning("unisci: audio non unito (la lezione resta senza audio)")
            except Exception:
                log.exception("unisci: audio")
        avanzamento(0.6)

        # 4. info, pacchetti e lezione completa
        info = {k: i0.get(k) for k in CAMPI_DAL_PRIMO if i0.get(k) is not None}
        info.update({"nome": nome, "inizio": quando.isoformat(timespec="seconds"), "durata": round(totale),
                     "n_slide": len(slides), "stato": "pronta", "pacchetti": {}, "parte_secondi": P,
                     "formato_appunti": i0.get("formato_appunti") or "cornell", "chi_parla": False,
                     "unita_da": [{"nome": x.get("nome", c.name), "cartella": c.name, "durata": round(d)}
                                  for c, x, d in zip(cartelle, infos, durate)]})
        el.scrivi_json(nuova / "info.json", info)
        for k, segs in parti.items():
            if segs:
                el.crea_pacchetto(nuova, k, cartella_pacchetti)
            avanzamento(0.6 + 0.3 * k / n_parti)
        el.crea_completa(nuova, segmenti)
        avanzamento(0.97)
    except Exception:
        shutil.rmtree(nuova, ignore_errors=True)          # niente lezione a meta' in elenco
        raise

    # 5. le registrazioni di prima, messe da parte
    dove = Path(base) / CARTELLA_UNITE
    dove.mkdir(exist_ok=True)
    for c in cartelle:
        dest = dove / c.name
        n = 2
        while dest.exists():
            dest = dove / f"{c.name} ({n})"
            n += 1
        try:
            shutil.move(str(c), str(dest))
        except Exception:
            log.exception("unisci: sposto %s", c.name)
    avanzamento(1.0)
    return nuova
