"""«Correggi e sottolinea» (anteprima 62, 08/11/2026): lo studente corregge gli appunti e la trascrizione,
evidenzia le righe che contano e aggiunge le sue note. Niente Claude: si cambiano i .json gia' salvati e si
rifanno i PDF.

Appunti con i blocchi (Cornell, webinar, «a modo mio»): domanda, righe e riassunto si correggono; le righe si
evidenziano, si tolgono e possono avere una nota. Le righe evidenziate e le note si ricordano per TESTO
(dati["_evid"] = [testo], dati["_mie"] = [{"dopo": testo, "nota": ...}]): togliere una riga non sposta le altre.
Gli altri formati (esame, verbale) prendono solo «Sostituisci una parola ovunque».
Trascrizione: trascrizione_00k.json, si cambia solo il testo della frase (orari e voce restano)."""
import re
from pathlib import Path

import appunti as ap
import elaborazione as el


def _formati(cartella):
    """[(formato, k, file .json)] degli appunti di una lezione, in ordine di parte."""
    info = el.leggi_json(Path(cartella) / "info.json", {}) or {}
    out = []
    for f in ap.FORMATI:
        for k in sorted((info.get(ap.chiave_info(f)) or {}), key=lambda x: int(x) if str(x).isdigit() else 0):
            p = ap.file_json(cartella, k, f)
            if p.exists():
                out.append((f, str(k), p))
    return out


def _con_blocchi(dati):
    return isinstance(dati, dict) and isinstance(dati.get("blocchi"), list)


def leggi(cartella):
    """Quello che serve alla pagina: i blocchi degli appunti (con righe evidenziate e note) e le frasi."""
    blocchi, altri = [], []
    for f, k, p in _formati(cartella):
        dati = el.leggi_json(p)
        if not _con_blocchi(dati):
            if dati:
                altri.append(f)
            continue
        ev = set(dati.get("_evid") or [])
        mie = {m.get("dopo"): m.get("nota") for m in dati.get("_mie") or [] if isinstance(m, dict)}
        for b, bl in enumerate(dati["blocchi"]):
            if not isinstance(bl, dict):
                continue
            righe = [{"id": f"{f}|{k}|{b}|{i}", "testo": str(r), "ev": str(r) in ev, "nota": mie.get(str(r)) or ""}
                     for i, r in enumerate(bl.get("appunti") or []) if isinstance(r, str) and r.strip()]
            blocchi.append({"id": f"{f}|{k}|{b}|d", "dom": str(bl.get("domanda") or ""), "righe": righe, "f": f})
        if str(dati.get("riassunto") or "").strip():
            blocchi.append({"id": f"{f}|{k}|r", "riassunto": str(dati["riassunto"]), "righe": [], "f": f})
    frasi = []
    for p in sorted(Path(cartella).glob("trascrizione_[0-9][0-9][0-9].json")):
        k = p.stem.split("_")[1]
        for i, s in enumerate(el.leggi_json(p, []) or []):
            if isinstance(s, dict) and str(s.get("testo") or "").strip():
                frasi.append({"id": f"{k}|{i}", "t": float(s.get("inizio") or 0), "testo": str(s["testo"]).strip()})
    frasi.sort(key=lambda x: x["t"])
    formati = sorted({b["f"] for b in blocchi})
    return {"blocchi": blocchi, "frasi": frasi, "altri": sorted(set(altri)), "formati": formati}


def _sost_tutto(v, da, a):
    """Sostituisce la parola in tutti i testi di un .json (liste e voci comprese). Torna (nuovo, quante)."""
    rx = re.compile(r"(?<!\w)" + re.escape(da) + r"(?!\w)")
    n = 0

    def giro(x):
        nonlocal n
        if isinstance(x, str):
            nuovo, c = rx.subn(a, x)
            n += c
            return nuovo
        if isinstance(x, list):
            return [giro(y) for y in x]
        if isinstance(x, dict):
            return {kk: giro(y) for kk, y in x.items()}
        return x
    return giro(v), n


def salva(cartella, modifiche, sost=None):
    """modifiche = [{"id", "testo"?, "tolta"?, "ev"?, "nota"?}] sui blocchi e sulle frasi (id senza «|» nel formato
    = frase «k|i»). sost = [[da, a]]: le sostituzioni gia' fatte dalla pagina sui blocchi e sulle frasi, da fare
    qui sugli appunti degli altri formati (esame, verbale). Torna quante cose ha cambiato."""
    cartella = Path(cartella)
    n = 0
    per_file, per_tr = {}, {}
    for m in modifiche or []:
        parti = str(m.get("id") or "").split("|")
        if len(parti) == 2:
            per_tr.setdefault(parti[0], []).append((int(parti[1]), m))
        elif len(parti) >= 3:
            per_file.setdefault((parti[0], parti[1]), []).append((parti[2:], m))
    for (f, k), lista in per_file.items():
        p = ap.file_json(cartella, k, f)
        dati = el.leggi_json(p)
        if not _con_blocchi(dati):
            continue
        ev = list(dati.get("_evid") or [])
        mie = [x for x in dati.get("_mie") or [] if isinstance(x, dict)]
        togli = {}
        for via, m in lista:
            if via == ["r"]:
                if "testo" in m:
                    dati["riassunto"] = str(m["testo"]).strip()
                    n += 1
                continue
            try:
                b = int(via[0])
                bl = dati["blocchi"][b]
            except (ValueError, IndexError, TypeError):
                continue
            if via[1] == "d":
                if "testo" in m:
                    bl["domanda"] = str(m["testo"]).strip()
                    n += 1
                continue
            try:
                i = int(via[1])
                vecchio = str(bl["appunti"][i])
            except (ValueError, IndexError, KeyError, TypeError):
                continue
            nuovo = str(m["testo"]).strip() if "testo" in m else vecchio
            if nuovo != vecchio:
                bl["appunti"][i] = nuovo
                ev = [nuovo if x == vecchio else x for x in ev]
                for x in mie:
                    if x.get("dopo") == vecchio:
                        x["dopo"] = nuovo
                n += 1
            if "ev" in m:
                ev = [x for x in ev if x != nuovo] + ([nuovo] if m["ev"] else [])
                n += 1
            if "nota" in m:
                mie = [x for x in mie if x.get("dopo") != nuovo]
                if str(m["nota"] or "").strip():
                    mie.append({"dopo": nuovo, "nota": str(m["nota"]).strip()[:600]})
                n += 1
            if m.get("tolta"):
                togli.setdefault(b, []).append(i)
                ev = [x for x in ev if x != nuovo]
                mie = [x for x in mie if x.get("dopo") != nuovo]
                n += 1
        for b, ii in togli.items():
            for i in sorted(set(ii), reverse=True):
                del dati["blocchi"][b]["appunti"][i]
        dati["_evid"], dati["_mie"] = ev, mie
        el.scrivi_json(p, dati)
    for k, lista in per_tr.items():
        p = cartella / f"trascrizione_{k}.json"
        segs = el.leggi_json(p, []) or []
        for i, m in lista:
            if 0 <= i < len(segs) and isinstance(segs[i], dict) and str(m.get("testo") or "").strip():
                segs[i]["testo"] = str(m["testo"]).strip()
                n += 1
        el.scrivi_json(p, segs)
    for da, a in sost or []:
        da, a = str(da or "").strip(), str(a or "").strip()
        if not da or da == a:
            continue
        for f, k, p in _formati(cartella):
            dati = el.leggi_json(p)
            if not dati or _con_blocchi(dati):
                continue
            nuovo, c = _sost_tutto(dati, da, a)
            if c:
                el.scrivi_json(p, nuovo)
                n += c
    if n:
        el.aggiorna_info(cartella, corretta=True)
    return n
