# -*- coding: utf-8 -*-
"""
«Università e Master» (anteprima 71, approvata il 09/11/2026): il percorso dello studente.
  - il percorso: corso, tipo (triennale, magistrale, ciclo unico, master), università, Paese;
  - il libretto: esami con crediti e voti (a mano, oppure da una foto o dal PDF letti da Claude);
  - appelli e scadenze (iscrizioni, esami, tasse, altro), con il promemoria nel calendario;
  - la tesi (o project work): titolo, relatore, azienda, note.
Tutto in <cartella registrazioni>/esami/_universita.json: la cartella «esami» va gia' sugli altri dispositivi
(sincronizzazione e cloud). Il Paese decide voti e crediti:
  Italia: voti 18-30 e lode, CFU (crediti formativi universitari), voto di partenza alla laurea = media × 110 / 30;
  Paesi Bassi: voti 1-10 (si passa con 6, cioè 5,5 arrotondato), crediti ECTS;
  Regno Unito: voti in percentuale (si passa con 40, ai master con 50), crediti britannici, classe di laurea;
  Altro: voto massimo, minimo e nome dei crediti scelti dallo studente.
"""
import base64
import datetime
import logging
import re
import time
import uuid
from pathlib import Path

import appunti as ap
import chiedi as ch
import edizione
import elaborazione as el
import testi

log = logging.getLogger("universita")

NOME = "_universita.json"

# crediti di tutto il corso, di partenza (lo studente li cambia)
CREDITI = {"it": {"triennale": 180, "magistrale": 120, "ciclo": 300, "master": 60},
           "nl": {"triennale": 180, "magistrale": 60, "ciclo": 360, "master": 60},
           "uk": {"triennale": 360, "magistrale": 180, "ciclo": 480, "master": 180},
           "altro": {"triennale": 180, "magistrale": 120, "ciclo": 300, "master": 60}}
SCALA = {"it": {"max": 30, "min": 18, "crediti": "CFU"},
         "nl": {"max": 10, "min": 6, "crediti": "ECTS"},
         "uk": {"max": 100, "min": 40, "crediti": "credits"},
         "altro": {"max": 30, "min": 18, "crediti": ""}}
TIPI = ("triennale", "magistrale", "ciclo", "master")
TIPI_SCAD = ("iscrizione", "esame", "tasse", "altro")


def _f(base):
    p = Path(base) / "esami"
    p.mkdir(parents=True, exist_ok=True)
    return p / NOME


def _adesso():
    return time.strftime("%Y-%m-%dT%H:%M:%S")


def leggi(base):
    d = el.leggi_json(_f(base), {}) or {}
    if not isinstance(d, dict):
        d = {}
    d.setdefault("percorso", {})
    d["esami"] = [e for e in d.get("esami") or [] if isinstance(e, dict) and e.get("id")]
    d["scadenze"] = [s for s in d.get("scadenze") or [] if isinstance(s, dict) and s.get("id")]
    d.setdefault("tesi", {})
    return d


def salva(base, d):
    el.scrivi_json(_f(base), d)


def _num(x):
    try:
        return float(str(x).replace(",", ".").strip())
    except (TypeError, ValueError):
        return None


def scala(perc):
    """Voto massimo, minimo per passare e nome dei crediti del percorso (dal Paese, o scelti dallo studente)."""
    p = perc or {}
    paese = p.get("paese") if p.get("paese") in SCALA else "it"
    s = dict(SCALA[paese])
    if paese == "uk" and p.get("tipo") == "master":
        s["min"] = 50
    if paese == "altro":
        s["max"] = _num(p.get("voto_max")) or s["max"]
        s["min"] = _num(p.get("voto_min")) or s["min"]
        s["crediti"] = str(p.get("nome_crediti") or "").strip()[:20]
    s["paese"] = paese
    return s


def voto_di(testo, sc=None):
    """Un voto scritto come capita («28», «30 e lode», «30L», «idoneo», «7,5», «68%») -> (voto, lode, idoneo)."""
    t = str(testo or "").strip().lower()
    if not t:
        return None, False, False
    if re.search(r"\b(idone|approvat|superat|pass\b|passed|sufficient|voldaan)", t):
        n = _num(re.sub(r"[^\d.,]", "", t))
        if n is None:
            return None, False, True
    lode = bool(re.search(r"lode|30\s*l\b|cum laude", t))
    m = re.search(r"\d+(?:[.,]\d+)?", t)
    if not m:
        return None, False, False
    v = _num(m.group(0))
    if sc and v is not None and (v > sc["max"] or v < 0):
        return None, False, False
    return v, lode, False


def _norm(s):
    return re.sub(r"\W+", " ", str(s or "").casefold()).strip()


def riepilogo(d):
    """Crediti fatti e mancanti, media ponderata, voto di partenza (Italia) o classe (Regno Unito)."""
    p = d.get("percorso") or {}
    sc = scala(p)
    tipo = p.get("tipo") if p.get("tipo") in TIPI else "triennale"
    tot = _num(p.get("cfu_tot")) or CREDITI[sc["paese"]][tipo]
    fatti = [e for e in d["esami"] if e.get("idoneo") or (e.get("voto") is not None and e["voto"] <= sc["max"] and e["voto"] >= sc["min"] - (0.5 if sc["paese"] == "nl" else 0))]
    cfu = sum(_num(e.get("cfu")) or 0 for e in fatti)
    con_voto = [e for e in fatti if e.get("voto") is not None and not e.get("idoneo")]
    peso = sum(_num(e.get("cfu")) or 0 for e in con_voto)
    media = (sum((_num(e.get("cfu")) or 0) * e["voto"] for e in con_voto) / peso) if peso else \
        (sum(e["voto"] for e in con_voto) / len(con_voto) if con_voto else None)
    out = {"crediti": cfu, "totale": tot, "mancano": max(0, tot - cfu), "fatti": len(fatti), "esami": len(d["esami"]),
           "media": round(media, 2) if media is not None else None, "scala": sc, "tipo": tipo,
           "piu_alto": max((e["voto"] for e in con_voto), default=None), "partenza": None, "classe": ""}
    if media is not None and sc["paese"] == "it" and tipo != "master":
        out["partenza"] = round(media * 110 / 30, 1)
    if media is not None and sc["paese"] == "uk":
        if tipo == "master":
            out["classe"] = "distinction" if media >= 70 else "merit" if media >= 60 else "pass" if media >= 50 else ""
        else:
            out["classe"] = "first" if media >= 70 else "21" if media >= 60 else "22" if media >= 50 else "third" if media >= 40 else ""
    return out


def _pulisci_esame(x, sc, vecchio=None):
    e = dict(vecchio or {})
    if "nome" in x:
        e["nome"] = str(x.get("nome") or "").strip()[:120]
    if "cfu" in x:
        e["cfu"] = _num(x.get("cfu")) or 0
    if "voto" in x:
        v, lode, idoneo = voto_di(x.get("voto"), sc)
        e["voto"], e["lode"], e["idoneo"] = v, bool(lode or x.get("lode")), bool(idoneo or x.get("idoneo"))
    for k, n in (("anno", 40), ("materia", 60), ("data", 10)):
        if k in x:
            e[k] = str(x.get(k) or "").strip()[:n]
    e.setdefault("id", uuid.uuid4().hex[:10])
    e["quando"] = _adesso()
    return e


def esame(base, x):
    """Aggiunge o cambia un esame (x con «id» = cambia; «togli»: True = toglie)."""
    d = leggi(base)
    sc = scala(d["percorso"])
    x = x or {}
    if x.get("id"):
        i = next((k for k, e in enumerate(d["esami"]) if e["id"] == x["id"]), None)
        if i is None:
            return d
        if x.get("togli"):
            via = [x["id"]] + [s["id"] for s in d["scadenze"] if s.get("esame") == x["id"]]
            d["esami"].pop(i)
            d["scadenze"] = [s for s in d["scadenze"] if s["id"] not in via]
            d["tolti"] = (list(d.get("tolti") or []) + via)[-500:]
        else:
            d["esami"][i] = _pulisci_esame(x, sc, d["esami"][i])
    elif str(x.get("nome") or "").strip():
        d["esami"].append(_pulisci_esame(x, sc))
    salva(base, d)
    return d


def esami_insieme(base, lista):
    """Gli esami letti dalla foto: quelli con lo stesso nome si aggiornano (crediti, voto), gli altri si aggiungono."""
    d = leggi(base)
    sc = scala(d["percorso"])
    nuovi = cambiati = 0
    for x in lista or []:
        if not isinstance(x, dict) or not str(x.get("nome") or "").strip():
            continue
        i = next((k for k, e in enumerate(d["esami"]) if _norm(e.get("nome")) == _norm(x.get("nome"))), None)
        if i is None:
            d["esami"].append(_pulisci_esame(x, sc))
            nuovi += 1
        else:
            y = {k: v for k, v in x.items() if k in ("cfu", "voto", "anno", "data") and str(v or "").strip()}
            if y:
                d["esami"][i] = _pulisci_esame(y, sc, d["esami"][i])
                cambiati += 1
    salva(base, d)
    return d, nuovi, cambiati


def scadenza(base, x):
    """Aggiunge, cambia o toglie una scadenza (appello, iscrizione, tasse, altro)."""
    d = leggi(base)
    x = x or {}
    if x.get("id"):
        i = next((k for k, s in enumerate(d["scadenze"]) if s["id"] == x["id"]), None)
        if i is None:
            return d
        if x.get("togli"):
            d["scadenze"].pop(i)
            d["tolti"] = (list(d.get("tolti") or []) + [x["id"]])[-500:]
            salva(base, d)
            return d
        s = dict(d["scadenze"][i])
    else:
        s = {"id": uuid.uuid4().hex[:10]}
    for k, n in (("cosa", 140), ("nota", 200), ("esame", 12), ("ora", 5)):
        if k in x:
            s[k] = str(x.get(k) or "").strip()[:n]
    if "tipo" in x:
        s["tipo"] = x["tipo"] if x.get("tipo") in TIPI_SCAD else "altro"
    if "data" in x:
        try:
            s["data"] = datetime.date.fromisoformat(str(x["data"])[:10]).isoformat()
        except ValueError:
            return d
    if "fatto" in x:
        s["fatto"] = bool(x["fatto"])
    if s.get("ora") and not re.fullmatch(r"\d{1,2}:\d{2}", s["ora"]):
        s["ora"] = ""
    if not s.get("data") or not (s.get("cosa") or s.get("esame")):
        return d
    s.setdefault("tipo", "altro")
    s["quando"] = _adesso()
    if x.get("id"):
        d["scadenze"][i] = s
    else:
        d["scadenze"].append(s)
    salva(base, d)
    return d


def percorso(base, x):
    d = leggi(base)
    p = dict(d["percorso"])
    for k, n in (("corso", 120), ("uni", 120), ("nome_crediti", 20)):
        if k in (x or {}):
            p[k] = str(x.get(k) or "").strip()[:n]
    if (x or {}).get("tipo") in TIPI:
        p["tipo"] = x["tipo"]
    if (x or {}).get("paese") in SCALA:
        p["paese"] = x["paese"]
    for k in ("anno", "cfu_tot", "voto_max", "voto_min"):
        if k in (x or {}):
            n = _num(x.get(k))
            p[k] = n if n and n > 0 else None
    p["_agg"] = _adesso()
    d["percorso"] = p
    salva(base, d)
    return d


def tesi(base, x):
    d = leggi(base)
    t = dict(d["tesi"])
    for k, n in (("titolo", 200), ("relatore", 120), ("correlatore", 120), ("azienda", 120), ("note", 2000)):
        if k in (x or {}):
            t[k] = str(x.get(k) or "").strip()[:n]
    t["_agg"] = _adesso()
    d["tesi"] = t
    salva(base, d)
    return d


def unisci(mio, altro, mio_nuovo=True):
    """Lo stesso file cambiato su due dispositivi: esami e scadenze per id (vince l'ultima modifica), il resto
    (percorso, tesi) vince il piu' recente."""
    out = {}
    ca, cb = altro.get("calendario") or {}, mio.get("calendario") or {}
    if ca.get("codice") and cb.get("codice") and ca["codice"] != cb["codice"]:
        out["calendario"] = min((ca, cb), key=lambda c: str(c.get("creato", "")))      # due collegati insieme: resta il primo
    else:
        c = cb if str(cb.get("_agg", "")) >= str(ca.get("_agg", "")) else ca
        if c:
            out["calendario"] = c
    for k in ("percorso", "tesi"):
        a, b = altro.get(k) or {}, mio.get(k) or {}
        out[k] = b if str(b.get("_agg", "")) >= str(a.get("_agg", "")) and (b or not a) else a
    for k in ("esami", "scadenze"):
        u = {}
        for lista in (altro.get(k) or [], mio.get(k) or []):
            for x in lista:
                if isinstance(x, dict) and x.get("id") and (x["id"] not in u or str(x.get("quando", "")) >= str(u[x["id"]].get("quando", ""))):
                    u[x["id"]] = x
        out[k] = list(u.values())
    out["tolti"] = sorted(set(mio.get("tolti") or []) | set(altro.get("tolti") or []))[-500:]
    for k in ("esami", "scadenze"):
        out[k] = [x for x in out[k] if x["id"] not in out["tolti"]]
    return out


# ------------------------------------------------------------------ Claude legge libretto e calendario degli appelli

def _contenuto(file):
    p = Path(file)
    if p.suffix.lower() == ".pdf":
        return {"type": "document", "source": {"type": "base64", "media_type": "application/pdf",
                                               "data": base64.b64encode(p.read_bytes()).decode()}}
    return {"type": "image", "source": {"type": "base64", "media_type": "image/jpeg",
                                        "data": base64.b64encode(ch.jpeg_ridotto(p)).decode()}}


def leggi_libretto(chiave, files, lingua=None):
    """Foto (o PDF) del libretto o del piano di studi -> {"esami": [{nome, cfu, voto, anno, data}], "corso", "uni", "spesa"}."""
    lingua = lingua or testi.LINGUA
    strumento = {"name": "salva_libretto", "description": "Gli esami letti",
                 "input_schema": {"type": "object", "properties": {
                     "corso": {"type": "string", "description": "nome del corso di laurea o del master, se c'e'"},
                     "universita": {"type": "string"},
                     "esami": {"type": "array", "items": {"type": "object", "properties": {
                         "nome": {"type": "string"}, "crediti": {"type": "number"},
                         "voto": {"type": "string", "description": "come e' scritto: 28, 30 e lode, idoneo, 7,5, 68%; vuoto se non ancora dato"},
                         "anno": {"type": "string", "description": "anno di corso o semestre, se c'e'"},
                         "data": {"type": "string", "description": "data dell'esame AAAA-MM-GG, se c'e'"}},
                         "required": ["nome"]}}},
                     "required": ["esami"]}}
    corpo = {"model": ap.MODELLO, "max_tokens": 6000, "tools": [strumento],
             "system": ("Ti mando le foto (o il PDF) del libretto universitario o del piano di studi di uno studente "
                        "(laurea o master, anche all'estero). Leggi TUTTI gli esami, nell'ordine: nome come e' scritto, crediti "
                        "(CFU, ECTS o altri), voto come e' scritto (vuoto se l'esame non e' ancora stato dato), anno o semestre, "
                        "data. Non inventare niente: quello che non si legge lascialo vuoto. "
                        f"I nomi degli esami lasciali nella lingua del documento. Usa lo strumento salva_libretto."),
             "messages": [{"role": "user", "content": [_contenuto(f) for f in files[:8]] + [{"type": "text", "text": "Ecco."}]}]}
    dati, uso = ch.strumento(chiave, corpo, "esami", "un_err")
    esami = [{"nome": str(e.get("nome") or "").strip(), "cfu": e.get("crediti"), "voto": str(e.get("voto") or "").strip(),
              "anno": str(e.get("anno") or "").strip(), "data": str(e.get("data") or "").strip()[:10]}
             for e in dati.get("esami") or [] if str(e.get("nome") or "").strip()]
    return {"esami": esami, "corso": str(dati.get("corso") or "").strip(), "uni": str(dati.get("universita") or "").strip(),
            "spesa": ch._costo(uso)}


def leggi_appelli(chiave, files, lingua=None):
    """Foto (o PDF) del calendario degli appelli -> {"appelli": [{esame, data, ora, tipo, iscrizione, aula}], "spesa"}."""
    oggi = datetime.date.today().isoformat()
    strumento = {"name": "salva_appelli", "description": "Gli appelli letti",
                 "input_schema": {"type": "object", "properties": {"appelli": {"type": "array", "items": {"type": "object", "properties": {
                     "esame": {"type": "string"}, "data": {"type": "string", "description": "AAAA-MM-GG"},
                     "ora": {"type": "string", "description": "HH:MM, se c'e'"},
                     "tipo": {"type": "string", "description": "scritto, orale o altro, come e' scritto"},
                     "iscrizione": {"type": "string", "description": "ultimo giorno per iscriversi AAAA-MM-GG, se c'e'"},
                     "aula": {"type": "string"}}, "required": ["esame", "data"]}}}, "required": ["appelli"]}}
    corpo = {"model": ap.MODELLO, "max_tokens": 6000, "tools": [strumento],
             "system": ("Ti mando le foto (o il PDF) del calendario degli appelli d'esame di un'universita'. Leggi tutti gli "
                        "appelli: nome dell'esame come e' scritto, data (AAAA-MM-GG), ora, tipo (scritto, orale...), ultimo giorno "
                        f"per iscriversi se c'e', aula. Oggi e' il {oggi}: se l'anno non e' scritto scegli quello che rende la data "
                        "futura. Non inventare niente. Usa lo strumento salva_appelli."),
             "messages": [{"role": "user", "content": [_contenuto(f) for f in files[:8]] + [{"type": "text", "text": "Ecco."}]}]}
    dati, uso = ch.strumento(chiave, corpo, "appelli", "un_err")
    out = []
    for a in dati.get("appelli") or []:
        try:
            g = datetime.date.fromisoformat(str(a.get("data") or "")[:10]).isoformat()
        except ValueError:
            continue
        try:
            isc = datetime.date.fromisoformat(str(a.get("iscrizione") or "")[:10]).isoformat()
        except ValueError:
            isc = ""
        ora = str(a.get("ora") or "").strip()[:5]
        out.append({"esame": str(a.get("esame") or "").strip()[:120], "data": g, "ora": ora if re.fullmatch(r"\d{1,2}:\d{2}", ora) else "",
                    "tipo": str(a.get("tipo") or "").strip()[:40], "iscrizione": isc, "aula": str(a.get("aula") or "").strip()[:60]})
    return {"appelli": out, "spesa": ch._costo(uso)}


def appelli_insieme(base, lista, L="it"):
    """Gli appelli letti dalla foto: un esame del libretto con lo stesso nome si collega; per ognuno la data
    dell'esame e, se c'e', l'ultimo giorno per iscriversi."""
    d = leggi(base)
    n = 0
    for a in lista or []:
        if not isinstance(a, dict) or not a.get("data"):
            continue
        es_ = next((e for e in d["esami"] if _norm(e.get("nome")) == _norm(a.get("esame"))), None)
        nome = (es_ or {}).get("nome") or str(a.get("esame") or "").strip()
        nota = " · ".join(x for x in (a.get("tipo"), a.get("aula")) if x)
        voci = [{"tipo": "esame", "data": a["data"], "ora": a.get("ora") or "", "nota": nota}]
        if a.get("iscrizione"):
            voci.append({"tipo": "iscrizione", "data": a["iscrizione"], "ora": "", "nota": ""})
        for v in voci:
            if any(s.get("tipo") == v["tipo"] and s.get("data") == v["data"] and
                   ((es_ and s.get("esame") == es_["id"]) or _norm(s.get("cosa")) == _norm(nome)) for s in d["scadenze"]):
                continue
            d["scadenze"].append({"id": uuid.uuid4().hex[:10], **v, "cosa": "" if es_ else nome, "esame": es_["id"] if es_ else "",
                                  "quando": _adesso()})
            n += 1
    salva(base, d)
    return d, n


# ------------------------------------------------------------------ calendario

T_CAL = {"it": {"iscrizione": "Iscrizione all'esame", "esame": "Esame", "tasse": "Tasse universitarie", "altro": "Scadenza"},
         "en": {"iscrizione": "Exam registration", "esame": "Exam", "tasse": "University fees", "altro": "Deadline"}}


def nome_scadenza(d, s, L="it"):
    es_ = next((e for e in d["esami"] if e["id"] == s.get("esame")), None)
    cosa = (es_ or {}).get("nome") or s.get("cosa") or ""
    return f"{T_CAL.get(L, T_CAL['it'])[s.get('tipo') or 'altro']}: {cosa}" if cosa else T_CAL.get(L, T_CAL["it"])[s.get("tipo") or "altro"]


def eventi(d, ids=None, L="it"):
    oggi = datetime.date.today().isoformat()
    return [{"titolo": nome_scadenza(d, s, L), "data": s["data"], "ora": s.get("ora") or "", "note": s.get("nota") or ""}
            for s in sorted(d["scadenze"], key=lambda s: s["data"])
            if (ids is None or s["id"] in ids) and s["data"] >= oggi and not s.get("fatto")]


def date_esami(d):
    """Per ogni esame collegato a una materia di Verba Manent: il prossimo appello (per la preparazione all'esame)."""
    oggi = datetime.date.today().isoformat()
    out = {}
    for e in d["esami"]:
        if not e.get("materia") or e.get("voto") is not None or e.get("idoneo"):
            continue
        prossimi = sorted(s["data"] for s in d["scadenze"] if s.get("esame") == e["id"] and s.get("tipo") == "esame"
                          and s["data"] >= oggi and not s.get("fatto"))
        if prossimi:
            out[e["materia"]] = prossimi[0]
    return out


# ------------------------------------------------------------------ calendario sempre aggiornato (scelta 1A di Paolo, 09/11/2026)

def calendario(base, attivo=True):
    """Il collegamento al calendario: codice (nell'indirizzo .ics) e chiave (per cambiarlo), uguali su tutti i dispositivi."""
    import secrets
    d = leggi(base)
    c = dict(d.get("calendario") or {})
    if attivo and not c.get("codice"):
        c = {"codice": secrets.token_hex(16), "chiave": secrets.token_hex(24), "creato": _adesso()}
    c["attivo"] = bool(attivo)
    c["_agg"] = _adesso()
    d["calendario"] = c
    salva(base, d)
    return c


def eventi_feed(base, d, L="it"):
    """Tutte le date per il calendario: scadenze di «Università e Master» (anche quelle passate da poco) e le date
    d'esame scelte in Studia (quelle che non vengono gia' da un appello)."""
    import hashlib
    import esame as es
    da = (datetime.date.today() - datetime.timedelta(days=60)).isoformat()
    out = []
    for s in d["scadenze"]:
        if s.get("fatto") or s["data"] < da:
            continue
        out.append({"id": "u" + s["id"], "titolo": nome_scadenza(d, s, L), "data": s["data"], "ora": s.get("ora") or "", "note": s.get("nota") or "",
                    "tipo": s.get("tipo") or "altro"})
    gia = {(str((next((e for e in d["esami"] if e["id"] == s.get("esame")), {}) or {}).get("materia") or "").casefold(), s["data"])
           for s in d["scadenze"] if s.get("tipo") == "esame"}
    p = Path(base) / "esami"
    for f in sorted(p.glob("*.json")) if p.exists() else []:
        if f.name.startswith("_") or re.search(r"_(glossario|mappa_verifica)\.json$", f.name):
            continue
        x = el.leggi_json(f, {}) or {}
        m, data = str(x.get("materia") or "").strip(), str(x.get("data_esame") or "")
        if not m or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", data) or data < da or (m.casefold(), data) in gia:
            continue
        out.append({"id": "s" + hashlib.md5(m.casefold().encode()).hexdigest()[:12], "titolo": f"{T_CAL.get(L, T_CAL['it'])['esame']}: {m}",
                    "data": data, "ora": "", "note": "", "tipo": "esame"})
    return sorted(out, key=lambda e: (e["data"], e["ora"]))


# ------------------------------------------------------------------ promemoria per tempo (scelta 1C di Paolo, 09/11/2026)
# esame 14, 7 e 1 giorno prima; iscrizione 3 giorni prima e il giorno della scadenza; tasse e altro 7 e 1 giorno prima
GIORNI = {"esame": (14, 7, 1), "iscrizione": (3, 0), "tasse": (7, 1), "altro": (7, 1)}
T_PRO = {"it": {"tra": "{t} · tra {n} giorni", "domani": "{t} · domani", "oggi": "{t} · oggi è l'ultimo giorno",
                "esame": "Apri {app}: in Studia trovi il piano di studio e le domande più probabili.",
                "altro": "Apri {app} › Università e Master."},
         "en": {"tra": "{t} · in {n} days", "domani": "{t} · tomorrow", "oggi": "{t} · today is the last day",
                "esame": "Open {app}: in Study you find the study plan and the most likely questions.",
                "altro": "Open {app} › University and Master."}}


def promemoria(eventi, L="it"):
    """I promemoria delle date (da eventi_feed): [{id, giorno, ora, titolo, testo, n}]; alle 9 (il giorno stesso alle 8)."""
    T = T_PRO.get(L, T_PRO["it"])
    out = []
    for e in eventi:
        try:
            d = datetime.date.fromisoformat(e["data"])
        except ValueError:
            continue
        for n in GIORNI.get(e.get("tipo") or "altro", GIORNI["altro"]):
            tit = T["oggi" if n == 0 else "domani" if n == 1 else "tra"].format(t=e["titolo"], n=n)
            out.append({"id": f"{e['id']}-{n}", "giorno": (d - datetime.timedelta(days=n)).isoformat(), "ora": "08:00" if n == 0 else "09:00",
                        "titolo": tit, "testo": T["esame" if e.get("tipo") == "esame" else "altro"].format(app=edizione.NOME_BREVE), "n": n})
    return out
