"""«Scrivi a mano» (anteprima 69, 08/11/2026): fogli scritti col dito, la penna o il mouse, durante la registrazione o
dopo. Ogni tratto ricorda il secondo della lezione («s»): dopo, toccandolo, si sente il prof in quel momento.

mano.json nella cartella della lezione: {"fogli": [{"id", "slide" (file della slide sotto, o ""), "r" (altezza/larghezza),
"tratti": [{"c" colore, "e" evidenziatore, "p": [[x, y], ...] in frazioni della LARGHEZZA, "s" secondi o null}]}]}.
Le immagini (mano/foglio_<id>.png) servono a Claude per leggere la scrittura e al PDF degli appunti."""
import hashlib
import json
from pathlib import Path

import elaborazione as el

COLORI = {"#14202e", "#1d4ed8", "#b91c1c"}


def file(cart):
    return Path(cart) / "mano.json"


def leggi(cart):
    d = el.leggi_json(file(cart), {}) or {}
    return d if isinstance(d.get("fogli"), list) else {"fogli": []}


def _pulisci(fogli):
    out = []
    for f in (fogli or [])[:40]:
        tratti = []
        for t in (f.get("tratti") or [])[:4000]:
            p = [[round(float(x), 4), round(float(y), 4)] for x, y in (t.get("p") or [])[:2000]]
            if not p:
                continue
            c = t.get("c") if t.get("c") in COLORI else "#14202e"
            s = t.get("s")
            tratti.append({"c": c, "e": bool(t.get("e")), "p": p, "s": round(float(s), 1) if isinstance(s, (int, float)) else None})
        out.append({"id": str(f.get("id") or len(out) + 1)[:20], "slide": str(f.get("slide") or "")[:120],
                    "r": max(0.3, min(3.0, float(f.get("r") or 1.3))), "tratti": tratti})
    return out


def salva(cart, fogli):
    d = {"fogli": _pulisci(fogli)}
    el.scrivi_json(file(cart), d)
    return d


def firma(f):
    return hashlib.sha1(json.dumps(f, sort_keys=True).encode()).hexdigest()[:12]


def immagine(cart, f, larg=1200):
    """Il foglio in PNG (righe o slide sotto, poi i tratti). Torna il percorso, o None se il foglio e' vuoto."""
    from PIL import Image, ImageDraw
    if not f.get("tratti"):
        return None
    W, H = larg, int(larg * f.get("r", 1.3))
    im = Image.new("RGB", (W, H), (255, 255, 255))
    if f.get("slide"):
        try:
            with Image.open(el.immagine_slide(cart, f["slide"])) as sl:
                sl = sl.convert("RGB").resize((W, H))
                im.paste(sl, (0, 0))
        except Exception:
            pass
    else:
        d0 = ImageDraw.Draw(im)
        for y in range(40, H, 40):
            d0.line([(0, y), (W, y)], fill=(229, 237, 245), width=2)
    lay = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(lay)
    for t in f["tratti"]:
        pts = [(x * W, y * W) for x, y in t["p"]]
        col = (250, 204, 21, 110) if t.get("e") else tuple(int(t["c"][i:i + 2], 16) for i in (1, 3, 5)) + (255,)
        w = 18 if t.get("e") else 4
        if len(pts) == 1:
            x, y = pts[0]
            d.ellipse([x - w / 2, y - w / 2, x + w / 2, y + w / 2], fill=col)
        else:
            d.line(pts, fill=col, width=w, joint="curve")
    im = Image.alpha_composite(im.convert("RGBA"), lay).convert("RGB")
    out = Path(cart) / "mano" / f"foglio_{f['id']}.png"
    out.parent.mkdir(exist_ok=True)
    im.save(out)
    return out


def immagini(cart):
    """Le immagini di tutti i fogli non vuoti, rifatte se il foglio e' cambiato."""
    out = []
    for f in leggi(cart)["fogli"]:
        p = Path(cart) / "mano" / f"foglio_{f['id']}.png"
        segno = Path(cart) / "mano" / f"foglio_{f['id']}.firma"
        if f.get("tratti") and (not p.exists() or not segno.exists() or segno.read_text() != firma(f)):
            p = immagine(cart, f)
            if p:
                segno.write_text(firma(f))
        if f.get("tratti") and p and p.exists():
            out.append((f, p))
    return out


def pdf_fogli(cart, dest):
    """Un PDF con i fogli scritti a mano (uno per pagina), da attaccare in fondo agli appunti. None se non ce ne sono."""
    fogli = immagini(cart)
    if not fogli:
        return None
    from fpdf import FPDF
    pdf = FPDF(format="A4")
    pdf.set_auto_page_break(False)
    for f, p in fogli:
        pdf.add_page()
        w = pdf.w - 20
        h = w * f.get("r", 1.3)
        if h > pdf.h - 20:
            h = pdf.h - 20
            w = h / f.get("r", 1.3)
        pdf.image(str(p), x=(pdf.w - w) / 2, y=10, w=w, h=h)
    pdf.output(str(dest))
    return Path(dest)
